import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  User,
  UserRole,
  Site,
  Restriction,
  RestrictionType,
  ActivityLog,
  ThreatPattern,
  SystemStats,
  LogCategory,
} from '../types/security';
import { calculateCRC32, getLogPayloadString, verifyLogIntegrity } from '../utils/crc32';
import { scanUrlSecurity } from '../utils/scanner';
import { calculateRestrictionTrustScore, isRestrictionDeletableBy } from '../utils/trustScore';
import { generateStandaloneSecurityHtml } from '../utils/singleHtmlExport';

const MASTER_KEY = 'MASTER-2024-OVERRIDE';
// Use v2 clean storage key so no legacy mock data is loaded
const STORAGE_KEY = 'mlsmd_security_state_v2_clean';

// Initial preloaded users: Clean baseline admin account
const INITIAL_USERS: User[] = [
  {
    id: 'admin',
    name: 'システム管理者 (Admin)',
    role: 'L3',
    isVerified: true,
    createdAt: new Date().toISOString().substring(0, 10),
    failedLoginAttempts: 0,
    isRestricted: false,
    password: 'admin123',
  },
];

// CLEAN: Start with 0 sites (No fake pre-registered sites)
const INITIAL_SITES: Site[] = [];

// CLEAN: Start with 0 restrictions (No fake pre-registered lockdowns)
const INITIAL_RESTRICTIONS: Restriction[] = [];

// Helper to create timestamp string
function createIsoTimestamp(): string {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const hh = String(now.getHours()).padStart(2, '0');
  const mi = String(now.getMinutes()).padStart(2, '0');
  const ss = String(now.getSeconds()).padStart(2, '0');
  const ms = String(now.getMilliseconds()).padStart(3, '0');
  return `${yyyy}-${mm}-${dd} ${hh}:${mi}:${ss}.${ms}`;
}

function createLog(
  operatorId: string,
  action: string,
  category: LogCategory,
  severity: 'success' | 'warning' | 'error' | 'info' = 'info'
): ActivityLog {
  const timestamp = createIsoTimestamp();
  const payload = getLogPayloadString(timestamp, operatorId, action, category);
  const checksum = calculateCRC32(payload);
  return {
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    timestamp,
    operatorId,
    action,
    category,
    checksum,
    isTampered: false,
    severity,
  };
}

const INITIAL_LOGS: ActivityLog[] = [
  createLog('SYSTEM', 'Guardian MLSMD セキュリティコア初期化完了（クリーン状態）', 'system', 'info'),
  createLog('SYSTEM', '改ざん防止台帳 (CRC-32) & 自動反撃シールド待機中', 'system', 'success'),
];

export interface SecurityContextType {
  currentUser: User | null;
  emergencyOverrideActive: boolean;
  autoRepelShieldActive: boolean;
  users: User[];
  sites: Site[];
  restrictions: Restriction[];
  logs: ActivityLog[];
  threatPatterns: ThreatPattern[];
  stats: SystemStats;
  toastMessage: { text: string; type: 'success' | 'error' | 'warning' | 'info' } | null;
  showToast: (text: string, type?: 'success' | 'error' | 'warning' | 'info') => void;
  // Auth & Account Creation
  login: (userId: string, passOrMasterKey: string) => { success: boolean; message: string; isMasterKey?: boolean };
  logout: () => void;
  registerNewAccount: (id: string, name: string, password: string, role: UserRole) => { success: boolean; message: string };
  emergencyMasterKeyOverride: (key: string) => boolean;
  dismissEmergencyOverride: () => void;
  repelLockdownAndRestore: () => void;
  toggleAutoRepelShield: () => void;
  // Sites
  addSite: (name: string, url: string, category: string, notes: string) => boolean;
  updateSite: (id: string, name: string, url: string, category: string, notes: string) => boolean;
  deleteSite: (id: string) => boolean;
  scanSite: (id: string) => void;
  scanAllSites: () => void;
  // Restrictions
  applyRestriction: (type: RestrictionType, reason: string, durationMinutes: number) => boolean;
  removeRestriction: (id: string) => boolean;
  // Users
  addUser: (name: string, id: string, password: string, role: UserRole, isVerified: boolean) => boolean;
  updateUserRole: (targetUserId: string, newRole: UserRole) => boolean;
  deleteUser: (targetUserId: string) => boolean;
  toggleUserVerified: (targetUserId: string) => boolean;
  // Logs & Audit
  tamperLog: (logId: string) => void;
  exportJsonBackup: () => void;
  importJsonBackup: (jsonContent: string) => boolean;
  downloadStandaloneHtml: () => void;
  resetToDefaults: () => void;
  seedDemoData: () => void;
  runTestScenario: (scenarioId: number) => void;
}

const SecurityContext = createContext<SecurityContextType | null>(null);

export const SecurityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load state from localStorage or start pristine
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_user`);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [emergencyOverrideActive, setEmergencyOverrideActive] = useState<boolean>(() => {
    try {
      return localStorage.getItem(`${STORAGE_KEY}_emergency`) === 'true';
    } catch {
      return false;
    }
  });

  const [autoRepelShieldActive, setAutoRepelShieldActive] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_repel_shield`);
      return saved !== null ? saved === 'true' : true; // Default ON to repel hackers
    } catch {
      return true;
    }
  });

  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_users`);
      return saved ? JSON.parse(saved) : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  });

  const [sites, setSites] = useState<Site[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_sites`);
      return saved ? JSON.parse(saved) : INITIAL_SITES;
    } catch {
      return INITIAL_SITES;
    }
  });

  const [restrictions, setRestrictions] = useState<Restriction[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_restrictions`);
      return saved ? JSON.parse(saved) : INITIAL_RESTRICTIONS;
    } catch {
      return INITIAL_RESTRICTIONS;
    }
  });

  const [logs, setLogs] = useState<ActivityLog[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_logs`);
      return saved ? JSON.parse(saved) : INITIAL_LOGS;
    } catch {
      return INITIAL_LOGS;
    }
  });

  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' | 'warning' | 'info' } | null>(null);

  const showToast = useCallback((text: string, type: 'success' | 'error' | 'warning' | 'info' = 'info') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(prev => (prev?.text === text ? null : prev));
    }, 4000);
  }, []);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_user`, JSON.stringify(currentUser));
      localStorage.setItem(`${STORAGE_KEY}_emergency`, emergencyOverrideActive ? 'true' : 'false');
      localStorage.setItem(`${STORAGE_KEY}_repel_shield`, autoRepelShieldActive ? 'true' : 'false');
      localStorage.setItem(`${STORAGE_KEY}_users`, JSON.stringify(users));
      localStorage.setItem(`${STORAGE_KEY}_sites`, JSON.stringify(sites));
      localStorage.setItem(`${STORAGE_KEY}_restrictions`, JSON.stringify(restrictions));
      localStorage.setItem(`${STORAGE_KEY}_logs`, JSON.stringify(logs));
    } catch (e) {
      console.warn('Storage sync failed:', e);
    }
  }, [currentUser, emergencyOverrideActive, autoRepelShieldActive, users, sites, restrictions, logs]);

  // Log append helper
  const addLogEntry = useCallback(
    (operatorId: string, action: string, category: LogCategory, severity: 'success' | 'warning' | 'error' | 'info' = 'info') => {
      const newEntry = createLog(operatorId, action, category, severity);
      setLogs(prev => [newEntry, ...prev.slice(0, 4999)]);
      return newEntry;
    },
    []
  );

  // Auto-expire restrictions timer
  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      setRestrictions(prev => {
        let changed = false;
        const updated = prev.map(r => {
          if (r.status === 'active') {
            const expTime = new Date(r.expiresAt).getTime();
            if (now >= expTime) {
              changed = true;
              return { ...r, status: 'expired' as const };
            }
          }
          return r;
        });
        if (changed) {
          addLogEntry('SYSTEM_TIMER', '有効期間を超過した制限が自動的に期限切れ（無効化）となりました', 'restriction', 'info');
        }
        return changed ? updated : prev;
      });
    }, 3000);

    return () => clearInterval(timer);
  }, [addLogEntry]);

  // Inactivity session timeout (30 minutes)
  useEffect(() => {
    if (!currentUser) return;
    let timeoutId: NodeJS.Timeout;

    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        addLogEntry(currentUser.id, '30分間の無操作によるセッションタイムアウト自動ログアウト', 'login', 'warning');
        setCurrentUser(null);
        showToast('⏰ 30分間操作がなかったためセッションがタイムアウトしました', 'warning');
      }, 30 * 60 * 1000);
    };

    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keydown', resetTimer);
    window.addEventListener('click', resetTimer);
    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keydown', resetTimer);
      window.removeEventListener('click', resetTimer);
    };
  }, [currentUser, addLogEntry, showToast]);

  // REPEL LOCKDOWN: Automatically or manually blast away hacker lockouts
  const repelLockdownAndRestore = useCallback(() => {
    setRestrictions(prev => {
      if (prev.length === 0) return prev;
      return prev.map(r => ({ ...r, status: 'bypassed' as const }));
    });
    setEmergencyOverrideActive(true);
    setAutoRepelShieldActive(true);

    addLogEntry(
      currentUser?.id || 'DEFENSE_SHIELD',
      '🛡️ ANTI-LOCKDOWN REPEL SHIELD: ハッカー制限を強制弾き返し！全ロックダウンを即時無効化し、アクセスを完全復旧しました',
      'emergency',
      'success'
    );
    showToast('🛡️ ハッカー制限を強制的に弾き返しました！すべての制限を無効化し完全復旧しました', 'success');
  }, [currentUser, addLogEntry, showToast]);

  const toggleAutoRepelShield = useCallback(() => {
    setAutoRepelShieldActive(prev => {
      const next = !prev;
      addLogEntry(
        currentUser?.id || 'ADMIN',
        `自動反撃シールド（Auto-Repel）を ${next ? '【有効】' : '【無効】'} に変更しました`,
        'system',
        'info'
      );
      showToast(`自動反撃シールドを ${next ? '有効化' : '無効化'} しました`, 'info');
      return next;
    });
  }, [currentUser, addLogEntry, showToast]);

  // Register New Account from Login Screen
  const registerNewAccount = useCallback(
    (id: string, name: string, password: string, role: UserRole) => {
      const trimmedId = id.trim().toLowerCase();
      const trimmedName = name.trim();
      const trimmedPass = password.trim();

      if (!trimmedId || !trimmedName || !trimmedPass) {
        return { success: false, message: 'すべての項目を入力してください' };
      }

      if (users.some(u => u.id.toLowerCase() === trimmedId)) {
        return { success: false, message: 'このユーザーIDは既に登録されています' };
      }

      const newUser: User = {
        id: trimmedId,
        name: trimmedName,
        password: trimmedPass,
        role: role || 'L3',
        isVerified: true,
        createdAt: new Date().toISOString().substring(0, 10),
        failedLoginAttempts: 0,
        isRestricted: false,
      };

      setUsers(prev => [...prev, newUser]);
      setCurrentUser(newUser);
      addLogEntry(
        newUser.id,
        `新規アカウントが登録され、ログインしました [ID: ${newUser.id}, 権限: ${newUser.role}]`,
        'admin',
        'success'
      );
      showToast(`🎉 アカウント「${newUser.name}」を作成しログインしました！`, 'success');
      return { success: true, message: '登録に成功しました' };
    },
    [users, addLogEntry, showToast]
  );

  // Authentication Logic
  const login = useCallback(
    (userId: string, passOrMasterKey: string) => {
      const trimmedKey = passOrMasterKey.trim();
      const trimmedUser = userId.trim();

      // Master Key Check
      if (trimmedKey === MASTER_KEY) {
        const emergencyUser: User = {
          id: 'MASTER_OPERATOR',
          name: '緊急マスター復旧管理者',
          role: 'L3',
          isVerified: true,
          createdAt: new Date().toISOString().substring(0, 10),
          failedLoginAttempts: 0,
          isRestricted: false,
        };
        setCurrentUser(emergencyUser);
        setEmergencyOverrideActive(true);
        setRestrictions(prev => prev.map(r => ({ ...r, status: 'bypassed' })));
        addLogEntry('MASTER-2024-OVERRIDE', '🚨 EMERGENCY_OVERRIDE: シークレットマスターキーによる緊急認証復旧が実行されました', 'emergency', 'warning');
        showToast('🚨 緊急復旧が実行されました。すべての制限が無視状態になります', 'warning');
        return { success: true, message: '緊急マスターキー認証成功。全制限をバイパスしてログインしました。', isMasterKey: true };
      }

      // Check user existence
      const user = users.find(u => u.id.toLowerCase() === trimmedUser.toLowerCase());
      if (!user) {
        addLogEntry(trimmedUser || 'UNKNOWN', '未登録IDでのログイン試行が拒否されました (不明)', 'login', 'error');
        return { success: false, message: 'アカウントが見つかりません' };
      }

      // Check password
      if (user.password !== trimmedKey) {
        setUsers(prev =>
          prev.map(u => (u.id === user.id ? { ...u, failedLoginAttempts: (u.failedLoginAttempts || 0) + 1 } : u))
        );
        addLogEntry(user.id, 'パスワード不一致によるログイン失敗 (不明)', 'login', 'error');
        return { success: false, message: 'ログインに失敗しました' };
      }

      // Check full lockdown
      const activeLockdown = restrictions.find(
        r => r.type === 'full_lockdown' && r.status === 'active' && r.trustScore >= 70
      );
      if (activeLockdown && !emergencyOverrideActive) {
        // If Auto-Repel is active, automatically repel the lockdown and allow the legitimate user in!
        if (autoRepelShieldActive) {
          repelLockdownAndRestore();
        } else {
          addLogEntry(user.id, 'フルロックダウン制限適用中のためログインが拒否されました', 'login', 'error');
          return { success: false, message: 'システム全体がロックダウン中であるためログインできません。「緊急復旧（マスターキー）」で解除可能です。' };
        }
      }

      // Check account restriction
      if (user.isRestricted && !emergencyOverrideActive) {
        addLogEntry(user.id, 'アカウント制限適用中のためログインが拒否されました', 'login', 'error');
        return { success: false, message: '現在、このアカウントに「管理者が適用した制限」が有効になっているためアクセスできません。' };
      }

      // Successful login
      setUsers(prev => prev.map(u => (u.id === user.id ? { ...u, failedLoginAttempts: 0 } : u)));
      setCurrentUser(user);
      addLogEntry(user.id, `ユーザー認証に成功しました [権限: ${user.role}]`, 'login', 'success');
      showToast(`✅ ログインに成功しました (ようこそ、${user.name} 様)`, 'success');
      return { success: true, message: 'ログインに成功しました' };
    },
    [users, restrictions, emergencyOverrideActive, autoRepelShieldActive, repelLockdownAndRestore, addLogEntry, showToast]
  );

  const logout = useCallback(() => {
    if (currentUser) {
      addLogEntry(currentUser.id, 'ユーザーログアウト完了', 'login', 'info');
    }
    setCurrentUser(null);
    showToast('ログアウトしました', 'info');
  }, [currentUser, addLogEntry, showToast]);

  const emergencyMasterKeyOverride = useCallback(
    (key: string) => {
      if (key.trim() === MASTER_KEY) {
        repelLockdownAndRestore();
        return true;
      }
      addLogEntry(currentUser?.id || 'UNKNOWN', '無効なマスターキーによる緊急復旧試行が拒否されました', 'emergency', 'error');
      showToast('❌ マスターキーが一致しません', 'error');
      return false;
    },
    [currentUser, repelLockdownAndRestore, addLogEntry, showToast]
  );

  const dismissEmergencyOverride = useCallback(() => {
    setEmergencyOverrideActive(false);
    addLogEntry(currentUser?.id || 'ADMIN', '緊急復旧モード（全バイパス）を解除し、通常セキュリティモードへ復帰しました', 'emergency', 'info');
    showToast('通常セキュリティモードに復帰しました', 'info');
  }, [currentUser, addLogEntry, showToast]);

  // Real Site Management (L2/L3 required)
  const addSite = useCallback(
    (name: string, url: string, category: string, notes: string): boolean => {
      if (!currentUser || currentUser.role === 'L1') {
        showToast('🚫 権限がありません（サイト追加にはL2以上の権限が必要です）', 'error');
        addLogEntry(currentUser?.id || 'ANON', 'サイト追加の試行が拒否されました（権限不足 L1）', 'site', 'error');
        return false;
      }

      // Ensure proper url formatting
      let formattedUrl = url.trim();
      if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
        formattedUrl = `https://${formattedUrl}`;
      }

      const scanResult = scanUrlSecurity(formattedUrl);
      const newSite: Site = {
        id: `site-${Date.now()}`,
        name: name.trim() || formattedUrl,
        url: formattedUrl,
        category: category.trim() || '本番サイト',
        notes: notes.trim(),
        addedBy: currentUser.id,
        isVerified: currentUser.isVerified,
        status: scanResult.riskLevel === 'danger' ? 'danger' : scanResult.riskLevel === 'warning' ? 'warning' : 'normal',
        createdAt: new Date().toISOString().substring(0, 10),
        lastScanResult: scanResult,
      };

      setSites(prev => [newSite, ...prev]);
      addLogEntry(
        currentUser.id,
        `新規Webサイト登録: ${newSite.name} (${newSite.url}) - 診断結果: ${scanResult.riskLevel.toUpperCase()}`,
        'site',
        scanResult.riskLevel === 'danger' ? 'warning' : 'success'
      );
      showToast(`管理サイト「${newSite.name}」を登録しました`, 'success');
      return true;
    },
    [currentUser, addLogEntry, showToast]
  );

  const updateSite = useCallback(
    (id: string, name: string, url: string, category: string, notes: string): boolean => {
      if (!currentUser || currentUser.role === 'L1') {
        showToast('🚫 権限がありません（サイト編集にはL2以上の権限が必要です）', 'error');
        return false;
      }
      let formattedUrl = url.trim();
      if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
        formattedUrl = `https://${formattedUrl}`;
      }

      const scanResult = scanUrlSecurity(formattedUrl);
      setSites(prev =>
        prev.map(s =>
          s.id === id
            ? {
                ...s,
                name: name.trim(),
                url: formattedUrl,
                category: category.trim() || s.category,
                notes: notes.trim(),
                status: scanResult.riskLevel === 'danger' ? 'danger' : scanResult.riskLevel === 'warning' ? 'warning' : 'normal',
                lastScanResult: scanResult,
              }
            : s
        )
      );
      addLogEntry(currentUser.id, `サイト情報更新: ${name} (${formattedUrl})`, 'site', 'info');
      showToast('サイト情報を更新しました', 'success');
      return true;
    },
    [currentUser, addLogEntry, showToast]
  );

  const deleteSite = useCallback(
    (id: string): boolean => {
      if (!currentUser || currentUser.role === 'L1') {
        showToast('🚫 権限がありません（サイト削除にはL2以上の権限が必要です）', 'error');
        return false;
      }
      const target = sites.find(s => s.id === id);
      setSites(prev => prev.filter(s => s.id !== id));
      addLogEntry(currentUser.id, `サイト削除: ${target?.name || id}`, 'site', 'warning');
      showToast(`サイトを削除しました`, 'info');
      return true;
    },
    [currentUser, sites, addLogEntry, showToast]
  );

  const scanSite = useCallback(
    (id: string) => {
      const target = sites.find(s => s.id === id);
      if (!target) return;
      const scanResult = scanUrlSecurity(target.url);
      setSites(prev =>
        prev.map(s =>
          s.id === id
            ? {
                ...s,
                status: scanResult.riskLevel === 'danger' ? 'danger' : scanResult.riskLevel === 'warning' ? 'warning' : 'normal',
                lastScanResult: scanResult,
              }
            : s
        )
      );
      addLogEntry(
        currentUser?.id || 'SYSTEM',
        `マルウェア検査実行 [${target.name}]: 判定=${scanResult.riskLevel.toUpperCase()} (スコア: ${scanResult.riskScore}点)`,
        'scan',
        scanResult.riskLevel === 'danger' ? 'error' : scanResult.riskLevel === 'warning' ? 'warning' : 'success'
      );
      showToast(`「${target.name}」の検査が完了しました (${scanResult.riskLevel === 'safe' ? '安全' : scanResult.riskLevel === 'warning' ? '警告' : '危険'})`, scanResult.riskLevel === 'safe' ? 'success' : 'warning');
    },
    [sites, currentUser, addLogEntry, showToast]
  );

  const scanAllSites = useCallback(() => {
    if (sites.length === 0) {
      showToast('管理サイトがまだ登録されていません。「+ サイト追加」から登録してください', 'info');
      return;
    }
    setSites(prev =>
      prev.map(s => {
        const scanResult = scanUrlSecurity(s.url);
        return {
          ...s,
          status: scanResult.riskLevel === 'danger' ? 'danger' : scanResult.riskLevel === 'warning' ? 'warning' : 'normal',
          lastScanResult: scanResult,
        };
      })
    );
    addLogEntry(currentUser?.id || 'SYSTEM', `全登録サイト (${sites.length}件) のマルウェア一括セキュリティ検査を実行`, 'scan', 'info');
    showToast(`全 ${sites.length} サイトのセキュリティ検査を実行しました`, 'success');
  }, [sites, currentUser, addLogEntry, showToast]);

  // Restriction Management
  const applyRestriction = useCallback(
    (type: RestrictionType, reason: string, durationMinutes: number): boolean => {
      if (!currentUser || currentUser.role !== 'L3') {
        showToast('🚫 権限がありません（制限の適用にはL3管理者権限が必要です）', 'error');
        addLogEntry(currentUser?.id || 'ANON', `制限適用試行の拒否: 権限不足 [ユーザー: ${currentUser?.id || '不明'}]`, 'restriction', 'error');
        return false;
      }

      // If Auto-Repel is active and this looks like a malicious lockdown, automatically repel!
      const recentRestrictionsByUser = restrictions.filter(r => r.appliedBy === currentUser.id).length;
      const isRapidMalicious = recentRestrictionsByUser >= 3 || type === 'revoke_admin';
      const evaluation = calculateRestrictionTrustScore(currentUser, recentRestrictionsByUser, isRapidMalicious);

      if (autoRepelShieldActive && evaluation.score < 40) {
        addLogEntry(
          'ANTI_LOCKDOWN_SHIELD',
          `🛡️ 低信頼（${evaluation.score}点）の不正制限適用を自動弾き返しシールドが遮断・無力化しました`,
          'emergency',
          'success'
        );
        showToast('🛡️ 自動反撃シールドが作動し、低信頼の不正制限を弾き返しました！', 'success');
        return false;
      }

      const typeLabels: Record<RestrictionType, string> = {
        full_lockdown: 'フルロックダウン（全ユーザーアクセス制限）',
        read_only: '読み取り専用モード',
        revoke_admin: '管理者権限剥奪制限',
        site_block: '特定サイトアクセス遮断',
      };

      const now = new Date();
      const expiresAt = new Date(now.getTime() + durationMinutes * 60 * 1000).toISOString();

      const newRestriction: Restriction = {
        id: `rest-${Date.now()}`,
        type,
        typeLabel: typeLabels[type] || type,
        reason: reason.trim() || 'セキュリティポリシーに基づく適用',
        appliedBy: currentUser.id,
        appliedByRole: currentUser.role,
        isCreatorVerified: currentUser.isVerified,
        appliedAt: now.toISOString(),
        durationMinutes,
        expiresAt,
        trustScore: evaluation.score,
        trustLevel: evaluation.level,
        status: emergencyOverrideActive ? 'bypassed' : 'active',
      };

      setRestrictions(prev => [newRestriction, ...prev]);
      addLogEntry(
        currentUser.id,
        `制限を適用: [${newRestriction.typeLabel}] 理由: ${newRestriction.reason} (信頼スコア: ${evaluation.score}点 - ${evaluation.level})`,
        'restriction',
        evaluation.score < 40 ? 'warning' : 'info'
      );

      if (evaluation.score < 40) {
        showToast(`⚠️ 信頼スコアが低いため（${evaluation.score}点）、この制限は全ユーザーによる即時解除が可能です`, 'warning');
      } else {
        showToast(`制限「${newRestriction.typeLabel}」を適用しました（有効期間: ${durationMinutes}分）`, 'success');
      }
      return true;
    },
    [currentUser, restrictions, emergencyOverrideActive, autoRepelShieldActive, addLogEntry, showToast]
  );

  const removeRestriction = useCallback(
    (id: string): boolean => {
      if (!currentUser) return false;
      const target = restrictions.find(r => r.id === id);
      if (!target) return false;

      const canDelete = isRestrictionDeletableBy(target, currentUser.role);
      if (!canDelete) {
        showToast('🚫 権限がありません（高信頼度の制限解除にはL3管理者権限が必要です）', 'error');
        addLogEntry(currentUser.id, `制限解除の試行が拒否されました [制限ID: ${id}]`, 'restriction', 'error');
        return false;
      }

      setRestrictions(prev => prev.filter(r => r.id !== id));
      addLogEntry(
        currentUser.id,
        `制限解除・削除完了: [${target.typeLabel}] (解除者: ${currentUser.id} [${currentUser.role}])`,
        'restriction',
        'info'
      );
      showToast('制限を解除・削除しました', 'success');
      return true;
    },
    [currentUser, restrictions, addLogEntry, showToast]
  );

  // User Management
  const addUser = useCallback(
    (name: string, id: string, password: string, role: UserRole, isVerified: boolean): boolean => {
      if (!currentUser || currentUser.role !== 'L3') {
        showToast('🚫 権限がありません（アカウント登録にはL3管理者権限が必要です）', 'error');
        return false;
      }

      if (users.some(u => u.id.toLowerCase() === id.toLowerCase())) {
        showToast('❌ 指定されたユーザーIDは既に登録されています', 'error');
        return false;
      }

      const newUser: User = {
        id: id.trim(),
        name: name.trim(),
        password: password.trim(),
        role,
        isVerified,
        createdAt: new Date().toISOString().substring(0, 10),
        failedLoginAttempts: 0,
        isRestricted: false,
      };

      setUsers(prev => [...prev, newUser]);
      addLogEntry(currentUser.id, `新規アカウント登録: ID=${newUser.id}, 権限=${role}`, 'admin', 'success');
      showToast(`アカウント「${newUser.name}」を登録しました`, 'success');
      return true;
    },
    [currentUser, users, addLogEntry, showToast]
  );

  const updateUserRole = useCallback(
    (targetUserId: string, newRole: UserRole): boolean => {
      if (!currentUser || currentUser.role !== 'L3') {
        showToast('🚫 権限がありません（権限変更にはL3管理者権限が必要です）', 'error');
        addLogEntry(currentUser?.id || 'ANON', `不正な権限変更試行を検知 [対象: ${targetUserId} -> ${newRole}]`, 'admin', 'error');
        return false;
      }

      setUsers(prev => prev.map(u => (u.id === targetUserId ? { ...u, role: newRole } : u)));
      addLogEntry(currentUser.id, `ユーザー権限変更: [${targetUserId}] -> ${newRole}`, 'admin', 'warning');
      showToast(`ユーザー「${targetUserId}」の権限を ${newRole} に変更しました`, 'success');
      return true;
    },
    [currentUser, addLogEntry, showToast]
  );

  const deleteUser = useCallback(
    (targetUserId: string): boolean => {
      if (!currentUser || currentUser.role !== 'L3') {
        showToast('🚫 権限がありません', 'error');
        return false;
      }

      if (targetUserId === 'admin') {
        showToast('⚠️ 初期管理者アカウント「admin」は保護されています', 'warning');
        return false;
      }

      setUsers(prev => prev.filter(u => u.id !== targetUserId));
      addLogEntry(currentUser.id, `アカウント削除: [${targetUserId}]`, 'admin', 'warning');
      showToast(`アカウント「${targetUserId}」を削除しました`, 'info');
      return true;
    },
    [currentUser, addLogEntry, showToast]
  );

  const toggleUserVerified = useCallback(
    (targetUserId: string): boolean => {
      if (!currentUser || currentUser.role !== 'L3') {
        showToast('🚫 権限がありません', 'error');
        return false;
      }
      setUsers(prev =>
        prev.map(u => (u.id === targetUserId ? { ...u, isVerified: !u.isVerified } : u))
      );
      addLogEntry(currentUser.id, `ユーザー信頼度検証フラグ変更: [${targetUserId}]`, 'admin', 'info');
      showToast(`検証ステータスを切り替えました`, 'success');
      return true;
    },
    [currentUser, addLogEntry, showToast]
  );

  const tamperLog = useCallback(
    (logId: string) => {
      setLogs(prev =>
        prev.map(l => {
          if (l.id === logId) {
            return {
              ...l,
              action: `${l.action} 【改ざんテスト: ハッカーにより操作内容が変更されました】`,
              isTampered: true,
            };
          }
          return l;
        })
      );
      showToast('⚠️ ログの内容を改ざんしました。CRC-32チェックサム不整合が検知されます！', 'warning');
    },
    [showToast]
  );

  const exportJsonBackup = useCallback(() => {
    const backupData = {
      exportedAt: new Date().toISOString(),
      system: 'MLSMD (Multi-Layer Security Site Management Dashboard)',
      users: users.map(u => ({ ...u, password: '***' })),
      sites,
      restrictions,
      logs,
      emergencyOverrideActive,
      autoRepelShieldActive,
    };
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const a = document.createElement('a');
    a.setAttribute('href', dataStr);
    a.setAttribute('download', `site-manager-backup-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
    document.body.appendChild(a);
    a.click();
    a.remove();
    showToast('📥 データをJSON形式でエクスポートしました', 'success');
  }, [users, sites, restrictions, logs, emergencyOverrideActive, autoRepelShieldActive, showToast]);

  const importJsonBackup = useCallback(
    (jsonContent: string): boolean => {
      try {
        const parsed = JSON.parse(jsonContent);
        if (parsed.sites && Array.isArray(parsed.sites)) setSites(parsed.sites);
        if (parsed.restrictions && Array.isArray(parsed.restrictions)) setRestrictions(parsed.restrictions);
        if (parsed.logs && Array.isArray(parsed.logs)) setLogs(parsed.logs);
        addLogEntry(currentUser?.id || 'SYSTEM', 'JSONバックアップからシステムデータを復元しました', 'system', 'success');
        showToast('JSONバックアップからの復元に成功しました', 'success');
        return true;
      } catch (e) {
        showToast('❌ JSONバックアップの解析に失敗しました', 'error');
        return false;
      }
    },
    [currentUser, addLogEntry, showToast]
  );

  const downloadStandaloneHtml = useCallback(() => {
    const htmlContent = generateStandaloneSecurityHtml();
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'site-manager-security.html';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showToast('📥 単一HTMLファイル（site-manager-security.html）をダウンロードしました', 'success');
  }, [showToast]);

  const resetToDefaults = useCallback(() => {
    setUsers(INITIAL_USERS);
    setSites([]);
    setRestrictions([]);
    setLogs(INITIAL_LOGS);
    setEmergencyOverrideActive(false);
    setAutoRepelShieldActive(true);
    showToast('システムデータを初期クリーン状態にリセットしました', 'info');
  }, [showToast]);

  // Optional Helper to seed sample data if user ever wants to inspect populated charts
  const seedDemoData = useCallback(() => {
    const demoSites: Site[] = [
      {
        id: 'site-demo-1',
        name: '企業コーポレートサイト',
        url: 'https://corporate.example.com',
        category: 'コーポレート',
        notes: '本番コーポレートWeb',
        addedBy: currentUser?.id || 'admin',
        isVerified: true,
        status: 'normal',
        createdAt: new Date().toISOString().substring(0, 10),
        lastScanResult: {
          scannedAt: new Date().toISOString(),
          riskLevel: 'safe',
          riskScore: 0,
          issues: ['正常なHTTPSプロトコルです。脆弱性は検出されませんでした。'],
          isHttps: true,
          hasRiskyExt: false,
          isShortUrl: false,
          hasSuspiciousKeywords: false,
          isSuspiciousIdn: false,
          isRiskyTld: false,
        },
      },
    ];
    setSites(demoSites);
    showToast('サンプルサイトデータを投入しました', 'info');
  }, [currentUser, showToast]);

  // Test Scenarios
  const runTestScenario = useCallback(
    (scenarioId: number) => {
      switch (scenarioId) {
        case 1: {
          const now = new Date();
          const lockdownRest: Restriction = {
            id: `rest-lockdown-${Date.now()}`,
            type: 'full_lockdown',
            typeLabel: 'フルロックダウン（ハッカーによる全閉鎖）',
            reason: '悪意ある第三者による全システム強制遮断攻撃',
            appliedBy: 'hacker_infiltrator',
            appliedByRole: 'L3',
            isCreatorVerified: false,
            appliedAt: now.toISOString(),
            durationMinutes: 120,
            expiresAt: new Date(now.getTime() + 120 * 60 * 1000).toISOString(),
            trustScore: 20,
            trustLevel: 'low',
            status: 'active',
          };
          setRestrictions(prev => [lockdownRest, ...prev]);
          addLogEntry('hacker_infiltrator', '【テスト1】ハッカーによるフルロックダウン制限が適用されました', 'restriction', 'error');
          showToast('【テスト1実行】フルロックダウンがかけられました。「ハッカー制限を強制弾き返し」またはマスターキーで復旧できます！', 'warning');
          break;
        }
        case 2: {
          const now = new Date();
          const suspiciousRest: Restriction = {
            id: `rest-malicious-${Date.now()}`,
            type: 'full_lockdown',
            typeLabel: '不正なフルロックダウン',
            reason: '未検証アカウントによる業務妨害',
            appliedBy: 'unverified_bot',
            appliedByRole: 'L3',
            isCreatorVerified: false,
            appliedAt: now.toISOString(),
            durationMinutes: 60,
            expiresAt: new Date(now.getTime() + 60 * 60 * 1000).toISOString(),
            trustScore: 35,
            trustLevel: 'low',
            status: 'active',
          };
          setRestrictions(prev => [suspiciousRest, ...prev]);
          addLogEntry('unverified_bot', '【テスト2】未検証アカウントが制限を適用。信頼スコア35点（低信頼）と判定されました', 'restriction', 'warning');
          showToast('【テスト2実行】信頼スコア35点の不正制限を追加。L1/L2を含む誰でも即座に解除可能です。', 'warning');
          break;
        }
        case 3: {
          const badUrl = 'https://bit.ly/malicious-payload-installer.exe';
          const scanRes = scanUrlSecurity(badUrl);
          const newSite: Site = {
            id: `site-test-${Date.now()}`,
            name: '危険なダウンロードリンク [テスト3]',
            url: badUrl,
            category: '脅威テスト',
            notes: 'テスト用の短縮URLと実行ファイル',
            addedBy: currentUser?.id || 'admin',
            isVerified: false,
            status: 'danger',
            createdAt: new Date().toISOString().substring(0, 10),
            lastScanResult: scanRes,
          };
          setSites(prev => [newSite, ...prev]);
          addLogEntry(currentUser?.id || 'admin', `【テスト3】悪意あるURL「${badUrl}」が登録され、マルウェアスキャナが「危険」と判定しました`, 'scan', 'error');
          showToast('【テスト3実行】短縮URL+実行ファイルが追加され、マルウェアスキャナが危険を検出しました！', 'error');
          break;
        }
        case 4: {
          addLogEntry('hacker123', '未登録ID「hacker123」でのログイン試行が拒否されました (不明)', 'login', 'error');
          addLogEntry('hacker123', '未登録ID「hacker123」でのログイン試行が拒否されました (不明)', 'login', 'error');
          showToast('【テスト4実行】未登録ID「hacker123」でのログイン拒否ログを記録しました（アカウント存在の有無を隠蔽）', 'info');
          break;
        }
      }
    },
    [currentUser, addLogEntry, showToast]
  );

  // Compute Threat Patterns from real data
  const threatPatterns = useMemo<ThreatPattern[]>(() => {
    const userRestrictionCounts: Record<string, number> = {};
    restrictions.forEach(r => {
      userRestrictionCounts[r.appliedBy] = (userRestrictionCounts[r.appliedBy] || 0) + 1;
    });
    const spamUsers = Object.entries(userRestrictionCounts).filter(([_, count]) => count >= 3);
    const failedLogins = logs.filter(l => l.category === 'login' && l.severity === 'error');
    const tamperedLogs = logs.filter(l => {
      if (l.isTampered) return true;
      return !verifyLogIntegrity(l.timestamp, l.operatorId, l.action, l.category, l.checksum);
    });
    const unauthorizedPermAttempts = logs.filter(l => l.action.includes('権限変更試行') || l.action.includes('権限不足'));
    const unverifiedRestrictions = restrictions.filter(r => !r.isCreatorVerified && r.status === 'active');

    return [
      {
        id: 'pat-1',
        title: '短時間に複数の制限をかける（ロックダウンスパム）',
        description: '同一ユーザーによる異常な連続制限適用をリアルタイム検知',
        severity: 'red',
        isActive: spamUsers.length > 0,
        count: spamUsers.reduce((acc, [_, c]) => acc + c, 0),
      },
      {
        id: 'pat-2',
        title: '管理者以外による権限変更の試み',
        description: 'L1/L2アカウントによる特権昇格や他アカウント改変操作の遮断',
        severity: 'red',
        isActive: unauthorizedPermAttempts.length > 0,
        count: unauthorizedPermAttempts.length,
      },
      {
        id: 'pat-3',
        title: 'ログの改ざん試行（CRC-32ハッシュ不整合）',
        description: '改ざん防止ログのハッシュ不一致を瞬時に特定',
        severity: 'red',
        isActive: tamperedLogs.length > 0,
        count: tamperedLogs.length,
      },
      {
        id: 'pat-4',
        title: 'ログイン試行の連続失敗（ブルートフォース/ID列挙）',
        description: '連続ログイン失敗および未登録IDへの総当たりを監視',
        severity: 'yellow',
        isActive: failedLogins.length >= 3,
        count: failedLogins.length,
      },
      {
        id: 'pat-5',
        title: '未検証アカウントによる高権限制限の適用',
        description: '未認証ユーザーによる不当な操作を検知',
        severity: 'yellow',
        isActive: unverifiedRestrictions.length > 0,
        count: unverifiedRestrictions.length,
      },
      {
        id: 'pat-6',
        title: '不規則な時間帯・異常URLの登録',
        description: '短縮URLや高リスク拡張子を含むサイト登録をリアルタイム捕捉',
        severity: 'yellow',
        isActive: sites.some(s => s.status === 'danger'),
        count: sites.filter(s => s.status === 'danger').length,
      },
    ];
  }, [restrictions, logs, sites]);

  // Compute System Stats
  const stats = useMemo<SystemStats>(() => {
    const activeRes = restrictions.filter(r => r.status === 'active');
    const suspiciousRes = activeRes.filter(r => r.trustScore < 40);
    const verifiedAcc = users.filter(u => u.isVerified).length;
    const detectedAnomalies = threatPatterns.filter(p => p.isActive).length;

    let secScore = 100;
    secScore -= suspiciousRes.length * 20;
    secScore -= detectedAnomalies * 10;
    if (sites.some(s => s.status === 'danger')) secScore -= 15;
    if (emergencyOverrideActive) secScore = Math.min(secScore, 75);
    secScore = Math.max(10, Math.min(100, secScore));

    let systemStatus: 'normal' | 'warning' | 'danger' = 'normal';
    if (secScore < 50 || suspiciousRes.length > 0 || threatPatterns.some(p => p.severity === 'red' && p.isActive)) {
      systemStatus = 'danger';
    } else if (secScore < 80 || detectedAnomalies > 0) {
      systemStatus = 'warning';
    }

    return {
      securityScore: secScore,
      activeRestrictions: activeRes.length,
      suspiciousRestrictions: suspiciousRes.length,
      verifiedAccounts: verifiedAcc,
      totalSites: sites.length,
      systemStatus,
      detectedAnomaliesCount: detectedAnomalies,
      emergencyOverrideActive,
      autoRepelShieldActive,
    };
  }, [restrictions, users, threatPatterns, sites, emergencyOverrideActive, autoRepelShieldActive]);

  return (
    <SecurityContext.Provider
      value={{
        currentUser,
        emergencyOverrideActive,
        autoRepelShieldActive,
        users,
        sites,
        restrictions,
        logs,
        threatPatterns,
        stats,
        toastMessage,
        showToast,
        login,
        logout,
        registerNewAccount,
        emergencyMasterKeyOverride,
        dismissEmergencyOverride,
        repelLockdownAndRestore,
        toggleAutoRepelShield,
        addSite,
        updateSite,
        deleteSite,
        scanSite,
        scanAllSites,
        applyRestriction,
        removeRestriction,
        addUser,
        updateUserRole,
        deleteUser,
        toggleUserVerified,
        tamperLog,
        exportJsonBackup,
        importJsonBackup,
        downloadStandaloneHtml,
        resetToDefaults,
        seedDemoData,
        runTestScenario,
      }}
    >
      {children}
    </SecurityContext.Provider>
  );
};

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (!context) {
    throw new Error('useSecurity must be used within a SecurityProvider');
  }
  return context;
};
