/**
 * Real CRC-32 (IEEE 802.3) Checksum implementation for tamper-evident logging.
 */

// Pre-computed CRC-32 table
const CRC32_TABLE: Uint32Array = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

export function calculateCRC32(data: string): string {
  let crc = 0xffffffff;
  const utf8Bytes = new TextEncoder().encode(data);
  for (let i = 0; i < utf8Bytes.length; i++) {
    crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ utf8Bytes[i]) & 0xff];
  }
  const result = (crc ^ 0xffffffff) >>> 0;
  return result.toString(16).toUpperCase().padStart(8, '0');
}

/**
 * Generates canonical payload string for a log entry to compute checksum
 */
export function getLogPayloadString(
  timestamp: string,
  operatorId: string,
  action: string,
  category: string
): string {
  return `${timestamp}::${operatorId}::${action}::${category}`;
}

/**
 * Verifies if the log's checksum matches the expected calculated CRC-32
 */
export function verifyLogIntegrity(
  timestamp: string,
  operatorId: string,
  action: string,
  category: string,
  storedChecksum: string
): boolean {
  const expectedChecksum = calculateCRC32(
    getLogPayloadString(timestamp, operatorId, action, category)
  );
  return expectedChecksum === storedChecksum;
}
