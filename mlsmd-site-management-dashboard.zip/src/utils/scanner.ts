import { MalwareScanResult } from '../types/security';

const DANGEROUS_EXTENSIONS = [
  '.exe', '.scr', '.bat', '.zip', '.vbs', '.apk', '.cmd', '.ps1', '.msi', '.pif', '.hta'
];

const SHORTENED_DOMAINS = [
  'bit.ly', 'tinyurl.com', 't.co', 'is.gd', 'buff.ly', 'goo.gl', 'ow.ly', 'rebrand.ly', 'cutt.ly'
];

const SUSPICIOUS_KEYWORDS = [
  'free-download', 'login-verify', 'secure-bank', 'payload', 'crack', 'keygen',
  'free-gift', 'account-update', 'phishing', 'claim-reward', 'unlock-pass', 'spyware'
];

const HIGH_RISK_TLDS = [
  '.ru', '.top', '.xyz', '.click', '.work', '.cn', '.su', '.tk', '.ml', '.ga'
];

export function scanUrlSecurity(rawUrl: string): MalwareScanResult {
  const issues: string[] = [];
  let riskScore = 0; // 0: safe, 100: severe danger

  const lowerUrl = (rawUrl || '').trim().toLowerCase();

  // 1. Protocol check
  const isHttps = lowerUrl.startsWith('https://');
  if (!isHttps) {
    if (lowerUrl.startsWith('http://')) {
      issues.push('暗号化されていないHTTPプロトコルが使用されています（通信傍受・改ざんリスク）');
      riskScore += 25;
    } else {
      issues.push('プロトコル（https://）が明示されていません');
      riskScore += 20;
    }
  }

  // 2. Dangerous extension check
  const hasRiskyExt = DANGEROUS_EXTENSIONS.some(ext => lowerUrl.includes(ext));
  if (hasRiskyExt) {
    const matched = DANGEROUS_EXTENSIONS.filter(ext => lowerUrl.includes(ext));
    issues.push(`既知の危険な実行ファイル・アーカイブ拡張子 (${matched.join(', ')}) が検出されました`);
    riskScore += 45;
  }

  // 3. Shortened URL check
  const isShortUrl = SHORTENED_DOMAINS.some(domain => lowerUrl.includes(domain));
  if (isShortUrl) {
    issues.push('短縮URLサービス（リダイレクト追跡困難・フィッシング悪用リスク）が検出されました');
    riskScore += 35;
  }

  // 4. Malware keywords
  const hasSuspiciousKeywords = SUSPICIOUS_KEYWORDS.some(kw => lowerUrl.includes(kw));
  if (hasSuspiciousKeywords) {
    const matched = SUSPICIOUS_KEYWORDS.filter(kw => lowerUrl.includes(kw));
    issues.push(`マルウェア・フィッシング頻出キーワード (${matched.join(', ')}) が含まれています`);
    riskScore += 40;
  }

  // 5. IDN Homograph / Punycode check
  const isSuspiciousIdn = lowerUrl.includes('xn--');
  if (isSuspiciousIdn) {
    issues.push('IDNホモグラフ攻撃（キリル文字等の偽装ドメイン xn--）の兆候が検出されました');
    riskScore += 35;
  }

  // 6. High risk TLD
  let domainPart = '';
  try {
    const parsed = new URL(lowerUrl.startsWith('http') ? lowerUrl : `https://${lowerUrl}`);
    domainPart = parsed.hostname;
  } catch {
    domainPart = lowerUrl;
  }

  const isRiskyTld = HIGH_RISK_TLDS.some(tld => domainPart.endsWith(tld));
  if (isRiskyTld) {
    const matched = HIGH_RISK_TLDS.filter(tld => domainPart.endsWith(tld));
    issues.push(`不正ドメイン多発TLD (${matched.join(', ')}) が使用されています`);
    riskScore += 30;
  }

  // Determine overall risk level
  let riskLevel: 'safe' | 'warning' | 'danger' = 'safe';
  if (riskScore >= 45 || hasRiskyExt || (isShortUrl && hasSuspiciousKeywords)) {
    riskLevel = 'danger';
  } else if (riskScore > 0 || !isHttps) {
    riskLevel = 'warning';
  }

  return {
    scannedAt: new Date().toISOString(),
    riskLevel,
    riskScore: Math.min(100, riskScore),
    issues: issues.length > 0 ? issues : ['セキュリティチェックをすべてクリアしました。安全と判定されました。'],
    isHttps,
    hasRiskyExt,
    isShortUrl,
    hasSuspiciousKeywords,
    isSuspiciousIdn,
    isRiskyTld,
  };
}
