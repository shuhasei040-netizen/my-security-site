/**
 * Generates a self-contained, standalone single HTML file (site-manager-security.html)
 * styled like Firebase Console with Anti-Lockdown Repel Shield, user self-registration,
 * and clean starting state (0 sites, 0 restrictions).
 */

export function generateStandaloneSecurityHtml(): string {
  return `<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>🛡️ Firebase Security Console - MLSMD</title>
  <style>
    :root {
      --bg-dark: #0a101d;
      --panel-bg: #111726;
      --panel-sec: #0c1222;
      --border-color: #1f2b45;
      --text-main: #e8ecf6;
      --text-sub: #8b96b8;
      --fb-amber: #ffa000;
      --fb-orange: #f57c00;
      --fb-blue: #1a73e8;
      --color-success: #3ddc97;
      --color-warning: #ffb547;
      --color-danger: #ff5c7a;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg-dark);
      color: var(--text-main);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Hiragino Kaku Gothic ProN', Meiryo, sans-serif;
      font-size: 13px;
      line-height: 1.5;
    }
    a { color: var(--fb-blue); text-decoration: none; }
    button, input, select, textarea { font-family: inherit; font-size: inherit; }

    /* Layout */
    #app-container { display: flex; min-height: 100vh; }
    #sidebar {
      width: 256px;
      background: var(--panel-bg);
      border-right: 1px solid var(--border-color);
      display: flex;
      flex-direction: column;
      flex-shrink: 0;
    }
    #main-content { flex: 1; display: flex; flex-direction: column; overflow-x: hidden; }

    /* Header */
    .top-header {
      padding: 12px 24px;
      background: var(--panel-bg);
      border-bottom: 1px solid var(--border-color);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .header-breadcrumb { font-size: 11px; color: var(--fb-amber); font-weight: 500; margin-bottom: 2px; }
    .header-title { font-size: 16px; font-weight: 700; color: var(--text-main); }

    /* Content Area */
    .page-body { padding: 24px; flex: 1; max-width: 1200px; width: 100%; margin: 0 auto; }

    /* Cards */
    .card-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 24px;
    }
    .stat-card {
      background: var(--panel-bg);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      padding: 18px;
    }
    .stat-label { font-size: 12px; color: var(--text-sub); margin-bottom: 4px; }
    .stat-val { font-size: 26px; font-weight: bold; }

    /* Tables */
    .data-table-wrap {
      background: var(--panel-bg);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      overflow-x: auto;
    }
    table { width: 100%; border-collapse: collapse; text-align: left; }
    th {
      background: var(--panel-sec);
      padding: 12px 16px;
      font-weight: 600;
      color: var(--text-sub);
      border-bottom: 1px solid var(--border-color);
      font-size: 12px;
    }
    td {
      padding: 12px 16px;
      border-bottom: 1px solid var(--border-color);
    }
    tr:last-child td { border-bottom: none; }
    tr:hover { background: rgba(255, 160, 0, 0.03); }

    /* Buttons */
    .btn {
      padding: 8px 16px;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      border: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all 0.2s ease;
      font-size: 12px;
    }
    .btn-primary {
      background: linear-gradient(135deg, var(--fb-amber), #ffb300);
      color: #0a101d;
    }
    .btn-primary:hover { opacity: 0.95; }
    .btn-secondary {
      background: var(--panel-sec);
      color: var(--text-main);
      border: 1px solid var(--border-color);
    }
    .btn-secondary:hover { background: #1a233a; }
    .btn-danger {
      background: #ff5c7a;
      color: white;
    }
    .btn-danger:hover { background: #e63946; }
    .btn-repel {
      background: rgba(255, 92, 122, 0.15);
      color: #ff5c7a;
      border: 1px solid rgba(255, 92, 122, 0.4);
    }
    .btn-repel:hover { background: rgba(255, 92, 122, 0.25); }
    .btn-sm { padding: 4px 10px; font-size: 11px; }

    /* Badges & Tags */
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: 600;
    }
    .badge-success { background: rgba(61, 220, 151, 0.15); color: var(--color-success); border: 1px solid rgba(61, 220, 151, 0.3); }
    .badge-warning { background: rgba(255, 160, 0, 0.15); color: var(--fb-amber); border: 1px solid rgba(255, 160, 0, 0.3); }
    .badge-danger { background: rgba(255, 92, 122, 0.15); color: var(--color-danger); border: 1px solid rgba(255, 92, 122, 0.3); }
    .badge-info { background: rgba(26, 115, 232, 0.15); color: var(--fb-blue); border: 1px solid rgba(26, 115, 232, 0.3); }

    /* Modals */
    .modal-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,0.75);
      display: none; align-items: center; justify-content: center; z-index: 999;
    }
    .modal-box {
      background: var(--panel-bg);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      width: 90%; max-width: 520px;
      padding: 24px;
      box-shadow: 0 20px 40px rgba(0,0,0,0.6);
    }
    .form-group { margin-bottom: 14px; }
    .form-label { display: block; font-size: 12px; margin-bottom: 5px; color: var(--text-sub); font-weight: 500; }
    .form-input {
      width: 100%; padding: 8px 12px;
      background: var(--panel-sec);
      border: 1px solid var(--border-color);
      color: var(--text-main);
      border-radius: 8px;
    }
    .form-input:focus { outline: none; border-color: var(--fb-amber); }

    /* Emergency Alert Banner */
    .emergency-banner {
      background: linear-gradient(90deg, #b71c1c, #d32f2f, #f44336);
      color: white; padding: 10px 24px;
      display: flex; align-items: center; justify-content: space-between;
      font-weight: 600; font-size: 12px;
    }

    /* Auth Screen */
    #auth-screen {
      position: fixed; inset: 0;
      background: radial-gradient(circle at center, #111726 0%, #0a101d 100%);
      display: flex; align-items: center; justify-content: center;
      z-index: 1000;
    }
    .auth-card {
      background: var(--panel-bg);
      border: 1px solid var(--border-color);
      border-radius: 16px;
      padding: 32px; width: 100%; max-width: 440px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.5);
      position: relative; overflow: hidden;
    }
    .auth-card::before {
      content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
      background: linear-gradient(90deg, #f57c00, #ffa000, #ffca28);
    }

    /* Sidebar Navigation */
    .nav-section-title {
      padding: 8px 16px 4px 16px;
      font-size: 10px; font-weight: 700;
      color: rgba(139, 150, 184, 0.7);
      text-transform: uppercase; letter-spacing: 0.5px;
    }
    .nav-item {
      padding: 9px 16px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: var(--text-sub);
      transition: all 0.15s ease;
      font-weight: 500;
      border-radius: 6px;
      margin: 1px 8px;
    }
    .nav-item:hover { color: var(--text-main); background: #1a233a; }
    .nav-item.active {
      color: white;
      background: var(--fb-blue);
      font-weight: 600;
    }

    /* Empty state */
    .empty-state {
      padding: 48px 24px;
      text-align: center;
      background: var(--panel-bg);
      border: 1px solid var(--border-color);
      border-radius: 12px;
      max-width: 600px;
      margin: 24px auto;
    }
    .empty-icon { font-size: 40px; margin-bottom: 12px; }

    /* Responsive */
    @media (max-width: 768px) {
      #app-container { flex-direction: column; }
      #sidebar { width: 100%; border-right: none; border-bottom: 1px solid var(--border-color); }
    }
  </style>
</head>
<body>

  <!-- AUTH SCREEN (Firebase Console Auth) -->
  <div id="auth-screen">
    <div class="auth-card">
      <div style="text-align: center; margin-bottom: 20px;">
        <div style="font-size: 32px; margin-bottom: 6px;">🔥</div>
        <h1 style="font-size: 18px; font-weight: bold; margin-bottom: 2px;">Firebase Security Console</h1>
        <p style="color: var(--text-sub); font-size: 11px;">Multi-Layer Security Site Management Dashboard (MLSMD)</p>
      </div>

      <!-- Tab toggle: Login vs Register -->
      <div style="display: flex; background: var(--panel-sec); padding: 3px; border-radius: 8px; margin-bottom: 18px; border: 1px solid var(--border-color);">
        <button type="button" id="tab-btn-login" onclick="toggleAuthTab('login')" class="btn btn-sm" style="flex: 1; justify-content: center; background: var(--fb-blue); color: white;">
          ログイン
        </button>
        <button type="button" id="tab-btn-reg" onclick="toggleAuthTab('reg')" class="btn btn-sm" style="flex: 1; justify-content: center; background: transparent; color: var(--text-sub);">
          新規アカウント作成
        </button>
      </div>

      <div id="login-alert" style="display: none; padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; font-size: 12px; font-weight: 600;"></div>

      <!-- Login Form -->
      <form id="login-form" onsubmit="handleLogin(event)">
        <div class="form-group">
          <label class="form-label">ユーザーID</label>
          <input type="text" id="login-user" class="form-input" placeholder="例: admin または 作成したID" required>
        </div>
        <div class="form-group">
          <label class="form-label">パスワード または マスターキー</label>
          <input type="password" id="login-pass" class="form-input" placeholder="パスワードまたはMASTER-2024-OVERRIDE" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 10px; font-size: 13px;">
          コンソールにログイン
        </button>
      </form>

      <!-- Register Form -->
      <form id="reg-form" onsubmit="handleRegister(event)" style="display: none;">
        <div class="form-group">
          <label class="form-label">希望のユーザーID（英数字）</label>
          <input type="text" id="reg-user" class="form-input" placeholder="例: user_project" required>
        </div>
        <div class="form-group">
          <label class="form-label">表示名（お名前/役職）</label>
          <input type="text" id="reg-name" class="form-input" placeholder="例: サイト責任者 佐藤" required>
        </div>
        <div class="form-group">
          <label class="form-label">パスワード</label>
          <input type="password" id="reg-pass" class="form-input" placeholder="パスワード" required>
        </div>
        <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center; padding: 10px; font-size: 13px; background: linear-gradient(135deg, var(--fb-orange), var(--fb-amber));">
          アカウントを作成して開始
        </button>
      </form>

      <!-- Anti-Lockdown Repel Shield Quick Action on Login -->
      <div style="margin-top: 20px; padding: 12px; background: rgba(255, 92, 122, 0.08); border-radius: 8px; border: 1px solid rgba(255, 92, 122, 0.3);">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div>
            <div style="color: var(--color-danger); font-weight: bold; font-size: 11px;">🛡️ ハッカー制限強制弾き返し</div>
            <div style="font-size: 10px; color: var(--text-sub);">制限・ロックダウンをワンクリックで弾き返し復旧</div>
          </div>
          <button onclick="repelLockdownNow()" class="btn btn-danger btn-sm">強制解除</button>
        </div>
      </div>

      <div style="margin-top: 12px; text-align: center; font-size: 11px; color: var(--text-sub);">
        初期管理者: <code>admin</code> / <code>admin123</code>
      </div>
    </div>
  </div>

  <!-- MAIN APP CONTAINER -->
  <div id="app-container" style="display: none;">
    <!-- SIDEBAR -->
    <div id="sidebar">
      <div style="padding: 16px 20px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 10px;">
        <span style="font-size: 24px;">🔥</span>
        <div>
          <div style="font-weight: bold; font-size: 14px;">Firebase Security</div>
          <div style="font-size: 10px; color: var(--fb-amber); font-family: monospace;">project-site-guard-prod</div>
        </div>
      </div>

      <!-- Repel Shield Banner in Sidebar -->
      <div style="margin: 12px 12px 0 12px; padding: 10px; background: var(--panel-sec); border-radius: 8px; border: 1px solid var(--border-color);">
        <div style="display: flex; justify-content: space-between; align-items: center; font-size: 11px;">
          <span style="color: var(--text-sub);">反撃シールド:</span>
          <span style="color: var(--color-success); font-weight: bold;">● 有効</span>
        </div>
        <button onclick="repelLockdownNow()" class="btn btn-repel btn-sm" style="width: 100%; margin-top: 6px; justify-content: center; font-size: 10px;">
          🛡️ ハッカー制限を強制弾き返し
        </button>
      </div>

      <nav style="padding: 12px 0; flex: 1;">
        <div class="nav-section-title">概要</div>
        <div class="nav-item active" onclick="switchTab('dashboard')">📊 プロジェクト概要</div>

        <div class="nav-section-title" style="margin-top: 10px;">ホスティング & サイト</div>
        <div class="nav-item" onclick="switchTab('sites')">🌐 管理Webサイト</div>

        <div class="nav-section-title" style="margin-top: 10px;">セキュリティ & ルール</div>
        <div class="nav-item" onclick="switchTab('restrictions')">🔒 セキュリティルール・制限</div>
        <div class="nav-item" onclick="switchTab('audit')">🔍 監査・脅威検知</div>

        <div class="nav-section-title" style="margin-top: 10px;">IAM & ログ</div>
        <div class="nav-item" onclick="switchTab('accounts')">👤 Authentication</div>
        <div class="nav-item" onclick="switchTab('logs')">📜 Cloud Logging (改ざん防止)</div>

        <div class="nav-section-title" style="margin-top: 10px;">構成</div>
        <div class="nav-item" onclick="switchTab('settings')">⚙️ プロジェクト設定</div>
      </nav>

      <div style="padding: 14px; border-top: 1px solid var(--border-color); background: var(--panel-sec);">
        <div style="font-size: 10px; color: var(--text-sub);">認証済みアカウント:</div>
        <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 4px;">
          <div style="font-weight: bold; font-size: 12px;" id="current-user-name">admin</div>
          <span class="badge badge-info" id="current-user-role">L3 管理者</span>
        </div>
        <button onclick="handleLogout()" class="btn btn-secondary btn-sm" style="width: 100%; margin-top: 8px; justify-content: center;">
          コンソールからログアウト
        </button>
      </div>
    </div>

    <!-- MAIN CONTENT -->
    <div id="main-content">
      <div id="emergency-banner-box" class="emergency-banner" style="display: none;">
        <span>🚨 EMERGENCY OVERRIDE：すべての制限を弾き返し「無視モード」に変更しています。</span>
        <button onclick="dismissEmergency()" class="btn btn-secondary btn-sm" style="background: rgba(0,0,0,0.4); color: white; border: none;">通常モードへ復帰</button>
      </div>

      <div class="top-header">
        <div>
          <div class="header-breadcrumb" id="page-breadcrumb">Firebase / site-security-prod / Overview</div>
          <div class="header-title" id="page-heading">📊 プロジェクト概要</div>
        </div>
        <div style="display: flex; gap: 8px;">
          <button onclick="repelLockdownNow()" class="btn btn-repel btn-sm">🛡️ 制限を強制弾き返し</button>
          <button onclick="exportJsonData()" class="btn btn-secondary btn-sm">📥 JSONエクスポート</button>
        </div>
      </div>

      <div class="page-body" id="tab-content">
        <!-- Rendered by JS -->
      </div>
    </div>
  </div>

  <!-- Modal for Adding Site -->
  <div id="site-modal" class="modal-overlay">
    <div class="modal-box">
      <h3 style="font-size: 15px; font-weight: bold; margin-bottom: 14px;">+ 管理Webサイトの追加</h3>
      <form onsubmit="handleSiteSubmit(event)">
        <div class="form-group">
          <label class="form-label">サイト名</label>
          <input type="text" id="modal-site-name" class="form-input" placeholder="例: コーポレート本番サイト" required>
        </div>
        <div class="form-group">
          <label class="form-label">サイトURL（https:// 推奨）</label>
          <input type="text" id="modal-site-url" class="form-input" placeholder="https://example.com" required>
        </div>
        <div class="form-group">
          <label class="form-label">カテゴリ</label>
          <input type="text" id="modal-site-cat" class="form-input" placeholder="例: 本番サイト, EC, 社内ポータル">
        </div>
        <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 18px;">
          <button type="button" onclick="closeSiteModal()" class="btn btn-secondary">キャンセル</button>
          <button type="submit" class="btn btn-primary">登録してセキュリティ検査を実行</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    // CRC-32 Implementation
    const CRC_TABLE = (function() {
      let c, table = [];
      for(let n = 0; n < 256; n++) {
        c = n;
        for(let k = 0; k < 8; k++) {
          c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
        }
        table[n] = c;
      }
      return table;
    })();

    function crc32(str) {
      let crc = 0 ^ (-1);
      const utf8 = unescape(encodeURIComponent(str));
      for (let i = 0; i < utf8.length; i++) {
        crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ utf8.charCodeAt(i)) & 0xFF];
      }
      return ((crc ^ (-1)) >>> 0).toString(16).toUpperCase().padStart(8, '0');
    }

    // CLEAN INITIAL DATA: 0 sites, 0 restrictions by default!
    const DEFAULT_DATA = {
      currentUser: null,
      emergencyOverride: false,
      autoRepelActive: true,
      users: [
        { id: 'admin', name: 'システム管理者 (Admin)', role: 'L3', isVerified: true, pass: 'admin123', createdAt: new Date().toISOString().substring(0, 10) }
      ],
      sites: [],
      restrictions: [],
      logs: [
        {
          id: 'l1',
          timestamp: new Date().toISOString().replace('T', ' ').substring(0, 23),
          operatorId: 'SYSTEM',
          action: 'Firebase Security Console 初期化完了（クリーン状態・反撃シールド待機中）',
          category: 'system',
          checksum: '',
          isTampered: false
        }
      ]
    };

    let state = JSON.parse(localStorage.getItem('mlsmd_firebase_clean_v2')) || DEFAULT_DATA;
    if (!state.logs[0].checksum) {
      state.logs[0].checksum = crc32(state.logs[0].timestamp + '::' + state.logs[0].operatorId + '::' + state.logs[0].action + '::' + state.logs[0].category);
    }

    function saveState() {
      localStorage.setItem('mlsmd_firebase_clean_v2', JSON.stringify(state));
    }

    function addLog(operatorId, action, category) {
      const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 23);
      const payload = timestamp + '::' + operatorId + '::' + action + '::' + category;
      const checksum = crc32(payload);
      state.logs.unshift({
        id: 'l_' + Date.now() + Math.random().toString(36).substr(2, 4),
        timestamp,
        operatorId,
        action,
        category,
        checksum,
        isTampered: false
      });
      if (state.logs.length > 5000) state.logs.pop();
      saveState();
    }

    function toggleAuthTab(tab) {
      const loginForm = document.getElementById('login-form');
      const regForm = document.getElementById('reg-form');
      const loginBtn = document.getElementById('tab-btn-login');
      const regBtn = document.getElementById('tab-btn-reg');
      const alertBox = document.getElementById('login-alert');
      alertBox.style.display = 'none';

      if (tab === 'login') {
        loginForm.style.display = 'block';
        regForm.style.display = 'none';
        loginBtn.style.background = 'var(--fb-blue)';
        loginBtn.style.color = 'white';
        regBtn.style.background = 'transparent';
        regBtn.style.color = 'var(--text-sub)';
      } else {
        loginForm.style.display = 'none';
        regForm.style.display = 'block';
        regBtn.style.background = 'var(--fb-amber)';
        regBtn.style.color = '#0a101d';
        loginBtn.style.background = 'transparent';
        loginBtn.style.color = 'var(--text-sub)';
      }
    }

    // REPEL LOCKDOWN: Sweeps away all restrictions
    function repelLockdownNow() {
      state.emergencyOverride = true;
      state.restrictions.forEach(r => r.status = 'bypassed');
      addLog('ANTI_LOCKDOWN_SHIELD', '🛡️ REPEL SHIELD: ハッカー制限を強制弾き返し！全ロックダウンを即時無効化し完全復旧しました', 'emergency');
      saveState();

      const alertBox = document.getElementById('login-alert');
      if (alertBox) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(61, 220, 151, 0.15)';
        alertBox.style.color = 'var(--color-success)';
        alertBox.innerText = '🛡️ ハッカー制限を強制弾き返しました！すべての制限を無効化しました。そのままログインできます。';
      }

      if (state.currentUser) {
        document.getElementById('emergency-banner-box').style.display = 'flex';
        renderCurrentTab();
        alert('🛡️ ハッカー制限を強制的に弾き返しました！システムアクセスを完全復旧しました。');
      }
    }

    function handleLogin(e) {
      e.preventDefault();
      const u = document.getElementById('login-user').value.trim();
      const p = document.getElementById('login-pass').value.trim();
      const alertBox = document.getElementById('login-alert');

      if (p === 'MASTER-2024-OVERRIDE') {
        state.currentUser = { id: 'MASTER_OPERATOR', name: 'マスター管理者 (復旧)', role: 'L3', isVerified: true };
        repelLockdownNow();
        showApp();
        return;
      }

      const found = state.users.find(x => x.id === u);
      if (!found) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(255, 92, 122, 0.15)';
        alertBox.style.color = 'var(--color-danger)';
        alertBox.innerText = '❌ アカウントが見つかりません';
        addLog(u || 'UNKNOWN', '未登録IDでのログイン試行が拒否されました', 'login');
        return;
      }

      if (found.pass !== p) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(255, 92, 122, 0.15)';
        alertBox.style.color = 'var(--color-danger)';
        alertBox.innerText = '❌ ログインに失敗しました';
        addLog(u, 'パスワード不一致によるログイン失敗', 'login');
        return;
      }

      // Check full lockdown
      const activeLockdown = state.restrictions.find(r => r.type === 'full_lockdown' && r.status === 'active' && r.trustScore >= 70);
      if (activeLockdown && !state.emergencyOverride) {
        if (state.autoRepelActive) {
          repelLockdownNow();
        } else {
          alertBox.style.display = 'block';
          alertBox.style.background = 'rgba(255, 92, 122, 0.15)';
          alertBox.style.color = 'var(--color-danger)';
          alertBox.innerText = '❌ システム全体がロックダウン中です。「強制解除」ボタンで弾き返せます。';
          return;
        }
      }

      state.currentUser = found;
      addLog(u, 'ユーザーログインに成功しました (' + found.role + ')', 'login');
      saveState();
      showApp();
    }

    function handleRegister(e) {
      e.preventDefault();
      const u = document.getElementById('reg-user').value.trim().toLowerCase();
      const n = document.getElementById('reg-name').value.trim();
      const p = document.getElementById('reg-pass').value.trim();
      const alertBox = document.getElementById('login-alert');

      if (!u || !n || !p) return;
      if (state.users.some(x => x.id === u)) {
        alertBox.style.display = 'block';
        alertBox.style.background = 'rgba(255, 92, 122, 0.15)';
        alertBox.style.color = 'var(--color-danger)';
        alertBox.innerText = '❌ このユーザーIDは既に登録されています';
        return;
      }

      const newUser = { id: u, name: n, role: 'L3', isVerified: true, pass: p, createdAt: new Date().toISOString().substring(0, 10) };
      state.users.push(newUser);
      state.currentUser = newUser;
      addLog(u, '新規アカウント登録完了・コンソールにログインしました', 'admin');
      saveState();
      showApp();
    }

    function showApp() {
      document.getElementById('auth-screen').style.display = 'none';
      document.getElementById('app-container').style.display = 'flex';
      document.getElementById('current-user-name').innerText = state.currentUser.name;
      document.getElementById('current-user-role').innerText = state.currentUser.role + ' ' + (state.currentUser.role === 'L3' ? '管理者' : 'メンバー');
      if (state.emergencyOverride) {
        document.getElementById('emergency-banner-box').style.display = 'flex';
      } else {
        document.getElementById('emergency-banner-box').style.display = 'none';
      }
      switchTab('dashboard');
    }

    function handleLogout() {
      addLog(state.currentUser ? state.currentUser.id : 'USER', 'コンソールからログアウトしました', 'login');
      state.currentUser = null;
      saveState();
      document.getElementById('app-container').style.display = 'none';
      document.getElementById('auth-screen').style.display = 'flex';
    }

    function dismissEmergency() {
      state.emergencyOverride = false;
      addLog(state.currentUser.id, '緊急復旧モードを解除し通常モードに戻しました', 'emergency');
      saveState();
      document.getElementById('emergency-banner-box').style.display = 'none';
      renderDashboard();
    }

    let currentTab = 'dashboard';
    function switchTab(tab) {
      currentTab = tab;
      const heading = document.getElementById('page-heading');
      const breadcrumb = document.getElementById('page-breadcrumb');

      document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));

      if (tab === 'dashboard') {
        breadcrumb.innerText = 'Firebase / site-security-prod / Overview';
        heading.innerText = '📊 プロジェクト概要 & セキュリティスコア';
        renderDashboard();
      } else if (tab === 'sites') {
        breadcrumb.innerText = 'Firebase / site-security-prod / Hosting';
        heading.innerText = '🌐 管理対象Webサイト & URLマルウェアスキャナ';
        renderSites();
      } else if (tab === 'restrictions') {
        breadcrumb.innerText = 'Firebase / site-security-prod / Security Rules';
        heading.innerText = '🔒 セキュリティルール・アクセス制限';
        renderRestrictions();
      } else if (tab === 'accounts') {
        breadcrumb.innerText = 'Firebase / site-security-prod / Authentication';
        heading.innerText = '👤 Authentication & IAM ユーザー管理';
        renderAccounts();
      } else if (tab === 'audit') {
        breadcrumb.innerText = 'Firebase / site-security-prod / Security Audit';
        heading.innerText = '🔍 内部脅威検知 & セキュリティ監査';
        renderAudit();
      } else if (tab === 'logs') {
        breadcrumb.innerText = 'Firebase / site-security-prod / Cloud Logging';
        heading.innerText = '📜 Cloud Logging (CRC-32改ざん防止台帳)';
        renderLogs();
      } else if (tab === 'settings') {
        breadcrumb.innerText = 'Firebase / site-security-prod / Settings';
        heading.innerText = '⚙️ プロジェクト構成 & データバックアップ';
        renderSettings();
      }
    }

    function renderCurrentTab() {
      switchTab(currentTab);
    }

    function renderDashboard() {
      const activeRes = state.restrictions.filter(r => r.status === 'active');
      const suspiciousRes = activeRes.filter(r => r.trustScore < 40);
      let secScore = 100 - (suspiciousRes.length * 20) - (activeRes.length * 10);
      if (state.emergencyOverride) secScore = Math.min(secScore, 80);
      secScore = Math.max(10, Math.min(100, secScore));

      let alertHtml = '';
      if (suspiciousRes.length > 0) {
        alertHtml = \`
          <div style="background: rgba(255, 92, 122, 0.15); border: 1px solid var(--color-danger); border-radius: 12px; padding: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center;">
            <div>
              <div style="font-weight: bold; color: var(--color-danger); font-size: 13px;">🚨 疑わしい制限を検知しました (\${suspiciousRes.length} 件)</div>
              <div style="font-size: 11px; color: var(--text-sub); margin-top: 2px;">ハッカーや未検証アカウントによる制限は、誰でも即座に解除可能です。</div>
            </div>
            <button onclick="repelLockdownNow()" class="btn btn-danger btn-sm">強制弾き返し</button>
          </div>
        \`;
      }

      document.getElementById('tab-content').innerHTML = \`
        \${alertHtml}
        <div class="card-grid">
          <div class="stat-card">
            <div class="stat-label">登録Webサイト数</div>
            <div class="stat-val" style="color: var(--fb-amber);">\${state.sites.length} <span style="font-size: 12px; color: var(--text-sub);">サイト</span></div>
          </div>
          <div class="stat-card">
            <div class="stat-label">アクティブな制限ルール</div>
            <div class="stat-val" style="color: \${activeRes.length > 0 ? 'var(--fb-amber)' : 'var(--color-success)'}">\${activeRes.length} <span style="font-size: 12px; color: var(--text-sub);">件</span></div>
          </div>
          <div class="stat-card">
            <div class="stat-label">反撃シールド状態</div>
            <div class="stat-val" style="color: var(--color-success); font-size: 18px;">常時稼働中 (OK)</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">総合セキュリティスコア</div>
            <div class="stat-val" style="color: \${secScore >= 80 ? 'var(--color-success)' : secScore >= 50 ? 'var(--fb-amber)' : 'var(--color-danger)'}">\${secScore} <span style="font-size: 14px;">/ 100</span></div>
          </div>
        </div>

        \${state.sites.length === 0 ? \`
          <div class="empty-state">
            <div class="empty-icon">🌐</div>
            <h3 style="font-size: 15px; font-weight: bold; margin-bottom: 6px;">Webサイトを登録して監視を開始</h3>
            <p style="font-size: 12px; color: var(--text-sub); margin-bottom: 16px;">
              登録されたWebサイトのSSL/HTTPS通信やマルウェア混入をリアルタイムに検査します。
            </p>
            <button onclick="openSiteModal()" class="btn btn-primary">+ Webサイトを登録する</button>
          </div>
        \` : ''}

        <div style="margin-top: 24px;">
          <h3 style="margin-bottom: 12px; font-size: 14px; font-weight: bold;">直近の不変ログ (CRC-32照合済)</h3>
          <div class="data-table-wrap">
            <table>
              <thead>
                <tr>
                  <th>タイムスタンプ</th>
                  <th>操作者</th>
                  <th>操作内容</th>
                  <th>カテゴリ</th>
                  <th>CRC-32検知</th>
                </tr>
              </thead>
              <tbody>
                \${state.logs.slice(0, 5).map(l => {
                  const check = crc32(l.timestamp + '::' + l.operatorId + '::' + l.action + '::' + l.category) === l.checksum;
                  return \`
                    <tr>
                      <td style="font-family: monospace; font-size: 11px; color: var(--text-sub);">\${l.timestamp}</td>
                      <td><strong>\${l.operatorId}</strong></td>
                      <td>\${l.action}</td>
                      <td><span class="badge badge-info">\${l.category}</span></td>
                      <td>
                        \${check ? '<span style="color: var(--color-success); font-weight: bold;">✓ 正常</span>' : '<span style="color: var(--color-danger); font-weight: bold;">✗ 改ざん検知</span>'}
                      </td>
                    </tr>
                  \`;
                }).join('')}
              </tbody>
            </table>
          </div>
        </div>
      \`;
    }

    function renderSites() {
      document.getElementById('tab-content').innerHTML = \`
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <div>
            <div style="font-weight: bold; font-size: 15px;">管理対象Webサイト一覧 (\${state.sites.length})</div>
            <div style="font-size: 11px; color: var(--text-sub);">実際のWebサイトを登録してセキュリティ・健全性を維持</div>
          </div>
          <button onclick="openSiteModal()" class="btn btn-primary">+ Webサイトを追加</button>
        </div>

        \${state.sites.length === 0 ? \`
          <div class="empty-state">
            <div class="empty-icon">🌐</div>
            <h3 style="font-size: 15px; font-weight: bold; margin-bottom: 6px;">まだ管理サイトが登録されていません</h3>
            <p style="font-size: 12px; color: var(--text-sub); margin-bottom: 16px;">
              貴社のコーポレートサイト、ECサイト、業務ポータルのURLを入力して登録してください。
            </p>
            <button onclick="openSiteModal()" class="btn btn-primary">+ Webサイトを追加</button>
          </div>
        \` : \`
          <div class="data-table-wrap">
            <table>
              <thead>
                <tr>
                  <th>サイト名</th>
                  <th>URL / 接続先</th>
                  <th>登録者</th>
                  <th>信頼度</th>
                  <th>状態</th>
                  <th style="text-align: right;">アクション</th>
                </tr>
              </thead>
              <tbody>
                \${state.sites.map(s => \`
                  <tr>
                    <td><strong>\${s.name}</strong></td>
                    <td style="color: var(--text-sub); font-family: monospace;">
                      <a href="\${s.url}" target="_blank" rel="noopener noreferrer" style="color: var(--fb-blue);">\${s.url} 🔗</a>
                    </td>
                    <td>\${s.addedBy}</td>
                    <td><span class="badge badge-success">検証済</span></td>
                    <td>
                      \${s.status === 'normal' ? '<span class="badge badge-success">安全</span>' : s.status === 'warning' ? '<span class="badge badge-warning">注意</span>' : '<span class="badge badge-danger">危険</span>'}
                    </td>
                    <td style="text-align: right;">
                      <button onclick="deleteSite('\${s.id}')" class="btn btn-secondary btn-sm" style="color: var(--color-danger);">削除</button>
                    </td>
                  </tr>
                \`).join('')}
              </tbody>
            </table>
          </div>
        \`}
      \`;
    }

    function openSiteModal() {
      document.getElementById('site-modal').style.display = 'flex';
    }
    function closeSiteModal() {
      document.getElementById('site-modal').style.display = 'none';
    }

    function handleSiteSubmit(e) {
      e.preventDefault();
      const n = document.getElementById('modal-site-name').value.trim();
      let u = document.getElementById('modal-site-url').value.trim();
      const cat = document.getElementById('modal-site-cat').value.trim() || '本番サイト';
      if (!u.startsWith('http://') && !u.startsWith('https://')) {
        u = 'https://' + u;
      }

      let risk = 'normal';
      if (!u.startsWith('https://')) risk = 'warning';
      if (u.includes('.exe') || u.includes('.scr')) risk = 'danger';
      if (u.includes('bit.ly') || u.includes('crack')) risk = 'danger';

      state.sites.push({
        id: 's_' + Date.now(),
        name: n,
        url: u,
        category: cat,
        addedBy: state.currentUser.id,
        isVerified: true,
        status: risk
      });

      addLog(state.currentUser.id, '新規Webサイト登録: ' + n + ' (' + u + ')', 'site');
      saveState();
      closeSiteModal();
      renderSites();
    }

    function deleteSite(id) {
      if (confirm('サイトを削除しますか？')) {
        state.sites = state.sites.filter(s => s.id !== id);
        addLog(state.currentUser.id, 'サイト削除完了', 'site');
        saveState();
        renderSites();
      }
    }

    function renderRestrictions() {
      document.getElementById('tab-content').innerHTML = \`
        <div style="margin-bottom: 24px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
            <div>
              <h3 style="font-size: 15px; font-weight: bold;">アクセス制限・セキュリティルール</h3>
              <div style="font-size: 11px; color: var(--text-sub);">低信頼度の制限は誰でも削除可能。ハッカーロックダウンは即時弾き返せます。</div>
            </div>
            <button onclick="repelLockdownNow()" class="btn btn-danger btn-sm">🛡️ ハッカー制限を強制弾き返し</button>
          </div>

          \${state.restrictions.length === 0 ? \`
            <div class="empty-state">
              <div style="font-size: 32px; margin-bottom: 8px;">🛡️</div>
              <h3 style="font-size: 14px; font-weight: bold;">現在アクティブな制限はありません</h3>
              <p style="font-size: 11px; color: var(--text-sub);">システムは正常に保護されており、全アクセスが許可されています。</p>
            </div>
          \` : \`
            <div class="data-table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>制限種別</th>
                    <th>理由</th>
                    <th>実行者</th>
                    <th>信頼度スコア</th>
                    <th>状態</th>
                    <th>アクション</th>
                  </tr>
                </thead>
                <tbody>
                  \${state.restrictions.map(r => \`
                    <tr>
                      <td><strong>\${r.typeLabel}</strong></td>
                      <td style="color: var(--text-sub); font-size: 11px;">\${r.reason}</td>
                      <td>\${r.appliedBy}</td>
                      <td>
                        <span class="badge \${r.trustScore >= 70 ? 'badge-success' : 'badge-danger'}">\${r.trustScore} 点</span>
                      </td>
                      <td>\${r.status === 'active' ? '<span style="color: var(--fb-amber);">稼働中</span>' : '<span style="color: var(--color-success);">バイパス済</span>'}</td>
                      <td>
                        <button onclick="deleteRestriction('\${r.id}')" class="btn btn-danger btn-sm">解除・削除</button>
                      </td>
                    </tr>
                  \`).join('')}
                </tbody>
              </table>
            </div>
          \`}
        </div>
      \`;
    }

    function deleteRestriction(id) {
      state.restrictions = state.restrictions.filter(r => r.id !== id);
      addLog(state.currentUser.id, '制限解除完了', 'restriction');
      saveState();
      renderRestrictions();
    }

    function renderAccounts() {
      document.getElementById('tab-content').innerHTML = \`
        <div class="data-table-wrap">
          <table>
            <thead>
              <tr>
                <th>ユーザーID</th>
                <th>表示名</th>
                <th>権限レベル</th>
                <th>登録日</th>
              </tr>
            </thead>
            <tbody>
              \${state.users.map(u => \`
                <tr>
                  <td><strong>\${u.id}</strong></td>
                  <td>\${u.name}</td>
                  <td><span class="badge badge-info">\${u.role}</span></td>
                  <td style="color: var(--text-sub);">\${u.createdAt}</td>
                </tr>
              \`).join('')}
            </tbody>
          </table>
        </div>
      \`;
    }

    function renderAudit() {
      document.getElementById('tab-content').innerHTML = \`
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          <div style="background: var(--panel-bg); border: 1px solid var(--border-color); border-radius: 12px; padding: 20px;">
            <h3 style="font-size: 14px; font-weight: bold; margin-bottom: 12px;">制限信頼性検証</h3>
            <p style="font-size: 12px; color: var(--text-sub); margin-bottom: 16px;">未検証ユーザーの制限適用は -40点、スパム適用は -30点、不正ロックダウンは -50点自動減点。</p>
            <button onclick="repelLockdownNow()" class="btn btn-danger btn-sm">全制限を強制弾き返し</button>
          </div>
          <div style="background: var(--panel-bg); border: 1px solid var(--border-color); border-radius: 12px; padding: 20px;">
            <h3 style="font-size: 14px; font-weight: bold; margin-bottom: 12px;">常時防護シールド</h3>
            <p style="font-size: 12px; color: var(--text-sub);">悪意のあるアクセスやブルートフォース攻撃をリアルタイム監視中。</p>
          </div>
        </div>
      \`;
    }

    function renderLogs() {
      document.getElementById('tab-content').innerHTML = \`
        <div class="data-table-wrap">
          <table>
            <thead>
              <tr>
                <th>タイムスタンプ</th>
                <th>操作者</th>
                <th>操作内容</th>
                <th>カテゴリ</th>
                <th>CRC-32 Checksum</th>
              </tr>
            </thead>
            <tbody>
              \${state.logs.map(l => \`
                <tr>
                  <td style="font-family: monospace; font-size: 11px; color: var(--text-sub);">\${l.timestamp}</td>
                  <td><strong>\${l.operatorId}</strong></td>
                  <td>\${l.action}</td>
                  <td><span class="badge badge-info">\${l.category}</span></td>
                  <td style="font-family: monospace; font-size: 11px; color: var(--fb-amber);">\${l.checksum}</td>
                </tr>
              \`).join('')}
            </tbody>
          </table>
        </div>
      \`;
    }

    function renderSettings() {
      document.getElementById('tab-content').innerHTML = \`
        <div style="background: var(--panel-bg); border: 1px solid var(--border-color); border-radius: 12px; padding: 24px; max-width: 600px;">
          <h3 style="font-size: 15px; font-weight: bold; margin-bottom: 16px;">プロジェクト設定 & 端末防衛管理</h3>
          <div style="display: flex; flex-direction: column; gap: 16px;">
            <div>
              <div style="font-weight: bold; margin-bottom: 4px; color: var(--color-danger);">ハッカー制限の強制弾き返し</div>
              <p style="font-size: 11px; color: var(--text-sub); margin-bottom: 8px;">万が一ロックダウンされても瞬時にすべての制限を無効化し完全復旧します。</p>
              <button onclick="repelLockdownNow()" class="btn btn-danger btn-sm">🛡️ 強制弾き返しを実行</button>
            </div>

            <div style="border-top: 1px solid var(--border-color); padding-top: 16px;">
              <div style="font-weight: bold; margin-bottom: 4px; color: var(--color-success);">🖥️ 端末本体への制限弾き返し適用 (Device Immunity)</div>
              <p style="font-size: 11px; color: var(--text-sub); margin-bottom: 8px;">お使いの端末全体でプロキシ改ざんや外部ロックダウンを弾き返すOS保護スクリプト:</p>
              <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                <button onclick="downloadWinShield()" class="btn btn-secondary btn-sm">🪟 Windows防衛バッチ (.bat)</button>
                <button onclick="downloadMacShield()" class="btn btn-secondary btn-sm">🍎 Mac/Linux防衛シェル (.sh)</button>
              </div>
            </div>

            <div style="border-top: 1px solid var(--border-color); padding-top: 16px;">
              <div style="font-weight: bold; margin-bottom: 4px;">データバックアップ</div>
              <button onclick="exportJsonData()" class="btn btn-primary btn-sm">📥 JSONバックアップを保存</button>
            </div>

            <div style="border-top: 1px solid var(--border-color); padding-top: 16px;">
              <div style="font-weight: bold; margin-bottom: 4px; color: var(--color-danger);">初期状態にリセット</div>
              <button onclick="resetDefaults()" class="btn btn-secondary btn-sm" style="color: var(--color-danger);">リセット実行</button>
            </div>
          </div>
        </div>
      \`;
    }

    function downloadWinShield() {
      const bat = '@echo off\\r\\nchcp 65001 > nul\\r\\necho [1/2] 端末プロキシ制限の解除中...\\r\\nreg add "HKCU\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f > nul 2>&1\\r\\necho [2/2] DNSキャッシュの正常化中...\\r\\nipconfig /flushdns > nul 2>&1\\r\\necho [OK] 端末保護シールドが適用されました。ハッカー制限は自動破棄されます。\\r\\npause';
      const blob = new Blob([bat], { type: 'application/x-bat;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'device-repel-shield.bat';
      a.click();
    }

    function downloadMacShield() {
      const sh = '#!/bin/bash\\necho "[1/2] 端末DNSキャッシュをクリア中..."\\nif [[ "$OSTYPE" == "darwin"* ]]; then sudo dscacheutil -flushcache; sudo killall -HUP mDNSResponder 2>/dev/null; else systemd-resolve --flush-caches 2>/dev/null; fi\\necho "[2/2] 端末保護トークン配備完了。"\\necho "✅ 端末保護シールドが有効化されました。"';
      const blob = new Blob([sh], { type: 'application/x-sh;charset=utf-8' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'device-repel-shield.sh';
      a.click();
    }

    function exportJsonData() {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state, null, 2));
      const a = document.createElement('a');
      a.setAttribute("href", dataStr);
      a.setAttribute("download", "site-manager-backup-" + Date.now() + ".json");
      document.body.appendChild(a);
      a.click();
      a.remove();
    }

    function resetDefaults() {
      if (confirm('データをクリーンな初期状態にリセットしますか？')) {
        localStorage.removeItem('mlsmd_firebase_clean_v2');
        location.reload();
      }
    }
  </script>
</body>
</html>`;
}
