import { Restriction, User } from '../types/security';

export interface TrustScoreEvaluation {
  score: number;
  level: 'high' | 'medium' | 'low';
  reasons: string[];
}

export function calculateRestrictionTrustScore(
  creator: User | undefined,
  recentRestrictionsByUser: number,
  isRevokingAdminOrRapidMalicious: boolean
): TrustScoreEvaluation {
  let score = 100;
  const reasons: string[] = ['基本信頼スコア: 100点'];

  // Rule 1: Verification status
  if (!creator || !creator.isVerified) {
    score -= 40;
    reasons.push('未検証アカウントによる制限適用 (-40点)');
  } else if (creator.role === 'L3') {
    reasons.push('検証済みL3管理者アカウントによる適用 (減点なし)');
  }

  // Rule 2: Spam pattern (>= 5 restrictions in recent history)
  if (recentRestrictionsByUser >= 5) {
    score -= 30;
    reasons.push(`同一ユーザーによる24時間以内の連続制限適用(${recentRestrictionsByUser}回) スパム判定 (-30点)`);
  }

  // Rule 3: Hacker pattern (rapid multiple account privilege revokes or aggressive lockdown)
  if (isRevokingAdminOrRapidMalicious) {
    score -= 50;
    reasons.push('短時間の複数権限剥奪または悪質なロックダウン兆候 ハッカー判定 (-50点)');
  }

  // Normalize between 0 and 100
  const normalizedScore = Math.max(0, Math.min(100, score));

  let level: 'high' | 'medium' | 'low' = 'low';
  if (normalizedScore >= 70) {
    level = 'high';
  } else if (normalizedScore >= 40) {
    level = 'medium';
  } else {
    level = 'low';
  }

  return {
    score: normalizedScore,
    level,
    reasons,
  };
}

export function isRestrictionDeletableBy(
  restriction: Restriction,
  userRole: 'L1' | 'L2' | 'L3'
): boolean {
  // Low trust restrictions (< 40 points) can be deleted by ANY user (L1, L2, L3)
  if (restriction.trustScore < 40) {
    return true;
  }
  // Medium trust restrictions can be modified or removed by L2 or L3
  if (restriction.trustScore < 70 && (userRole === 'L2' || userRole === 'L3')) {
    return true;
  }
  // High trust restrictions (>= 70) require L3 Admin
  return userRole === 'L3';
}
