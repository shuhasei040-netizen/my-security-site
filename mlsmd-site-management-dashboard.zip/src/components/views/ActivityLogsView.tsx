import React, { useState } from 'react';
import { useSecurity } from '../../context/SecurityContext';
import { ActivityLog, LogCategory } from '../../types/security';
import {
  FileText,
  Search,
  Download,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { verifyLogIntegrity } from '../../utils/crc32';

export const ActivityLogsView: React.FC = () => {
  const { logs, tamperLog, exportJsonBackup } = useSecurity();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  // Filter logs
  const filteredLogs = logs.filter(log => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.operatorId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.checksum.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;
    if (selectedCategory !== 'all' && log.category !== selectedCategory) return false;
    return true;
  });

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage) || 1;
  const currentLogs = filteredLogs.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getCategoryBadge = (cat: LogCategory) => {
    const map: Record<LogCategory, { label: string; color: string }> = {
      login: { label: 'ログイン', color: 'bg-[#5b8cff]/15 text-[#5b8cff] border-[#5b8cff]/30' },
      site: { label: 'サイト操作', color: 'bg-[#3ddc97]/15 text-[#3ddc97] border-[#3ddc97]/30' },
      restriction: { label: '制限適用', color: 'bg-[#ffb547]/15 text-[#ffb547] border-[#ffb547]/30' },
      admin: { label: '管理者行為', color: 'bg-[#7c5bff]/15 text-[#7c5bff] border-[#7c5bff]/30' },
      emergency: { label: '緊急復旧', color: 'bg-[#ff5c7a]/20 text-[#ff5c7a] border-[#ff5c7a]/40' },
      scan: { label: '脆弱検査', color: 'bg-[#5b8cff]/15 text-[#5b8cff] border-[#5b8cff]/30' },
      system: { label: 'システム', color: 'bg-[#2a3550] text-[#8b96b8] border-[#2a3550]' },
    };
    const c = map[cat] || { label: cat, color: 'bg-[#2a3550] text-[#8b96b8] border-[#2a3550]' };
    return (
      <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${c.color}`}>
        {c.label}
      </span>
    );
  };

  const getDotColor = (log: ActivityLog) => {
    if (log.isTampered) return 'bg-[#ff5c7a] ring-4 ring-[#ff5c7a]/20 animate-ping';
    if (log.severity === 'error') return 'bg-[#ff5c7a]';
    if (log.severity === 'warning') return 'bg-[#ffb547]';
    if (log.severity === 'success') return 'bg-[#3ddc97]';
    return 'bg-[#5b8cff]';
  };

  return (
    <div className="space-y-6">
      {/* Top Toolbar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#0f1420] p-4 rounded-xl border border-[#2a3550]">
        <div className="flex flex-1 items-center gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-[#8b96b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="操作内容・操作者ID・ハッシュで検索..."
              className="w-full bg-[#161d2e] border border-[#2a3550] rounded-lg pl-9 pr-3 py-1.5 text-xs text-[#e8ecf6] placeholder-[#8b96b8]/60 focus:outline-none focus:border-[#5b8cff]"
            />
          </div>

          <select
            value={selectedCategory}
            onChange={e => {
              setSelectedCategory(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-[#161d2e] border border-[#2a3550] text-[#e8ecf6] rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-[#5b8cff]"
          >
            <option value="all">全カテゴリ</option>
            <option value="login">ログイン試行</option>
            <option value="site">サイト操作</option>
            <option value="restriction">制限適用</option>
            <option value="admin">管理者行為</option>
            <option value="emergency">緊急復旧</option>
            <option value="scan">脆弱性スキャン</option>
            <option value="system">システム内部</option>
          </select>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Tamper simulation button */}
          <button
            onClick={() => {
              if (currentLogs.length > 0) {
                tamperLog(currentLogs[0].id);
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#ffb547]/15 hover:bg-[#ffb547]/25 text-[#ffb547] border border-[#ffb547]/30 rounded-lg text-xs font-semibold transition cursor-pointer"
            title="1行目のログを改変してCRC-32チェックサム不整合を検証"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>改ざんシミュレート</span>
          </button>

          {/* Export JSON */}
          <button
            onClick={exportJsonBackup}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#161d2e] hover:bg-[#2a3550] text-[#e8ecf6] border border-[#2a3550] rounded-lg text-xs font-medium transition cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#5b8cff]" />
            <span>ログJSON保存</span>
          </button>
        </div>
      </div>

      {/* Logs Table */}
      <div className="rounded-xl bg-[#0f1420] border border-[#2a3550] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#161d2e] text-[#8b96b8] border-b border-[#2a3550]">
                <th className="py-3 px-4 font-semibold w-12 text-center">状態</th>
                <th className="py-3 px-4 font-semibold">タイムスタンプ (ミリ秒)</th>
                <th className="py-3 px-4 font-semibold">操作者ID</th>
                <th className="py-3 px-4 font-semibold">操作内容</th>
                <th className="py-3 px-4 font-semibold">カテゴリ</th>
                <th className="py-3 px-4 font-semibold">CRC-32 ハッシュ</th>
                <th className="py-3 px-4 font-semibold text-right">改ざん検知ステータス</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2a3550]/60">
              {currentLogs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#8b96b8]">
                    条件に一致するログは見つかりませんでした
                  </td>
                </tr>
              ) : (
                currentLogs.map(log => {
                  const isCalculatedValid = verifyLogIntegrity(
                    log.timestamp,
                    log.operatorId,
                    log.action,
                    log.category,
                    log.checksum
                  );
                  const isUntampered = isCalculatedValid && !log.isTampered;

                  return (
                    <tr
                      key={log.id}
                      className={`hover:bg-[#161d2e]/40 transition ${
                        !isUntampered ? 'bg-[#ff5c7a]/10' : ''
                      }`}
                    >
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block w-2.5 h-2.5 rounded-full ${getDotColor(log)}`}
                        />
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-[#8b96b8] whitespace-nowrap">
                        {log.timestamp}
                      </td>
                      <td className="py-3 px-4 font-bold text-[#e8ecf6] whitespace-nowrap">
                        {log.operatorId}
                      </td>
                      <td className="py-3 px-4 text-[#e8ecf6] leading-relaxed">
                        {log.action}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {getCategoryBadge(log.category)}
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-[#5b8cff] whitespace-nowrap">
                        {log.checksum}
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        {isUntampered ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-[#3ddc97]">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>✓ 正常 (一致)</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-bold text-[#ff5c7a] animate-pulse">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>✗ 改ざん検知！</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Toolbar */}
        <div className="p-3.5 bg-[#161d2e]/60 border-t border-[#2a3550] flex items-center justify-between text-xs text-[#8b96b8]">
          <div>
            全 {filteredLogs.length} 件中 {(currentPage - 1) * itemsPerPage + 1} -{' '}
            {Math.min(currentPage * itemsPerPage, filteredLogs.length)} 件を表示中 (最大5000件保持)
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1 rounded bg-[#161d2e] hover:bg-[#2a3550] border border-[#2a3550] disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-mono px-2 font-bold text-[#e8ecf6]">
              {currentPage} / {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1 rounded bg-[#161d2e] hover:bg-[#2a3550] border border-[#2a3550] disabled:opacity-40 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
