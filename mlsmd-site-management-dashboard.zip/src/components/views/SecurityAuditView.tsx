import React from 'react';
import { useSecurity } from '../../context/SecurityContext';
import {
  ShieldAlert,
  SearchCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Cpu,
  Layers,
} from 'lucide-react';

export const SecurityAuditView: React.FC = () => {
  const { restrictions, threatPatterns, stats } = useSecurity();

  const activeRes = restrictions.filter(r => r.status === 'active');
  const countHigh = activeRes.filter(r => r.trustScore >= 70).length;
  const countMedium = activeRes.filter(r => r.trustScore >= 40 && r.trustScore < 70).length;
  const countLow = activeRes.filter(r => r.trustScore < 40).length;

  return (
    <div className="space-y-6">
      {/* 2-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: 制限検証チェック */}
        <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550] flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2 text-[#5b8cff]">
              <Layers className="w-5 h-5" />
              <h3 className="font-bold text-base text-[#e8ecf6]">制限検証チェック (Trust Verification)</h3>
            </div>
            <p className="text-xs text-[#8b96b8] mb-5">
              稼働中制限の客観的信頼度スコアをリアルタイム集計し、不正なロックダウンを隔離
            </p>

            <div className="space-y-3.5">
              <div className="flex items-center justify-between p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
                <span className="text-xs text-[#8b96b8]">アクティブな制限総数</span>
                <span className="text-sm font-bold text-[#e8ecf6] font-mono">
                  {activeRes.length} 件
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#3ddc97]" />
                  <span className="text-xs text-[#e8ecf6]">信頼度 70点以上 (高信頼)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-[#3ddc97]">{countHigh} 件</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-[#3ddc97]/15 text-[#3ddc97] border border-[#3ddc97]/30">
                    厳格適用
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-[#ffb547]" />
                  <span className="text-xs text-[#e8ecf6]">信頼度 40〜70点 (中程度)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-[#ffb547]">{countMedium} 件</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-[#ffb547]/15 text-[#ffb547] border border-[#ffb547]/30">
                    警告表示
                  </span>
                </div>
              </div>

              <div
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  countLow > 0
                    ? 'bg-[#ff5c7a]/15 border-[#ff5c7a]/40 text-[#ff5c7a]'
                    : 'bg-[#161d2e] border-[#2a3550]'
                }`}
              >
                <div className="flex items-center gap-2">
                  <XCircle className="w-4 h-4 text-[#ff5c7a]" />
                  <span className="text-xs font-semibold">信頼度 40点未満 (低信頼・警告)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-[#ff5c7a]">{countLow} 件</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#ff5c7a]/20 text-[#ff5c7a] border border-[#ff5c7a]/40">
                    全ユーザー削除可
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
                <span className="text-xs text-[#8b96b8]">内部検知エンジン異常検知数</span>
                <span className="text-sm font-bold text-[#ffb547] font-mono">
                  {stats.detectedAnomaliesCount} 件
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#2a3550] text-[11px] text-[#8b96b8]">
            ※ 低信頼度の制限は、ハッカーに乗っ取られたアカウントによる不正制限の可能性が高いため、誰でも即座に解除・削除できます。
          </div>
        </div>

        {/* Right Column: ハッカー検知パターン */}
        <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550]">
          <div className="flex items-center gap-2 mb-2 text-[#ff5c7a]">
            <Cpu className="w-5 h-5" />
            <h3 className="font-bold text-base text-[#e8ecf6]">ハッカー検知パターン監視 (Real-time Watch)</h3>
          </div>
          <p className="text-xs text-[#8b96b8] mb-5">
            短時間での大量ロックダウン、権限昇格、ログ改ざん等の悪意ある行動をリアルタイム捕捉
          </p>

          <div className="space-y-3">
            {threatPatterns.map(pattern => {
              const isRed = pattern.severity === 'red';
              return (
                <div
                  key={pattern.id}
                  className={`p-3.5 rounded-lg border transition ${
                    pattern.isActive
                      ? isRed
                        ? 'bg-[#ff5c7a]/10 border-[#ff5c7a]/40'
                        : 'bg-[#ffb547]/10 border-[#ffb547]/40'
                      : 'bg-[#161d2e] border-[#2a3550]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <span className="mt-0.5 shrink-0 text-sm">
                        {isRed ? '🔴' : '🟡'}
                      </span>
                      <div>
                        <div className="text-xs font-bold text-[#e8ecf6]">{pattern.title}</div>
                        <div className="text-[11px] text-[#8b96b8] mt-0.5">
                          {pattern.description}
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 text-right">
                      {pattern.isActive ? (
                        <span
                          className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                            isRed
                              ? 'bg-[#ff5c7a]/20 text-[#ff5c7a] border border-[#ff5c7a]/30 animate-pulse'
                              : 'bg-[#ffb547]/20 text-[#ffb547] border border-[#ffb547]/30'
                          }`}
                        >
                          検知中 ({pattern.count})
                        </span>
                      ) : (
                        <span className="text-[10px] text-[#3ddc97] font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> 正常
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Trust Score Calculation Engine Specs Box */}
      <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550]">
        <div className="flex items-center gap-2 mb-3">
          <HelpCircle className="w-4 h-4 text-[#5b8cff]" />
          <h4 className="text-sm font-bold text-[#e8ecf6]">
            信頼性スコア（Trust Score）自動計算アルゴリズムの仕様
          </h4>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="font-bold text-[#e8ecf6] mb-1">① 基本スコア</div>
            <p className="text-[#8b96b8]">
              すべての制限適用は初期値 <span className="text-[#5b8cff] font-bold">100点</span> からスタートします。
            </p>
          </div>

          <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="font-bold text-[#ffb547] mb-1">② 未検証アカウント</div>
            <p className="text-[#8b96b8]">
              未検証アカウントによる適用の場合、即座に <span className="text-[#ff5c7a] font-bold">-40点</span> 減点。
            </p>
          </div>

          <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="font-bold text-[#ff5c7a] mb-1">③ スパム判定</div>
            <p className="text-[#8b96b8]">
              同一ユーザーが24時間以内に5回以上の制限を適用した場合、<span className="text-[#ff5c7a] font-bold">-30点</span> 減点。
            </p>
          </div>

          <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="font-bold text-[#ff5c7a] mb-1">④ ハッカー判定</div>
            <p className="text-[#8b96b8]">
              管理者権限剥奪や短時間の複数アカウント制限を試みた場合、<span className="text-[#ff5c7a] font-bold">-50点</span> 減点。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
