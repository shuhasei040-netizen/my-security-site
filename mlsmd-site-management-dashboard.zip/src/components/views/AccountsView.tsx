import React, { useState } from 'react';
import { useSecurity } from '../../context/SecurityContext';
import { User, UserRole } from '../../types/security';
import {
  Users,
  Plus,
  Shield,
  CheckCircle,
  AlertTriangle,
  Trash2,
  Lock,
  X,
  UserCheck,
} from 'lucide-react';

export const AccountsView: React.FC = () => {
  const {
    users,
    addUser,
    updateUserRole,
    deleteUser,
    toggleUserVerified,
    currentUser,
    showToast,
  } = useSecurity();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [formId, setFormId] = useState('');
  const [formName, setFormName] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formRole, setFormRole] = useState<UserRole>('L2');
  const [formVerified, setFormVerified] = useState(true);

  const openAddModal = () => {
    if (currentUser?.role !== 'L3') {
      showToast('🚫 権限がありません（アカウント登録にはL3管理者権限が必要です）', 'error');
      return;
    }
    setFormId('');
    setFormName('');
    setFormPassword('');
    setFormRole('L2');
    setFormVerified(true);
    setIsAddModalOpen(true);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formId.trim() || !formName.trim() || !formPassword.trim()) {
      showToast('すべての必須項目を入力してください', 'error');
      return;
    }
    const success = addUser(formName, formId, formPassword, formRole, formVerified);
    if (success) {
      setIsAddModalOpen(false);
    }
  };

  const handleRoleChange = (userId: string, newRole: UserRole) => {
    if (currentUser?.role !== 'L3') {
      showToast('🚫 権限がありません（権限変更にはL3管理者権限が必要です）', 'error');
      return;
    }
    updateUserRole(userId, newRole);
  };

  const handleDeleteUser = (userId: string) => {
    if (currentUser?.role !== 'L3') {
      showToast('🚫 権限がありません', 'error');
      return;
    }
    if (confirm(`アカウント「${userId}」を削除しますか？`)) {
      deleteUser(userId);
    }
  };

  return (
    <div className="space-y-6">
      {/* Upper toolbar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#0f1420] p-4 rounded-xl border border-[#2a3550]">
        <div>
          <h2 className="text-sm font-bold text-[#e8ecf6] flex items-center gap-2">
            <Users className="w-4 h-4 text-[#5b8cff]" />
            <span>ユーザーアカウント & 多層権限管理 ({users.length}件)</span>
          </h2>
          <p className="text-xs text-[#8b96b8]">
            権限レベル（L1閲覧者 / L2編集者 / L3管理者）および信頼度検証ステータス
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-[#5b8cff] to-[#7c5bff] text-white rounded-lg text-xs font-bold transition shadow-md shadow-[#5b8cff]/20 cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>+ アカウント登録</span>
        </button>
      </div>

      {/* Accounts Table */}
      <div className="rounded-xl bg-[#0f1420] border border-[#2a3550] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#161d2e] text-[#8b96b8] border-b border-[#2a3550]">
                <th className="py-3.5 px-4 font-semibold">ユーザーID</th>
                <th className="py-3.5 px-4 font-semibold">表示名</th>
                <th className="py-3.5 px-4 font-semibold">権限レベル (RBAC)</th>
                <th className="py-3.5 px-4 font-semibold">信頼度ステータス</th>
                <th className="py-3.5 px-4 font-semibold">登録日</th>
                <th className="py-3.5 px-4 font-semibold text-right">アクション</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2a3550]/60">
              {users.map(u => {
                const isAdmin = u.id === 'admin';
                return (
                  <tr key={u.id} className="hover:bg-[#161d2e]/40 transition">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-[#e8ecf6] font-mono flex items-center gap-1.5">
                        <span>{u.id}</span>
                        {isAdmin && (
                          <span className="px-1.5 py-0.2 bg-[#5b8cff]/20 text-[#5b8cff] rounded text-[10px]">
                            ROOT
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-[#e8ecf6] font-medium">{u.name}</td>
                    <td className="py-3.5 px-4">
                      {isAdmin ? (
                        <span className="px-2 py-1 rounded text-xs font-bold bg-[#5b8cff]/20 text-[#5b8cff] border border-[#5b8cff]/40">
                          L3 管理者 (固定)
                        </span>
                      ) : (
                        <select
                          value={u.role}
                          onChange={e => handleRoleChange(u.id, e.target.value as UserRole)}
                          disabled={currentUser?.role !== 'L3'}
                          className="bg-[#161d2e] border border-[#2a3550] text-[#e8ecf6] rounded px-2.5 py-1 text-xs focus:outline-none focus:border-[#5b8cff] disabled:opacity-60 cursor-pointer"
                        >
                          <option value="L1">L1 閲覧者（閲覧のみ）</option>
                          <option value="L2">L2 編集者（サイト管理）</option>
                          <option value="L3">L3 管理者（全権限・制限適用）</option>
                        </select>
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <button
                        onClick={() => toggleUserVerified(u.id)}
                        disabled={currentUser?.role !== 'L3' || isAdmin}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold transition ${
                          u.isVerified
                            ? 'bg-[#3ddc97]/15 text-[#3ddc97] border border-[#3ddc97]/30 hover:bg-[#3ddc97]/25'
                            : 'bg-[#ffb547]/15 text-[#ffb547] border border-[#ffb547]/30 hover:bg-[#ffb547]/25'
                        }`}
                        title="クリックで検証ステータスを切り替え (L3)"
                      >
                        {u.isVerified ? (
                          <>
                            <CheckCircle className="w-3 h-3" />
                            <span>検証済み</span>
                          </>
                        ) : (
                          <>
                            <AlertTriangle className="w-3 h-3" />
                            <span>未検証 (制限適用時に減点)</span>
                          </>
                        )}
                      </button>
                    </td>
                    <td className="py-3.5 px-4 font-mono text-[11px] text-[#8b96b8]">
                      {u.createdAt}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      {isAdmin ? (
                        <span className="text-[11px] text-[#8b96b8]/60">保護アカウント</span>
                      ) : (
                        <button
                          onClick={() => handleDeleteUser(u.id)}
                          className="p-1.5 text-[#8b96b8] hover:text-[#ff5c7a] hover:bg-[#ff5c7a]/10 rounded transition"
                          title="アカウントを削除"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Permissions Breakdown Guide */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-[#0f1420] border border-[#2a3550]">
          <div className="text-xs font-bold text-[#8b96b8] uppercase tracking-wider mb-2">
            L1 閲覧者 (Viewer)
          </div>
          <ul className="text-xs text-[#8b96b8] space-y-1.5 list-disc list-inside">
            <li>ダッシュボード概要の閲覧</li>
            <li>サイトの追加・編集・削除：不可</li>
            <li>制限の適用：不可</li>
            <li><span className="text-[#3ddc97]">低信頼度制限(&lt;40点)の緊急削除：可能</span></li>
          </ul>
        </div>

        <div className="p-4 rounded-xl bg-[#0f1420] border border-[#2a3550]">
          <div className="text-xs font-bold text-[#5b8cff] uppercase tracking-wider mb-2">
            L2 編集者 (Editor)
          </div>
          <ul className="text-xs text-[#8b96b8] space-y-1.5 list-disc list-inside">
            <li>ダッシュボード全体の閲覧</li>
            <li>サイト情報の追加・編集・削除：可能</li>
            <li>マルウェア検査の実行：可能</li>
            <li>制限の適用：不可</li>
            <li>低信頼度制限の削除：可能</li>
          </ul>
        </div>

        <div className="p-4 rounded-xl bg-[#0f1420] border border-[#2a3550]">
          <div className="text-xs font-bold text-[#7c5bff] uppercase tracking-wider mb-2">
            L3 管理者 (Administrator)
          </div>
          <ul className="text-xs text-[#8b96b8] space-y-1.5 list-disc list-inside">
            <li>すべての機能の利用が可能</li>
            <li>ロックダウン等の制限適用</li>
            <li>アカウント追加・削除・権限変更</li>
            <li>改ざん防止ログの完全閲覧</li>
          </ul>
        </div>
      </div>

      {/* Add User Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#0f1420] border border-[#2a3550] rounded-xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4 border-b border-[#2a3550] pb-3">
              <h3 className="font-bold text-base text-[#e8ecf6] flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-[#5b8cff]" />
                <span>新規アカウントの登録</span>
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-[#8b96b8] hover:text-[#e8ecf6]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  ユーザーID（英数字） <span className="text-[#ff5c7a]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formId}
                  onChange={e => setFormId(e.target.value.replace(/[^a-zA-Z0-9_-]/g, ''))}
                  placeholder="例: sec_officer02"
                  className="w-full bg-[#161d2e] border border-[#2a3550] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] font-mono focus:outline-none focus:border-[#5b8cff]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  表示名 <span className="text-[#ff5c7a]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="例: セキュリティ運用担当 高橋"
                  className="w-full bg-[#161d2e] border border-[#2a3550] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#5b8cff]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  初期パスワード <span className="text-[#ff5c7a]">*</span>
                </label>
                <input
                  type="password"
                  required
                  value={formPassword}
                  onChange={e => setFormPassword(e.target.value)}
                  placeholder="英数記号8文字以上"
                  className="w-full bg-[#161d2e] border border-[#2a3550] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#5b8cff]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  権限レベル
                </label>
                <select
                  value={formRole}
                  onChange={e => setFormRole(e.target.value as UserRole)}
                  className="w-full bg-[#161d2e] border border-[#2a3550] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#5b8cff]"
                >
                  <option value="L1">L1 閲覧者（監査・サマリー閲覧のみ）</option>
                  <option value="L2">L2 編集者（サイト追加・変更・低信頼制限削除）</option>
                  <option value="L3">L3 管理者（全特権・制限適用・ユーザー管理）</option>
                </select>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="verified-check"
                  checked={formVerified}
                  onChange={e => setFormVerified(e.target.checked)}
                  className="w-4 h-4 accent-[#5b8cff] rounded"
                />
                <label htmlFor="verified-check" className="text-xs text-[#e8ecf6] cursor-pointer">
                  このアカウントを「検証済み」として登録する
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#2a3550]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-[#161d2e] hover:bg-[#2a3550] text-[#8b96b8] rounded-lg text-xs font-medium transition cursor-pointer"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-[#5b8cff] to-[#7c5bff] text-white rounded-lg text-xs font-bold transition shadow-md shadow-[#5b8cff]/20 cursor-pointer"
                >
                  登録する
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
