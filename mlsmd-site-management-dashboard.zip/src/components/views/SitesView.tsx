import React, { useState } from 'react';
import { useSecurity } from '../../context/SecurityContext';
import { Site, SiteStatus } from '../../types/security';
import {
  Globe,
  Plus,
  Search,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Trash2,
  Edit2,
  ExternalLink,
  RefreshCw,
  Info,
  CheckCircle,
  X,
  Sparkles,
} from 'lucide-react';

export const SitesView: React.FC = () => {
  const {
    sites,
    addSite,
    updateSite,
    deleteSite,
    scanSite,
    scanAllSites,
    seedDemoData,
    currentUser,
    showToast,
  } = useSecurity();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingSite, setEditingSite] = useState<Site | null>(null);
  const [selectedScanDetail, setSelectedScanDetail] = useState<Site | null>(null);

  // Form states
  const [formName, setFormName] = useState('');
  const [formUrl, setFormUrl] = useState('');
  const [formCategory, setFormCategory] = useState('');
  const [formNotes, setFormNotes] = useState('');

  const openAddModal = () => {
    if (currentUser?.role === 'L1') {
      showToast('🚫 権限がありません（サイト追加にはL2以上の権限が必要です）', 'error');
      return;
    }
    setFormName('');
    setFormUrl('https://');
    setFormCategory('本番サイト');
    setFormNotes('');
    setEditingSite(null);
    setIsAddModalOpen(true);
  };

  const openEditModal = (site: Site) => {
    if (currentUser?.role === 'L1') {
      showToast('🚫 権限がありません（サイト編集にはL2以上の権限が必要です）', 'error');
      return;
    }
    setEditingSite(site);
    setFormName(site.name);
    setFormUrl(site.url);
    setFormCategory(site.category);
    setFormNotes(site.notes);
    setIsAddModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formUrl.trim()) {
      showToast('サイト名とURLは必須です', 'error');
      return;
    }

    if (editingSite) {
      updateSite(editingSite.id, formName, formUrl, formCategory, formNotes);
    } else {
      addSite(formName, formUrl, formCategory, formNotes);
    }
    setIsAddModalOpen(false);
  };

  const handleDelete = (id: string, name: string) => {
    if (currentUser?.role === 'L1') {
      showToast('🚫 権限がありません（サイト削除にはL2以上の権限が必要です）', 'error');
      return;
    }
    if (confirm(`管理サイト「${name}」を削除してもよろしいですか？`)) {
      deleteSite(id);
    }
  };

  // Filtered sites
  const filteredSites = sites.filter(s => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.addedBy.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (filterStatus === 'verified') return s.isVerified;
    if (filterStatus === 'unverified') return !s.isVerified;
    if (filterStatus === 'danger') return s.status === 'danger' || s.status === 'warning';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Toolbar (Firebase Hosting Style) */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#111726] p-4 rounded-xl border border-[#1f2b45]">
        <div className="flex flex-1 items-center gap-3">
          {/* Search box */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-[#8b96b8] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="サイト名・URL・登録者で検索..."
              className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg pl-9 pr-3 py-1.5 text-xs text-[#e8ecf6] placeholder-[#8b96b8]/60 focus:outline-none focus:border-[#ffa000]"
            />
          </div>

          {/* Filter dropdown */}
          <select
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="bg-[#0c1222] border border-[#1f2b45] text-[#e8ecf6] rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-[#ffa000]"
          >
            <option value="all">すべてのステータス</option>
            <option value="verified">検証済み登録者のみ</option>
            <option value="unverified">未検証アカウント登録のみ</option>
            <option value="danger">危険 / 警告検出サイトのみ</option>
          </select>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {sites.length > 0 && (
            <button
              onClick={() => scanAllSites()}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#0c1222] hover:bg-[#1a233a] text-[#e8ecf6] border border-[#1f2b45] rounded-lg text-xs font-semibold transition cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#ffa000]" />
              <span>全サイトをセキュリティスキャン</span>
            </button>
          )}

          <button
            onClick={openAddModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-[#ffa000] to-[#ffca28] hover:opacity-95 text-[#0a101d] rounded-lg text-xs font-bold transition shadow-md shadow-[#ffa000]/20 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Webサイトを追加</span>
          </button>
        </div>
      </div>

      {/* Sites List or Empty State */}
      {sites.length === 0 ? (
        <div className="p-12 rounded-2xl bg-[#111726] border border-[#1f2b45] text-center max-w-2xl mx-auto my-6">
          <div className="w-16 h-16 rounded-2xl bg-[#ffa000]/15 border border-[#ffa000]/30 text-[#ffa000] flex items-center justify-center mx-auto mb-4">
            <Globe className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-[#e8ecf6] mb-2">
            管理対象のWebサイトがまだ登録されていません
          </h3>
          <p className="text-xs text-[#8b96b8] leading-relaxed mb-6 max-w-lg mx-auto">
            貴社の本番Webサイト、ECショップ、社内ポータルなどの実際のURLを登録して、常時SSL暗号化通信の確認や不正リンク・マルウェアのセキュリティ検査を開始しましょう。
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={openAddModal}
              className="px-5 py-2.5 bg-gradient-to-r from-[#ffa000] to-[#ffca28] text-[#0a101d] rounded-xl text-xs font-bold transition shadow-md shadow-[#ffa000]/20 cursor-pointer flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              <span>最初のWebサイトを登録する</span>
            </button>
            <button
              onClick={seedDemoData}
              className="px-4 py-2 bg-[#0c1222] hover:bg-[#1a233a] text-[#8b96b8] hover:text-[#e8ecf6] border border-[#1f2b45] rounded-xl text-xs font-medium transition cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#ffa000]" />
              <span>テスト用にサンプルデータを投入</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="rounded-xl bg-[#111726] border border-[#1f2b45] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-[#0c1222] text-[#8b96b8] border-b border-[#1f2b45]">
                  <th className="py-3.5 px-4 font-semibold">サイト名</th>
                  <th className="py-3.5 px-4 font-semibold">URL / 接続先</th>
                  <th className="py-3.5 px-4 font-semibold">登録者</th>
                  <th className="py-3.5 px-4 font-semibold">信頼度</th>
                  <th className="py-3.5 px-4 font-semibold">マルウェア検査状態</th>
                  <th className="py-3.5 px-4 font-semibold text-right">アクション</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1f2b45]/60">
                {filteredSites.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-[#8b96b8]">
                      検索条件に一致するサイトが見つかりません
                    </td>
                  </tr>
                ) : (
                  filteredSites.map(site => {
                    const isSafe = site.status === 'normal';
                    const isWarning = site.status === 'warning';
                    const isDanger = site.status === 'danger';

                    return (
                      <tr key={site.id} className="hover:bg-[#0c1222]/40 transition">
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-[#e8ecf6]">{site.name}</div>
                          <div className="text-[11px] text-[#8b96b8]">{site.category}</div>
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="font-mono text-[11px] text-[#8b96b8] flex items-center gap-1.5 max-w-xs truncate">
                            <span className="truncate">{site.url}</span>
                            <a
                              href={site.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[#1a73e8] hover:text-[#4285f4] shrink-0"
                              title="サイトを別タブで開く"
                            >
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                          {site.notes && (
                            <div className="text-[10px] text-[#8b96b8]/80 truncate">{site.notes}</div>
                          )}
                        </td>
                        <td className="py-3.5 px-4 font-medium text-[#e8ecf6]">
                          {site.addedBy}
                        </td>
                        <td className="py-3.5 px-4">
                          {site.isVerified ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-[#3ddc97]/15 text-[#3ddc97] border border-[#3ddc97]/30">
                              <CheckCircle className="w-3 h-3" /> 検証済
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-[#ffa000]/15 text-[#ffa000] border border-[#ffa000]/30">
                              <AlertTriangle className="w-3 h-3" /> 未検証
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2">
                            {isSafe && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-[#3ddc97]/15 text-[#3ddc97] border border-[#3ddc97]/30">
                                <ShieldCheck className="w-3 h-3" /> 安全 (検査合格)
                              </span>
                            )}
                            {isWarning && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-[#ffa000]/15 text-[#ffa000] border border-[#ffa000]/30">
                                <AlertTriangle className="w-3 h-3" /> 警告検出
                              </span>
                            )}
                            {isDanger && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-[#ff5c7a]/15 text-[#ff5c7a] border border-[#ff5c7a]/30 animate-pulse">
                                <ShieldAlert className="w-3 h-3" /> 危険 (不正URL)
                              </span>
                            )}

                            <button
                              onClick={() => setSelectedScanDetail(site)}
                              className="p-1 text-[#8b96b8] hover:text-[#ffa000] transition cursor-pointer"
                              title="検査レポート詳細を見る"
                            >
                              <Info className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => scanSite(site.id)}
                              className="px-2 py-1 bg-[#0c1222] hover:bg-[#1a233a] text-[#ffa000] rounded text-[11px] font-semibold border border-[#1f2b45] transition cursor-pointer"
                            >
                              再検査
                            </button>
                            <button
                              onClick={() => openEditModal(site)}
                              className="p-1.5 text-[#8b96b8] hover:text-[#e8ecf6] hover:bg-[#0c1222] rounded transition cursor-pointer"
                              title="編集"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDelete(site.id, site.name)}
                              className="p-1.5 text-[#8b96b8] hover:text-[#ff5c7a] hover:bg-[#ff5c7a]/10 rounded transition cursor-pointer"
                              title="削除"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Site Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-[#111726] border border-[#1f2b45] rounded-xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4 border-b border-[#1f2b45] pb-3">
              <h3 className="font-bold text-base text-[#e8ecf6] flex items-center gap-2">
                <Globe className="w-4 h-4 text-[#ffa000]" />
                <span>{editingSite ? 'サイト情報の変更' : '新規管理Webサイトの登録'}</span>
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-[#8b96b8] hover:text-[#e8ecf6]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  サイト名 <span className="text-[#ff5c7a]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  placeholder="例: 株式会社サンプル コーポレートサイト"
                  className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  サイトURL <span className="text-[#ff5c7a]">* (登録時に自動ウイルス・SSL検査)</span>
                </label>
                <input
                  type="text"
                  required
                  value={formUrl}
                  onChange={e => setFormUrl(e.target.value)}
                  placeholder="https://example.com"
                  className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] font-mono focus:outline-none focus:border-[#ffa000]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  カテゴリ
                </label>
                <input
                  type="text"
                  value={formCategory}
                  onChange={e => setFormCategory(e.target.value)}
                  placeholder="例: コーポレート, ECサイト, 社内ポータル, API"
                  className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  管理メモ（オプション）
                </label>
                <textarea
                  value={formNotes}
                  onChange={e => setFormNotes(e.target.value)}
                  rows={2}
                  placeholder="アクセス要件や担当者、ドメイン更新日に関するメモ..."
                  className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1f2b45]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-[#0c1222] hover:bg-[#1a233a] text-[#8b96b8] rounded-lg text-xs font-medium transition cursor-pointer"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-[#ffa000] to-[#ffca28] text-[#0a101d] rounded-lg text-xs font-bold transition shadow-md shadow-[#ffa000]/20 cursor-pointer"
                >
                  {editingSite ? '変更を保存' : '登録してセキュリティ検査を実行'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Malware Scan Diagnostic Report Modal */}
      {selectedScanDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-[#111726] border border-[#1f2b45] rounded-xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4 border-b border-[#1f2b45] pb-3">
              <div>
                <h3 className="font-bold text-base text-[#e8ecf6] flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-[#ffa000]" />
                  <span>マルウェア・URLセキュリティ検査レポート</span>
                </h3>
                <p className="text-xs text-[#8b96b8] font-mono mt-0.5 truncate max-w-sm">
                  {selectedScanDetail.name} ({selectedScanDetail.url})
                </p>
              </div>
              <button
                onClick={() => setSelectedScanDetail(null)}
                className="text-[#8b96b8] hover:text-[#e8ecf6]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div className="p-3 bg-[#0c1222] rounded-lg border border-[#1f2b45] flex items-center justify-between">
                <div>
                  <span className="text-xs text-[#8b96b8]">総合リスク評価:</span>
                  <div className="text-sm font-bold mt-0.5">
                    {selectedScanDetail.status === 'normal' && (
                      <span className="text-[#3ddc97]">● 安全 (Safe) - リスクスコア 0</span>
                    )}
                    {selectedScanDetail.status === 'warning' && (
                      <span className="text-[#ffa000]">▲ 警告 (Warning) - リスクスコア {selectedScanDetail.lastScanResult?.riskScore}</span>
                    )}
                    {selectedScanDetail.status === 'danger' && (
                      <span className="text-[#ff5c7a]">■ 危険 (Danger) - リスクスコア {selectedScanDetail.lastScanResult?.riskScore}</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => {
                    scanSite(selectedScanDetail.id);
                    setSelectedScanDetail(null);
                  }}
                  className="px-3 py-1.5 bg-[#ffa000] hover:bg-[#ffb300] text-[#0a101d] rounded text-xs font-bold transition cursor-pointer"
                >
                  再スキャン
                </button>
              </div>

              <div>
                <h4 className="text-xs font-bold text-[#8b96b8] mb-2 uppercase tracking-wider">
                  検出項目・診断所見
                </h4>
                <div className="space-y-2">
                  {selectedScanDetail.lastScanResult?.issues.map((issue, idx) => (
                    <div
                      key={idx}
                      className={`p-2.5 rounded text-xs flex items-start gap-2 border ${
                        selectedScanDetail.status === 'danger'
                          ? 'bg-[#ff5c7a]/10 border-[#ff5c7a]/30 text-[#ff5c7a]'
                          : selectedScanDetail.status === 'warning'
                          ? 'bg-[#ffa000]/10 border-[#ffa000]/30 text-[#ffa000]'
                          : 'bg-[#3ddc97]/10 border-[#3ddc97]/30 text-[#3ddc97]'
                      }`}
                    >
                      <span className="shrink-0">•</span>
                      <span>{issue}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-[#0c1222] rounded-lg border border-[#1f2b45] text-[11px] text-[#8b96b8] space-y-1">
                <div>・HTTPS通信暗号化: {selectedScanDetail.lastScanResult?.isHttps ? '対応済 (OK)' : '未対応 (HTTP警告)'}</div>
                <div>・危険な拡張子 (.exe, .bat等): {selectedScanDetail.lastScanResult?.hasRiskyExt ? '検出あり (危険)' : '検出なし (安全)'}</div>
                <div>・短縮URL (bit.ly等): {selectedScanDetail.lastScanResult?.isShortUrl ? '検出あり (警告)' : '検出なし'}</div>
                <div>・IDN偽装ドメイン (xn--): {selectedScanDetail.lastScanResult?.isSuspiciousIdn ? '検出あり' : '検出なし'}</div>
              </div>
            </div>

            <div className="mt-5 text-right">
              <button
                onClick={() => setSelectedScanDetail(null)}
                className="px-4 py-1.5 bg-[#0c1222] hover:bg-[#1a233a] text-[#e8ecf6] rounded text-xs font-semibold border border-[#1f2b45] cursor-pointer"
              >
                閉じる
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
