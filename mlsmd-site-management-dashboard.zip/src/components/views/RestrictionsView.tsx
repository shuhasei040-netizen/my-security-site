import React, { useState } from 'react';
import { useSecurity } from '../../context/SecurityContext';
import { Restriction, RestrictionType } from '../../types/security';
import {
  Lock,
  Plus,
  ShieldAlert,
  AlertTriangle,
  Clock,
  Trash2,
  Key,
  ShieldCheck,
  CheckCircle,
  X,
  RotateCcw,
} from 'lucide-react';

export const RestrictionsView: React.FC = () => {
  const {
    restrictions,
    applyRestriction,
    removeRestriction,
    repelLockdownAndRestore,
    emergencyMasterKeyOverride,
    emergencyOverrideActive,
    currentUser,
    showToast,
  } = useSecurity();

  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [selectedType, setSelectedType] = useState<RestrictionType>('full_lockdown');
  const [reason, setReason] = useState('');
  const [durationMinutes, setDurationMinutes] = useState(60);

  // Master key input for emergency panel
  const [emergencyKeyInput, setEmergencyKeyInput] = useState('');

  const suspiciousRestrictions = restrictions.filter(r => r.status === 'active' && r.trustScore < 40);

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      showToast('制限の理由を入力してください', 'error');
      return;
    }
    const success = applyRestriction(selectedType, reason, durationMinutes);
    if (success) {
      setIsApplyModalOpen(false);
      setReason('');
    }
  };

  const handleEmergencySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emergencyKeyInput.trim()) {
      showToast('マスターキーを入力してください', 'error');
      return;
    }
    const res = emergencyMasterKeyOverride(emergencyKeyInput);
    if (res) {
      setEmergencyKeyInput('');
    }
  };

  const getRemainingTimeText = (r: Restriction) => {
    if (r.status === 'expired') return '期限切れ';
    if (r.status === 'bypassed') return 'バイパス（無効中）';
    const now = Date.now();
    const exp = new Date(r.expiresAt).getTime();
    const diffMs = exp - now;
    if (diffMs <= 0) return '期限切れ';
    const minutes = Math.ceil(diffMs / (1000 * 60));
    return `残り約 ${minutes} 分`;
  };

  return (
    <div className="space-y-6">
      {/* Top Suspicious Restrictions Alert */}
      {suspiciousRestrictions.length > 0 && (
        <div className="p-4 rounded-xl bg-[#ff5c7a]/15 border border-[#ff5c7a]/40 text-[#ff5c7a] flex items-start justify-between gap-3 shadow-sm">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5" />
            <div className="text-xs">
              <div className="font-bold text-sm text-[#e8ecf6] mb-1">
                🚨 警告：信頼性スコアが40点未満の制限が {suspiciousRestrictions.length} 件稼働しています
              </div>
              <p className="text-[#8b96b8] leading-relaxed">
                未検証アカウントまたは短時間のスパム操作により適用された疑いがあります。
                被害を防止するため、<strong>閲覧者(L1)や編集者(L2)でも即座に解除・削除</strong>できるように設計されています。
              </p>
            </div>
          </div>
          <button
            onClick={repelLockdownAndRestore}
            className="shrink-0 px-3 py-1.5 bg-[#ff5c7a] hover:bg-[#ff5c7a]/90 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
          >
            今すぐ弾き返し
          </button>
        </div>
      )}

      {/* Header and Apply / Repel Buttons */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#111726] p-4 rounded-xl border border-[#1f2b45]">
        <div>
          <h2 className="text-sm font-bold text-[#e8ecf6] flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#ffa000]" />
            <span>アクセス制限・セキュリティルール ({restrictions.length}件)</span>
          </h2>
          <p className="text-xs text-[#8b96b8]">
            動的信頼スコア自動計算・自動有効期限・反撃シールドによる不当制限の無力化
          </p>
        </div>

        <div className="flex items-center gap-2">
          {restrictions.length > 0 && (
            <button
              onClick={repelLockdownAndRestore}
              className="flex items-center gap-1.5 px-3 py-2 bg-[#ff5c7a]/15 hover:bg-[#ff5c7a]/25 text-[#ff5c7a] border border-[#ff5c7a]/40 rounded-lg text-xs font-bold transition cursor-pointer"
              title="すべての制限を弾き返し、アクセスを復旧します"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>制限を強制弾き返し</span>
            </button>
          )}

          <button
            onClick={() => {
              if (currentUser?.role !== 'L3') {
                showToast('🚫 権限がありません（制限の新規適用にはL3管理者権限が必要です）', 'error');
                return;
              }
              setIsApplyModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-[#ffa000] to-[#ffca28] text-[#0a101d] rounded-lg text-xs font-bold transition shadow-md shadow-[#ffa000]/20 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ 新規制限ルールを適用</span>
          </button>
        </div>
      </div>

      {/* Restrictions Table or Clean Empty State */}
      {restrictions.length === 0 ? (
        <div className="p-8 rounded-xl bg-[#111726] border border-[#1f2b45] text-center max-w-xl mx-auto my-4">
          <div className="w-12 h-12 rounded-xl bg-[#3ddc97]/15 border border-[#3ddc97]/30 text-[#3ddc97] flex items-center justify-center mx-auto mb-3">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-bold text-[#e8ecf6] mb-1">
            現在アクティブな制限はありません
          </h3>
          <p className="text-xs text-[#8b96b8] leading-relaxed">
            システムは通常稼働しており、全ユーザーおよびサイトへのアクセスは正常に保護されています。
          </p>
        </div>
      ) : (
        <div className="rounded-xl bg-[#111726] border border-[#1f2b45] overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-[#0c1222] text-[#8b96b8] border-b border-[#1f2b45]">
                  <th className="py-3.5 px-4 font-semibold">制限内容 / 種別</th>
                  <th className="py-3.5 px-4 font-semibold">実行者</th>
                  <th className="py-3.5 px-4 font-semibold">信頼度スコア</th>
                  <th className="py-3.5 px-4 font-semibold">残り有効期間</th>
                  <th className="py-3.5 px-4 font-semibold">状態</th>
                  <th className="py-3.5 px-4 font-semibold text-right">アクション</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1f2b45]/60">
                {restrictions.map(r => {
                  const isLowTrust = r.trustScore < 40;
                  const isMediumTrust = r.trustScore >= 40 && r.trustScore < 70;
                  const isHighTrust = r.trustScore >= 70;

                  const canDelete =
                    isLowTrust ||
                    (isMediumTrust && (currentUser?.role === 'L2' || currentUser?.role === 'L3')) ||
                    currentUser?.role === 'L3';

                  return (
                    <tr
                      key={r.id}
                      className={`hover:bg-[#0c1222]/40 transition ${
                        isLowTrust ? 'bg-[#ff5c7a]/5' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-[#e8ecf6] flex items-center gap-1.5">
                          <span>{r.typeLabel}</span>
                          {emergencyOverrideActive && (
                            <span className="text-[10px] text-[#ff5c7a] font-mono">
                              [BYPASSED]
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-[#8b96b8] mt-0.5 max-w-sm">
                          {r.reason}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-[#e8ecf6]">{r.appliedBy}</div>
                        <div className="text-[10px] text-[#8b96b8]">
                          {r.appliedByRole} · {r.isCreatorVerified ? '検証済' : '未検証'}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`font-mono font-bold text-xs ${
                              isHighTrust
                                ? 'text-[#3ddc97]'
                                : isMediumTrust
                                ? 'text-[#ffa000]'
                                : 'text-[#ff5c7a]'
                            }`}
                          >
                            {r.trustScore} 点
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                              isHighTrust
                                ? 'bg-[#3ddc97]/15 text-[#3ddc97]'
                                : isMediumTrust
                                ? 'bg-[#ffa000]/15 text-[#ffa000]'
                                : 'bg-[#ff5c7a]/15 text-[#ff5c7a]'
                            }`}
                          >
                            {isHighTrust
                              ? '高信頼'
                              : isMediumTrust
                              ? '中程度'
                              : '低信頼（誰でも削除可）'}
                          </span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-[11px] text-[#8b96b8] whitespace-nowrap">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>{getRemainingTimeText(r)}</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {r.status === 'active' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-[#ffa000]/15 text-[#ffa000] border border-[#ffa000]/30">
                            稼働中
                          </span>
                        )}
                        {r.status === 'bypassed' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-[#1a73e8]/15 text-[#1a73e8] border border-[#1a73e8]/30">
                            無視モード (Bypassed)
                          </span>
                        )}
                        {r.status === 'expired' && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-[#1f2b45] text-[#8b96b8]">
                            期限切れ
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        {canDelete ? (
                          <button
                            onClick={() => removeRestriction(r.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#ff5c7a]/20 hover:bg-[#ff5c7a]/30 text-[#ff5c7a] rounded text-xs font-semibold border border-[#ff5c7a]/40 transition cursor-pointer"
                            title={
                              isLowTrust
                                ? '信頼スコア40点未満のため誰でも解除可能'
                                : '制限を解除・削除'
                            }
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>解除・削除</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-[#8b96b8]/60">
                            解除権限なし (L3要)
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Emergency Master Key Bypass & Anti-Lockdown Repel Panel */}
      <div className="rounded-xl bg-[#111726] border-2 border-[#ff5c7a]/40 p-5 sm:p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#ff5c7a]/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="max-w-xl">
            <div className="flex items-center gap-2 text-sm font-bold text-[#ff5c7a] mb-1">
              <Key className="w-4 h-4" />
              <span>🚨 緊急復旧・ハッカー制限強制弾き返しモード</span>
            </div>
            <p className="text-xs text-[#8b96b8] leading-relaxed">
              悪意のあるハッカーや不正アカウントによってシステム全体がロックダウンされた場合、
              ワンクリックまたはマスターキー入力で<strong>すべての制限を強制的に弾き返し無力化</strong>し、
              最高権限で完全復旧します。
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch gap-2 w-full lg:w-auto">
            <button
              onClick={repelLockdownAndRestore}
              className="px-4 py-2 bg-[#ff5c7a] hover:bg-[#ff5c7a]/90 text-white rounded-lg text-xs font-bold transition shadow-md shadow-[#ff5c7a]/30 whitespace-nowrap cursor-pointer flex items-center justify-center gap-1.5"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>ワンクリックで制限を弾き返す</span>
            </button>

            <form onSubmit={handleEmergencySubmit} className="flex gap-2">
              <input
                type="password"
                value={emergencyKeyInput}
                onChange={e => setEmergencyKeyInput(e.target.value)}
                placeholder="MASTER-2024-OVERRIDE"
                className="bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] placeholder-[#8b96b8]/60 focus:outline-none focus:border-[#ff5c7a] min-w-[190px]"
              />
              <button
                type="submit"
                className="px-3 py-2 bg-[#1f2b45] hover:bg-[#2a3a5e] text-[#e8ecf6] rounded-lg text-xs font-semibold border border-[#2a3a5e] transition whitespace-nowrap cursor-pointer"
              >
                復旧
              </button>
            </form>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t border-[#1f2b45] flex flex-wrap items-center justify-between text-[11px] text-[#8b96b8]">
          <span>シークレットマスターキー：<code>MASTER-2024-OVERRIDE</code></span>
          <span>実行ログは改ざん防止台帳に「EMERGENCY_OVERRIDE」として永続記録されます</span>
        </div>
      </div>

      {/* Apply Restriction Modal */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#111726] border border-[#1f2b45] rounded-xl shadow-2xl p-6">
            <div className="flex items-center justify-between mb-4 border-b border-[#1f2b45] pb-3">
              <h3 className="font-bold text-base text-[#e8ecf6] flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#ffa000]" />
                <span>新規制限ルールの適用 (L3管理者)</span>
              </h3>
              <button
                onClick={() => setIsApplyModalOpen(false)}
                className="text-[#8b96b8] hover:text-[#e8ecf6]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleApply} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  制限の種類 <span className="text-[#ff5c7a]">*</span>
                </label>
                <select
                  value={selectedType}
                  onChange={e => setSelectedType(e.target.value as RestrictionType)}
                  className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                >
                  <option value="full_lockdown">フルロックダウン（全ユーザーアクセス制限）</option>
                  <option value="read_only">読み取り専用モード（変更・更新の停止）</option>
                  <option value="revoke_admin">管理者権限剥奪制限（特権の一時凍結）</option>
                  <option value="site_block">特定サイトアクセス遮断</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  適用の理由（テキスト） <span className="text-[#ff5c7a]">*</span>
                </label>
                <textarea
                  required
                  rows={3}
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                  placeholder="例: 不正アクセス検知による一時的隔離措置"
                  className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#8b96b8] mb-1">
                  有効期間（分、デフォルト60分・自動期限切れ）
                </label>
                <input
                  type="number"
                  min={1}
                  max={1440}
                  value={durationMinutes}
                  onChange={e => setDurationMinutes(Number(e.target.value) || 60)}
                  className="w-full bg-[#0c1222] border border-[#1f2b45] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                />
                <span className="text-[11px] text-[#8b96b8] mt-1 block">
                  時間経過とともに自動的に無効化され、永久ロックを防止します。
                </span>
              </div>

              <div className="p-3 bg-[#ff5c7a]/10 border border-[#ff5c7a]/30 rounded-lg text-xs text-[#ff5c7a]">
                ⚠️ この制限操作は実行者IDとCRC-32ハッシュとともに改ざん防止ログに永久記録されます。
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1f2b45]">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-4 py-2 bg-[#0c1222] hover:bg-[#1a233a] text-[#8b96b8] rounded-lg text-xs font-medium transition cursor-pointer"
                >
                  キャンセル
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-[#ffa000] to-[#ffca28] text-[#0a101d] rounded-lg text-xs font-bold transition shadow-md shadow-[#ffa000]/20 cursor-pointer"
                >
                  制限を適用する
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
