import React, { useState } from 'react';
import { useSecurity } from '../../context/SecurityContext';
import {
  Settings,
  Key,
  Download,
  Upload,
  RotateCcw,
  Clock,
  ShieldCheck,
  FileCode,
  Sparkles,
  AlertTriangle,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    exportJsonBackup,
    importJsonBackup,
    downloadStandaloneHtml,
    resetToDefaults,
    runTestScenario,
    emergencyOverrideActive,
    showToast,
  } = useSecurity();

  const [importJsonText, setImportJsonText] = useState('');
  const [showImportBox, setShowImportBox] = useState(false);

  const handleImport = () => {
    if (!importJsonText.trim()) return;
    const success = importJsonBackup(importJsonText);
    if (success) {
      setImportJsonText('');
      setShowImportBox(false);
    }
  };

  const handleReset = () => {
    if (confirm('システムデータを初期状態にリセットしますか？現在の追加データは消去されます。')) {
      resetToDefaults();
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Test Scenarios Runner Box (Prominently featured from prompt specs) */}
      <div className="p-6 rounded-xl bg-[#0f1420] border-2 border-[#5b8cff]/30 shadow-lg">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-5 h-5 text-[#5b8cff]" />
          <h3 className="font-bold text-base text-[#e8ecf6]">
            仕様書テストシナリオ自動実行 (One-Click Verification)
          </h3>
        </div>
        <p className="text-xs text-[#8b96b8] mb-5">
          仕様書に定義された4つの主要テストシナリオをワンクリックでシミュレートし、システムの挙動を検証できます。
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550] flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-[#ff5c7a] mb-1">
                テスト1：ハッカーが管理権限を奪った場合の回復
              </div>
              <p className="text-[11px] text-[#8b96b8] leading-relaxed">
                ハッカーによる「フルロックダウン」を適用。マスターキー <code>MASTER-2024-OVERRIDE</code> を用いて緊急復旧と制限の無視モード移行を検証します。
              </p>
            </div>
            <button
              onClick={() => runTestScenario(1)}
              className="mt-3 px-3 py-1.5 bg-[#ff5c7a]/20 hover:bg-[#ff5c7a]/30 text-[#ff5c7a] border border-[#ff5c7a]/40 rounded text-xs font-semibold transition cursor-pointer"
            >
              ▶ テスト1を実行（ロックダウン発生）
            </button>
          </div>

          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550] flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-[#ffb547] mb-1">
                テスト2：悪質なユーザーが不正な制限をかけた場合
              </div>
              <p className="text-[11px] text-[#8b96b8] leading-relaxed">
                未検証アカウントによる制限適用をシミュレート。信頼スコアが35点（&lt;40点）となり、L1/L2を含む誰でも即座に解除・削除できることを検証します。
              </p>
            </div>
            <button
              onClick={() => runTestScenario(2)}
              className="mt-3 px-3 py-1.5 bg-[#ffb547]/20 hover:bg-[#ffb547]/30 text-[#ffb547] border border-[#ffb547]/40 rounded text-xs font-semibold transition cursor-pointer"
            >
              ▶ テスト2を実行（低信頼制限の注入）
            </button>
          </div>

          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550] flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-[#5b8cff] mb-1">
                テスト3：ウイルス・マルウェア簡易スキャン
              </div>
              <p className="text-[11px] text-[#8b96b8] leading-relaxed">
                短縮URL（bit.ly）と危険な拡張子（.exe）を持つテストサイトを登録し、セキュリティスキャンが「危険」を即時検知することを検証します。
              </p>
            </div>
            <button
              onClick={() => runTestScenario(3)}
              className="mt-3 px-3 py-1.5 bg-[#5b8cff]/20 hover:bg-[#5b8cff]/30 text-[#5b8cff] border border-[#5b8cff]/40 rounded text-xs font-semibold transition cursor-pointer"
            >
              ▶ テスト3を実行（悪意URLの登録と検知）
            </button>
          </div>

          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550] flex flex-col justify-between">
            <div>
              <div className="text-xs font-bold text-[#3ddc97] mb-1">
                テスト4：ログインの試行錯誤（ID列挙防御）
              </div>
              <p className="text-[11px] text-[#8b96b8] leading-relaxed">
                存在しないID「hacker123」での不正アクセス試行を発生させ、理由を隠蔽しつつ改ざん不能ログに記録されることを検証します。
              </p>
            </div>
            <button
              onClick={() => runTestScenario(4)}
              className="mt-3 px-3 py-1.5 bg-[#3ddc97]/20 hover:bg-[#3ddc97]/30 text-[#3ddc97] border border-[#3ddc97]/40 rounded text-xs font-semibold transition cursor-pointer"
            >
              ▶ テスト4を実行（ID列挙攻撃の監視ログ記録）
            </button>
          </div>
        </div>
      </div>

      {/* Standalone HTML File Export Box */}
      <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550]">
        <div className="flex items-center gap-2 mb-2">
          <FileCode className="w-5 h-5 text-[#3ddc97]" />
          <h3 className="font-bold text-base text-[#e8ecf6]">
            単一HTMLファイル（site-manager-security.html）の保存
          </h3>
        </div>
        <p className="text-xs text-[#8b96b8] mb-4 leading-relaxed">
          外部ファイル参照なしの単一HTMLファイルとしてダウンロードします。
          Webサーバー不要で、ブラウザでのダブルクリック（<code>file://</code>）でも完全に動作します。
        </p>

        <button
          onClick={downloadStandaloneHtml}
          className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-[#3ddc97] to-[#10b981] hover:opacity-90 text-[#0a0e1a] rounded-lg text-xs font-bold transition shadow-md shadow-[#3ddc97]/20 cursor-pointer"
        >
          <FileCode className="w-4 h-4" />
          <span>📥 site-manager-security.html をダウンロード</span>
        </button>
      </div>

      {/* Secret Master Key Info */}
      <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550]">
        <div className="flex items-center gap-2 mb-2">
          <Key className="w-5 h-5 text-[#ff5c7a]" />
          <h3 className="font-bold text-base text-[#e8ecf6]">マスターキー構成（最高レベル認証）</h3>
        </div>
        <p className="text-xs text-[#8b96b8] mb-4">
          ハッカーによるロックダウン制限の突破およびシステム復旧のための専用認証キー。
        </p>

        <div className="p-3.5 bg-[#161d2e] rounded-lg border border-[#2a3550] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div>
            <span className="text-[#8b96b8] block">有効なシークレットマスターキー:</span>
            <code className="text-[#ff5c7a] font-bold font-mono text-sm">MASTER-2024-OVERRIDE</code>
          </div>
          <div className="text-[11px] text-[#8b96b8]">
            {emergencyOverrideActive ? (
              <span className="text-[#ff5c7a] font-bold">● 現在緊急復旧バイパス発動中</span>
            ) : (
              <span className="text-[#3ddc97]">● 通常監視待機中</span>
            )}
          </div>
        </div>
      </div>

      {/* Session Security & Timeout */}
      <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550]">
        <div className="flex items-center gap-2 mb-2">
          <Clock className="w-5 h-5 text-[#5b8cff]" />
          <h3 className="font-bold text-base text-[#e8ecf6]">セッションタイムアウト設定</h3>
        </div>
        <p className="text-xs text-[#8b96b8] mb-3">
          離席時の不正操作を防止するため、30分間無操作状態が続くと自動ログアウトされます。
        </p>
        <div className="text-xs text-[#e8ecf6] flex items-center gap-2">
          <span className="px-2 py-1 bg-[#161d2e] border border-[#2a3550] rounded font-mono">
            30 分（アクティブリスナー稼働中）
          </span>
          <span className="text-[#3ddc97] text-xs">✓ 有効</span>
        </div>
      </div>

      {/* Data Backup & Restore */}
      <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550] space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <Download className="w-5 h-5 text-[#5b8cff]" />
          <h3 className="font-bold text-base text-[#e8ecf6]">データバックアップ & 復元</h3>
        </div>
        <p className="text-xs text-[#8b96b8]">
          全サイト情報・アカウント・制限・ログをJSON形式でダウンロードまたはリストアできます。
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={exportJsonBackup}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#161d2e] hover:bg-[#2a3550] text-[#e8ecf6] border border-[#2a3550] rounded-lg text-xs font-semibold transition cursor-pointer"
          >
            <Download className="w-4 h-4 text-[#5b8cff]" />
            <span>JSONエクスポート</span>
          </button>

          <button
            onClick={() => setShowImportBox(!showImportBox)}
            className="flex items-center gap-1.5 px-4 py-2 bg-[#161d2e] hover:bg-[#2a3550] text-[#e8ecf6] border border-[#2a3550] rounded-lg text-xs font-semibold transition cursor-pointer"
          >
            <Upload className="w-4 h-4 text-[#7c5bff]" />
            <span>JSONバックアップから復元</span>
          </button>
        </div>

        {showImportBox && (
          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550] space-y-3">
            <label className="block text-xs font-semibold text-[#8b96b8]">
              エクスポートされたJSONテキストを貼り付けてください:
            </label>
            <textarea
              rows={4}
              value={importJsonText}
              onChange={e => setImportJsonText(e.target.value)}
              placeholder="バックアップファイルのJSONテキスト..."
              className="w-full bg-[#0f1420] border border-[#2a3550] rounded p-2 text-xs text-[#e8ecf6] font-mono focus:outline-none focus:border-[#5b8cff]"
            />
            <button
              onClick={handleImport}
              className="px-4 py-1.5 bg-[#5b8cff] hover:bg-[#5b8cff]/90 text-white rounded text-xs font-semibold transition cursor-pointer"
            >
              復元を実行
            </button>
          </div>
        )}
      </div>

      {/* Danger Zone: Reset */}
      <div className="p-6 rounded-xl bg-[#0f1420] border border-[#ff5c7a]/30">
        <h3 className="font-bold text-sm text-[#ff5c7a] mb-1">データ初期化（リセット）</h3>
        <p className="text-xs text-[#8b96b8] mb-4">
          ローカルストレージに保存されているサイトや制限、ログを初期状態に戻します。
        </p>
        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 px-4 py-2 bg-[#ff5c7a]/20 hover:bg-[#ff5c7a]/30 text-[#ff5c7a] border border-[#ff5c7a]/40 rounded-lg text-xs font-semibold transition cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>初期状態にリセット</span>
        </button>
      </div>
    </div>
  );
};
