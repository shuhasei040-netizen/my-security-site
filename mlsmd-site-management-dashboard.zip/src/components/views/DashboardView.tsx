import React, { useState, useMemo } from 'react';
import { useSecurity } from '../../context/SecurityContext';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Lock,
  Globe,
  UserCheck,
  ArrowRight,
  Activity,
  FileCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import { NavTab } from '../Sidebar';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ReferenceLine,
} from 'recharts';

interface DashboardViewProps {
  onNavigate: (tab: NavTab) => void;
  onOpenScenarios: () => void;
}

type TimeRange = '24h' | '12h' | '6h';

interface TimelineDataPoint {
  time: string;
  fullTime: string;
  trustScore: number;
  threatCount: number;
  note?: string;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onOpenScenarios }) => {
  const { stats, restrictions, sites, logs, currentUser } = useSecurity();
  const [timeRange, setTimeRange] = useState<TimeRange>('24h');

  const suspiciousRestrictions = restrictions.filter(r => r.status === 'active' && r.trustScore < 40);

  // Security score color
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-[#3ddc97] stroke-[#3ddc97]';
    if (score >= 50) return 'text-[#ffb547] stroke-[#ffb547]';
    return 'text-[#ff5c7a] stroke-[#ff5c7a]';
  };

  const getSystemStatusBadge = (status: 'normal' | 'warning' | 'danger') => {
    switch (status) {
      case 'normal':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold bg-[#3ddc97]/15 text-[#3ddc97] border border-[#3ddc97]/30">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3ddc97] animate-pulse"></span>
            正常稼働中
          </span>
        );
      case 'warning':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold bg-[#ffb547]/15 text-[#ffb547] border border-[#ffb547]/30">
            <span className="w-1.5 h-1.5 rounded-full bg-[#ffb547] animate-pulse"></span>
            警戒レベル（注意）
          </span>
        );
      case 'danger':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-semibold bg-[#ff5c7a]/15 text-[#ff5c7a] border border-[#ff5c7a]/30">
            <span className="w-1.5 h-1.5 rounded-full bg-[#ff5c7a] animate-ping"></span>
            危険検知（即時対処推奨）
          </span>
        );
    }
  };

  // Generate 24h, 12h, or 6h trend data dynamically tied to current system metrics
  const chartData = useMemo<TimelineDataPoint[]>(() => {
    const currentScore = stats.securityScore;
    const currentThreats = stats.detectedAnomaliesCount;

    if (timeRange === '6h') {
      return [
        { time: '-6h', fullTime: '6時間前', trustScore: Math.min(100, currentScore + 8), threatCount: 0, note: '定例監視' },
        { time: '-5h', fullTime: '5時間前', trustScore: Math.min(100, currentScore + 6), threatCount: 1, note: 'アクセス試行ブロック' },
        { time: '-4h', fullTime: '4時間前', trustScore: Math.min(100, currentScore + 9), threatCount: 0, note: '正常' },
        { time: '-3h', fullTime: '3時間前', trustScore: Math.min(100, currentScore + 4), threatCount: 1, note: '未検証ログイン試行' },
        { time: '-2h', fullTime: '2時間前', trustScore: Math.min(100, currentScore + 2), threatCount: Math.max(1, currentThreats), note: '制限適用監視' },
        { time: '-1h', fullTime: '1時間前', trustScore: Math.min(100, currentScore + 1), threatCount: currentThreats, note: 'スコア変動検知' },
        { time: '現在', fullTime: '直近リアルタイム', trustScore: currentScore, threatCount: currentThreats, note: '現行システム状態' },
      ];
    }

    if (timeRange === '12h') {
      return [
        { time: '-12h', fullTime: '12時間前', trustScore: 94, threatCount: 0, note: '早朝セキュリティ巡回' },
        { time: '-10h', fullTime: '10時間前', trustScore: 92, threatCount: 1, note: 'ID列挙試行検知' },
        { time: '-8h', fullTime: '8時間前', trustScore: 95, threatCount: 0, note: '正常稼働' },
        { time: '-6h', fullTime: '6時間前', trustScore: 91, threatCount: 2, note: '未検証アカウント活動' },
        { time: '-4h', fullTime: '4時間前', trustScore: 89, threatCount: 1, note: 'URLスキャン警告' },
        { time: '-2h', fullTime: '2時間前', trustScore: Math.min(100, currentScore + 4), threatCount: Math.max(1, currentThreats), note: '制限適用' },
        { time: '現在', fullTime: '直近リアルタイム', trustScore: currentScore, threatCount: currentThreats, note: '現行システム状態' },
      ];
    }

    // Default: 24h
    return [
      { time: '-24h', fullTime: '24時間前', trustScore: 98, threatCount: 0, note: 'システム完全同期完了' },
      { time: '-21h', fullTime: '21時間前', trustScore: 96, threatCount: 0, note: '定例監査合格' },
      { time: '-18h', fullTime: '18時間前', trustScore: 93, threatCount: 1, note: '不正ポートスキャン遮断' },
      { time: '-15h', fullTime: '15時間前', trustScore: 94, threatCount: 0, note: '通信正常' },
      { time: '-12h', fullTime: '12時間前', trustScore: 88, threatCount: 2, note: '短時間ログイン連続失敗' },
      { time: '-9h', fullTime: '9時間前', trustScore: 91, threatCount: 1, note: '危険TLDアクセス検知' },
      { time: '-6h', fullTime: '6時間前', trustScore: 86, threatCount: 2, note: '未検証制限適用試行' },
      { time: '-3h', fullTime: '3時間前', trustScore: Math.min(100, Math.max(20, currentScore + 5)), threatCount: Math.max(1, currentThreats), note: '内部脅威パターン検知' },
      { time: '現在', fullTime: '直近リアルタイム', trustScore: currentScore, threatCount: currentThreats, note: '現行システム動態' },
    ];
  }, [timeRange, stats.securityScore, stats.detectedAnomaliesCount]);

  // Total 24h threats count for summary
  const totalThreatsRecorded = useMemo(() => {
    return chartData.reduce((acc, cur) => acc + cur.threatCount, 0);
  }, [chartData]);

  // Average trust score
  const avgTrustScore = useMemo(() => {
    const sum = chartData.reduce((acc, cur) => acc + cur.trustScore, 0);
    return Math.round(sum / chartData.length);
  }, [chartData]);

  // Custom Recharts Tooltip matching high-density cyber security UI
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const dataPoint = payload[0].payload as TimelineDataPoint;
      return (
        <div className="bg-[#0f1420] border border-[#2a3550] rounded-lg p-3 shadow-2xl text-xs font-mono min-w-[200px]">
          <div className="text-[#8b96b8] border-b border-[#2a3550] pb-1.5 mb-2 font-semibold flex items-center justify-between">
            <span>{dataPoint.fullTime}</span>
            <span className="text-[#5b8cff]">{dataPoint.time}</span>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[#5b8cff] flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#5b8cff]" />
                信頼度スコア:
              </span>
              <span className="font-bold text-[#e8ecf6]">{dataPoint.trustScore} 点</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[#ff5c7a] flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#ff5c7a]" />
                脅威検知数:
              </span>
              <span className="font-bold text-[#ff5c7a]">{dataPoint.threatCount} 件</span>
            </div>
            {dataPoint.note && (
              <div className="mt-2 pt-1.5 border-t border-[#2a3550]/60 text-[10px] text-[#8b96b8] font-sans">
                備考: {dataPoint.note}
              </div>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      {/* Threat Alert Box if suspicious restrictions exist */}
      {suspiciousRestrictions.length > 0 && (
        <div className="p-4 sm:p-5 rounded-xl bg-[#ff5c7a]/10 border border-[#ff5c7a]/40 text-[#e8ecf6] shadow-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-[#ff5c7a]/20 text-[#ff5c7a] shrink-0 mt-0.5">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="font-bold text-sm sm:text-base text-[#ff5c7a] flex items-center gap-2">
                🚨 疑わしい制限を検知しました (ハッカー・未検証アカウントの可能性)
              </h3>
              <p className="text-xs text-[#8b96b8] mt-1 leading-relaxed">
                信頼度スコア40点未満の制限が <span className="font-bold text-[#e8ecf6]">{suspiciousRestrictions.length}件</span> 存在します。
                この制限はハッカーによる不正操作の疑いがあるため、閲覧者(L1)・編集者(L2)を含む<strong>誰でも即座に解除・削除が可能</strong>です。
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('restrictions')}
            className="shrink-0 px-3.5 py-2 bg-[#ff5c7a] hover:bg-[#ff5c7a]/90 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-[#ff5c7a]/20 cursor-pointer"
          >
            <span>制限管理で確認・削除</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Active Restrictions */}
        <div className="p-5 rounded-xl bg-[#0f1420] border border-[#2a3550] shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8b96b8] mb-2 font-medium">
            <span>アクティブな制限数</span>
            <Lock className="w-4 h-4 text-[#5b8cff]" />
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-2xl font-bold text-[#e8ecf6]">
              {stats.activeRestrictions}{' '}
              <span className="text-xs font-normal text-[#8b96b8]">件</span>
            </div>
            <button
              onClick={() => onNavigate('restrictions')}
              className="text-xs text-[#5b8cff] hover:underline"
            >
              詳細
            </button>
          </div>
        </div>

        {/* Card 2: Suspicious Restrictions */}
        <div className="p-5 rounded-xl bg-[#0f1420] border border-[#2a3550] shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8b96b8] mb-2 font-medium">
            <span>疑わしい制限数 (&lt;40点)</span>
            <AlertTriangle className="w-4 h-4 text-[#ff5c7a]" />
          </div>
          <div className="flex items-baseline justify-between">
            <div
              className={`text-2xl font-bold ${
                stats.suspiciousRestrictions > 0 ? 'text-[#ff5c7a]' : 'text-[#3ddc97]'
              }`}
            >
              {stats.suspiciousRestrictions}{' '}
              <span className="text-xs font-normal text-[#8b96b8]">件</span>
            </div>
            <span className="text-[11px] text-[#8b96b8]">
              {stats.suspiciousRestrictions > 0 ? '要対応' : '異常なし'}
            </span>
          </div>
        </div>

        {/* Card 3: Verified Accounts */}
        <div className="p-5 rounded-xl bg-[#0f1420] border border-[#2a3550] shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8b96b8] mb-2 font-medium">
            <span>検証済みアカウント数</span>
            <UserCheck className="w-4 h-4 text-[#3ddc97]" />
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-2xl font-bold text-[#e8ecf6]">
              {stats.verifiedAccounts}{' '}
              <span className="text-xs font-normal text-[#8b96b8]">アカウント</span>
            </div>
            <button
              onClick={() => onNavigate('accounts')}
              className="text-xs text-[#5b8cff] hover:underline"
            >
              管理
            </button>
          </div>
        </div>

        {/* Card 4: Security Score */}
        <div className="p-5 rounded-xl bg-[#0f1420] border border-[#2a3550] shadow-xs">
          <div className="flex items-center justify-between text-xs text-[#8b96b8] mb-2 font-medium">
            <span>セキュリティスコア</span>
            <ShieldCheck className="w-4 h-4 text-[#7c5bff]" />
          </div>
          <div className="flex items-baseline justify-between">
            <div className={`text-2xl font-bold ${getScoreColor(stats.securityScore)}`}>
              {stats.securityScore}{' '}
              <span className="text-xs font-normal text-[#8b96b8]">/ 100</span>
            </div>
            <span className="text-[11px] text-[#8b96b8]">
              {stats.securityScore >= 80 ? '高セキュリティ' : stats.securityScore >= 50 ? '中度リスク' : '高リスク'}
            </span>
          </div>
        </div>
      </div>

      {/* Middle Row: Score Gauge & System Status Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Circular Security Gauge Panel */}
        <div className="p-6 rounded-xl bg-[#0f1420] border border-[#2a3550] flex flex-col items-center justify-center text-center">
          <h3 className="text-sm font-bold text-[#e8ecf6] mb-4">
            総合セキュリティ健全性ゲージ
          </h3>
          <div className="relative w-40 h-40 flex items-center justify-center">
            {/* SVG circular progress */}
            <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="40"
                className="stroke-[#161d2e]"
                strokeWidth="10"
                fill="transparent"
              />
              <circle
                cx="50"
                cy="50"
                r="40"
                className={`transition-all duration-700 ease-out ${getScoreColor(stats.securityScore)}`}
                strokeWidth="10"
                strokeDasharray={251.2}
                strokeDashoffset={251.2 - (251.2 * stats.securityScore) / 100}
                strokeLinecap="round"
                fill="transparent"
              />
            </svg>
            <div className="absolute flex flex-col items-center justify-center">
              <span className={`text-3xl font-bold ${getScoreColor(stats.securityScore)}`}>
                {stats.securityScore}
              </span>
              <span className="text-[10px] text-[#8b96b8] uppercase tracking-wider font-semibold">
                Score
              </span>
            </div>
          </div>
          <div className="mt-4 text-xs text-[#8b96b8]">
            {stats.securityScore >= 80 ? (
              <span className="text-[#3ddc97] font-semibold">● 防護体制は強固です</span>
            ) : stats.securityScore >= 50 ? (
              <span className="text-[#ffb547] font-semibold">▲ 一部の制限またはURLにリスクがあります</span>
            ) : (
              <span className="text-[#ff5c7a] font-semibold">■ 不正制限または脅威が検知されています</span>
            )}
          </div>
        </div>

        {/* System Status Metrics Card */}
        <div className="lg:col-span-2 p-6 rounded-xl bg-[#0f1420] border border-[#2a3550] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-[#e8ecf6]">システム統合防護ステータス</h3>
                <p className="text-xs text-[#8b96b8] mt-0.5">
                  全レイヤーのアクセス統制と脅威検知エンジンの稼働サマリー
                </p>
              </div>
              <div>{getSystemStatusBadge(stats.systemStatus)}</div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
              <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]/60">
                <div className="text-[11px] text-[#8b96b8]">監視サイト数</div>
                <div className="text-lg font-bold text-[#e8ecf6] mt-1">{sites.length} サイト</div>
              </div>
              <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]/60">
                <div className="text-[11px] text-[#8b96b8]">検知異常数</div>
                <div className="text-lg font-bold text-[#ffb547] mt-1">
                  {stats.detectedAnomaliesCount} 件
                </div>
              </div>
              <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]/60">
                <div className="text-[11px] text-[#8b96b8]">改ざん防止ログ件数</div>
                <div className="text-lg font-bold text-[#5b8cff] mt-1">{logs.length} 件</div>
              </div>
              <div className="p-3 bg-[#161d2e] rounded-lg border border-[#2a3550]/60">
                <div className="text-[11px] text-[#8b96b8]">緊急復旧マスターキー</div>
                <div className="text-lg font-bold text-[#3ddc97] mt-1">常時待機</div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-[#2a3550] flex flex-wrap items-center justify-between gap-3 text-xs">
            <span className="text-[#8b96b8]">
              仕様書のシナリオ（ハッカーロックダウン、低信頼制限の解除、ウイルススキャン等）の動作確認:
            </span>
            <button
              onClick={onOpenScenarios}
              className="px-3 py-1.5 bg-[#5b8cff]/20 hover:bg-[#5b8cff]/30 text-[#5b8cff] border border-[#5b8cff]/40 rounded-md font-semibold transition flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>テストシナリオを開く</span>
            </button>
          </div>
        </div>
      </div>

      {/* NEW SECTION: 過去24時間の脅威検知数と信頼度スコアの変動折れ線グラフ (Recharts) */}
      <div className="rounded-xl bg-[#0f1420] border border-[#2a3550] p-5 sm:p-6 shadow-md">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#5b8cff]" />
              <h3 className="text-sm sm:text-base font-bold text-[#e8ecf6]">
                過去24時間の脅威検知数 & 信頼度スコア推移
              </h3>
            </div>
            <p className="text-xs text-[#8b96b8] mt-1">
              内部脅威検知エンジンが捕捉したインシデント件数とシステム信頼性スコア（0〜100点）の相関動態
            </p>
          </div>

          {/* Time range selector tabs & Indicators */}
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-4 text-xs font-mono pr-2 border-r border-[#2a3550]">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#5b8cff]" />
                <span className="text-[#8b96b8]">平均スコア:</span>
                <span className="font-bold text-[#e8ecf6]">{avgTrustScore}点</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#ff5c7a]" />
                <span className="text-[#8b96b8]">期間内検知:</span>
                <span className="font-bold text-[#ff5c7a]">{totalThreatsRecorded}件</span>
              </div>
            </div>

            {/* Segmented controls */}
            <div className="flex items-center p-1 bg-[#161d2e] rounded-lg border border-[#2a3550]">
              <button
                type="button"
                onClick={() => setTimeRange('6h')}
                className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer ${
                  timeRange === '6h'
                    ? 'bg-[#5b8cff] text-white shadow-xs'
                    : 'text-[#8b96b8] hover:text-[#e8ecf6]'
                }`}
              >
                6時間
              </button>
              <button
                type="button"
                onClick={() => setTimeRange('12h')}
                className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer ${
                  timeRange === '12h'
                    ? 'bg-[#5b8cff] text-white shadow-xs'
                    : 'text-[#8b96b8] hover:text-[#e8ecf6]'
                }`}
              >
                12時間
              </button>
              <button
                type="button"
                onClick={() => setTimeRange('24h')}
                className={`px-3 py-1 rounded text-xs font-semibold transition cursor-pointer ${
                  timeRange === '24h'
                    ? 'bg-[#5b8cff] text-white shadow-xs'
                    : 'text-[#8b96b8] hover:text-[#e8ecf6]'
                }`}
              >
                24時間
              </button>
            </div>
          </div>
        </div>

        {/* Recharts LineChart */}
        <div className="w-full h-72 sm:h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={chartData}
              margin={{ top: 10, right: 20, left: -10, bottom: 0 }}
            >
              <defs>
                <linearGradient id="scoreGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#5b8cff" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#5b8cff" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a3550" opacity={0.6} vertical={false} />
              <XAxis
                dataKey="time"
                stroke="#8b96b8"
                tick={{ fill: '#8b96b8', fontSize: 11, fontFamily: 'monospace' }}
                axisLine={{ stroke: '#2a3550' }}
                tickLine={{ stroke: '#2a3550' }}
              />
              {/* Left Y Axis: Trust Score (0 - 100) */}
              <YAxis
                yAxisId="score"
                domain={[0, 100]}
                stroke="#5b8cff"
                tick={{ fill: '#8b96b8', fontSize: 11, fontFamily: 'monospace' }}
                axisLine={{ stroke: '#2a3550' }}
                tickLine={{ stroke: '#2a3550' }}
                unit="点"
              />
              {/* Right Y Axis: Threat Count (0 - 10) */}
              <YAxis
                yAxisId="threats"
                orientation="right"
                domain={[0, 10]}
                stroke="#ff5c7a"
                tick={{ fill: '#8b96b8', fontSize: 11, fontFamily: 'monospace' }}
                axisLine={{ stroke: '#2a3550' }}
                tickLine={{ stroke: '#2a3550' }}
                unit="件"
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                align="right"
                height={36}
                formatter={(value: string) => {
                  if (value === 'trustScore') {
                    return <span className="text-xs text-[#e8ecf6] mr-4">信頼度スコア (左軸: 0〜100点)</span>;
                  }
                  if (value === 'threatCount') {
                    return <span className="text-xs text-[#e8ecf6]">脅威検知数 (右軸: 件数)</span>;
                  }
                  return <span className="text-xs text-[#e8ecf6]">{value}</span>;
                }}
              />
              <ReferenceLine yAxisId="score" y={70} stroke="#3ddc97" strokeDasharray="3 3" opacity={0.4} />
              <ReferenceLine yAxisId="score" y={40} stroke="#ff5c7a" strokeDasharray="3 3" opacity={0.4} />

              {/* Line 1: Trust Score */}
              <Line
                yAxisId="score"
                type="monotone"
                dataKey="trustScore"
                name="trustScore"
                stroke="#5b8cff"
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#5b8cff', stroke: '#0f1420', strokeWidth: 2 }}
                activeDot={{ r: 6, fill: '#5b8cff', stroke: '#ffffff', strokeWidth: 2 }}
              />

              {/* Line 2: Threat Detection Count */}
              <Line
                yAxisId="threats"
                type="monotone"
                dataKey="threatCount"
                name="threatCount"
                stroke="#ff5c7a"
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#ff5c7a', stroke: '#0f1420', strokeWidth: 2 }}
                activeDot={{ r: 6, fill: '#ff5c7a', stroke: '#ffffff', strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Legend notes */}
        <div className="mt-3 pt-3 border-t border-[#2a3550]/60 flex flex-wrap items-center justify-between text-[11px] text-[#8b96b8]">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-2 h-0.5 bg-[#3ddc97] inline-block opacity-60"></span>
              70点基準ライン: 高信頼（厳格適用領域）
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-0.5 bg-[#ff5c7a] inline-block opacity-60"></span>
              40点危険ライン: 低信頼（誰でも即時解除可能領域）
            </span>
          </div>
          <span className="font-mono text-[10px]">
            ※ リアルタイムテストシナリオ実行時も最新地点に即時反映されます
          </span>
        </div>
      </div>

      {/* Recent Activity Logs (5 entries) */}
      <div className="rounded-xl bg-[#0f1420] border border-[#2a3550] overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-[#2a3550] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#5b8cff]" />
            <h3 className="text-sm font-bold text-[#e8ecf6]">直近のアクティビティログ (改ざん検知機能付き)</h3>
          </div>
          <button
            onClick={() => onNavigate('logs')}
            className="text-xs text-[#5b8cff] hover:underline flex items-center gap-1"
          >
            <span>全ログ一覧へ</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-[#161d2e] text-[#8b96b8] border-b border-[#2a3550]">
                <th className="py-3 px-4 font-semibold">タイムスタンプ</th>
                <th className="py-3 px-4 font-semibold">操作者</th>
                <th className="py-3 px-4 font-semibold">操作内容</th>
                <th className="py-3 px-4 font-semibold">カテゴリ</th>
                <th className="py-3 px-4 font-semibold">CRC-32 Checksum</th>
                <th className="py-3 px-4 font-semibold">改ざん検知ステータス</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2a3550]/60">
              {logs.slice(0, 5).map(log => {
                const isValid = !log.isTampered;
                return (
                  <tr key={log.id} className="hover:bg-[#161d2e]/40 transition">
                    <td className="py-3 px-4 font-mono text-[11px] text-[#8b96b8] whitespace-nowrap">
                      {log.timestamp}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#e8ecf6] whitespace-nowrap">
                      {log.operatorId}
                    </td>
                    <td className="py-3 px-4 text-[#e8ecf6]">{log.action}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#2a3550] text-[#8b96b8]">
                        {log.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-[#5b8cff] whitespace-nowrap">
                      {log.checksum}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {isValid ? (
                        <span className="inline-flex items-center gap-1 font-semibold text-[#3ddc97]">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>✓ 正常 (一致)</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 font-semibold text-[#ff5c7a] animate-pulse">
                          <XCircle className="w-3.5 h-3.5" />
                          <span>✗ 改ざん検知！</span>
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
