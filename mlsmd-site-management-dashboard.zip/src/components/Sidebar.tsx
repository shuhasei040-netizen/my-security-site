import React from 'react';
import { useSecurity } from '../context/SecurityContext';
import {
  LayoutDashboard,
  Globe,
  Lock,
  Users,
  SearchCheck,
  FileText,
  Settings,
  LogOut,
  Flame,
  CheckCircle,
  AlertCircle,
  ShieldAlert,
  ShieldCheck,
  ExternalLink,
  Smartphone,
} from 'lucide-react';

export type NavTab = 'dashboard' | 'sites' | 'restrictions' | 'accounts' | 'audit' | 'logs' | 'settings';

interface SidebarProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
  onOpenPWAInstall: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onTabChange,
  isMobileOpen,
  setIsMobileOpen,
  onOpenPWAInstall,
}) => {
  const {
    currentUser,
    logout,
    emergencyOverrideActive,
    autoRepelShieldActive,
    repelLockdownAndRestore,
    stats,
  } = useSecurity();

  const navSections: {
    category: string;
    items: { id: NavTab; label: string; icon: React.ReactNode; badge?: number }[];
  }[] = [
    {
      category: '概要',
      items: [
        { id: 'dashboard', label: 'プロジェクト概要', icon: <LayoutDashboard className="w-4 h-4" /> },
      ],
    },
    {
      category: 'ホスティング & サイト',
      items: [
        { id: 'sites', label: '管理Webサイト', icon: <Globe className="w-4 h-4" />, badge: stats.totalSites },
      ],
    },
    {
      category: 'セキュリティ & ルール',
      items: [
        {
          id: 'restrictions',
          label: 'アクセス制限・ルール',
          icon: <Lock className="w-4 h-4" />,
          badge: stats.activeRestrictions > 0 ? stats.activeRestrictions : undefined,
        },
        {
          id: 'audit',
          label: '監査・脅威検知',
          icon: <SearchCheck className="w-4 h-4" />,
          badge: stats.detectedAnomaliesCount > 0 ? stats.detectedAnomaliesCount : undefined,
        },
      ],
    },
    {
      category: 'IAM & ログ',
      items: [
        { id: 'accounts', label: 'Authentication (ユーザー)', icon: <Users className="w-4 h-4" /> },
        { id: 'logs', label: 'Cloud Logging (改ざん防止)', icon: <FileText className="w-4 h-4" /> },
      ],
    },
    {
      category: '構成',
      items: [
        { id: 'settings', label: 'プロジェクト設定', icon: <Settings className="w-4 h-4" /> },
      ],
    },
  ];

  const getRoleLabel = (role?: string) => {
    switch (role) {
      case 'L3':
        return '管理者 (Owner / L3)';
      case 'L2':
        return '編集者 (Editor / L2)';
      case 'L1':
        return '閲覧者 (Viewer / L1)';
      default:
        return '未設定';
    }
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/70 md:hidden backdrop-blur-xs"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-64 bg-[#111726] border-r border-[#1f2b45] flex flex-col transition-transform duration-200 ease-in-out md:translate-x-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Firebase Console Project Header */}
        <div className="p-4 border-b border-[#1f2b45]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#ffa000]/15 border border-[#ffa000]/30 flex items-center justify-center text-[#ffa000] shadow-sm">
              <Flame className="w-5 h-5 fill-[#ffa000]" />
            </div>
            <div className="overflow-hidden">
              <div className="font-bold text-xs tracking-tight text-[#e8ecf6] flex items-center gap-1.5 truncate">
                <span>Firebase Security</span>
              </div>
              <div className="text-[10px] text-[#ffa000] font-mono truncate">
                project-site-guard-prod
              </div>
            </div>
          </div>
        </div>

        {/* Anti-Lockdown Repel Shield Quick Status Banner */}
        <div className="mx-3 mt-3 p-2.5 bg-[#0c1222] border border-[#1f2b45] rounded-xl">
          <div className="flex items-center justify-between text-[11px] mb-1">
            <span className="text-[#8b96b8] flex items-center gap-1 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-[#3ddc97]" />
              反撃シールド
            </span>
            <span className="text-[10px] text-[#3ddc97] font-bold">有効</span>
          </div>
          <button
            onClick={repelLockdownAndRestore}
            className="w-full mt-1 py-1 px-2 bg-[#ff5c7a]/15 hover:bg-[#ff5c7a]/25 text-[#ff5c7a] border border-[#ff5c7a]/30 rounded text-[10px] font-bold flex items-center justify-center gap-1 transition cursor-pointer"
            title="もしハッカーに制限されてもワンクリックで弾き返します"
          >
            <ShieldAlert className="w-3 h-3" />
            <span>ハッカー制限を強制弾き返し</span>
          </button>
        </div>

        {/* Navigation list */}
        <nav className="p-3 space-y-4 flex-1 overflow-y-auto">
          {navSections.map((sec, idx) => (
            <div key={idx}>
              <div className="px-3 mb-1 text-[10px] font-bold uppercase tracking-wider text-[#8b96b8]/70">
                {sec.category}
              </div>
              <div className="space-y-0.5">
                {sec.items.map(item => {
                  const isActive = currentTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onTabChange(item.id);
                        setIsMobileOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                        isActive
                          ? 'bg-[#1a73e8] text-white font-semibold shadow-xs'
                          : 'text-[#8b96b8] hover:text-[#e8ecf6] hover:bg-[#1a233a]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className={isActive ? 'text-white' : 'text-[#8b96b8]'}>
                          {item.icon}
                        </span>
                        <span>{item.label}</span>
                      </div>
                      {item.badge !== undefined && (
                        <span
                          className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold ${
                            isActive
                              ? 'bg-white/20 text-white'
                              : item.id === 'audit' || item.id === 'restrictions'
                              ? 'bg-[#ff5c7a]/20 text-[#ff5c7a]'
                              : 'bg-[#1f2b45] text-[#8b96b8]'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Direct Device Install Action Banner */}
        <div className="p-3 border-t border-[#1f2b45] bg-[#0c1222]/70">
          <button
            onClick={() => {
              onOpenPWAInstall();
              setIsMobileOpen(false);
            }}
            className="w-full flex items-center justify-between p-2.5 bg-gradient-to-r from-[#1a73e8]/20 to-[#3ddc97]/20 border border-[#3ddc97]/30 hover:border-[#3ddc97]/60 rounded-xl text-left transition group cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-[#3ddc97]/20 text-[#3ddc97] rounded-lg">
                <Smartphone className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-[#e8ecf6] group-hover:text-[#3ddc97] transition">
                  端末に直接インストール
                </div>
                <div className="text-[9px] text-[#8b96b8]">
                  PWA & 端末防御シールド適用
                </div>
              </div>
            </div>
            <span className="text-[10px] text-[#3ddc97] font-bold">導入</span>
          </button>
        </div>

        {/* User Card */}
        <div className="p-3.5 border-t border-[#1f2b45] bg-[#0c1222]">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] uppercase font-bold tracking-wider text-[#8b96b8]">
              認証済みアカウント
            </span>
            <span className="text-[10px] text-[#3ddc97] flex items-center gap-1 font-medium">
              <CheckCircle className="w-3 h-3" /> 接続中
            </span>
          </div>

          <div className="flex items-center gap-2.5 mb-2.5">
            <div className="w-7 h-7 rounded-full bg-[#1a73e8] text-white flex items-center justify-center font-bold text-xs shadow-sm">
              {currentUser?.id.substring(0, 1).toUpperCase() || 'U'}
            </div>
            <div className="overflow-hidden">
              <div className="text-xs font-semibold text-[#e8ecf6] truncate">
                {currentUser?.name || 'ゲスト'}
              </div>
              <div className="text-[10px] text-[#8b96b8] truncate font-mono">
                {currentUser ? getRoleLabel(currentUser.role) : '未ログイン'}
              </div>
            </div>
          </div>

          <button
            onClick={logout}
            className="w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-[#111726] hover:bg-[#1a233a] text-[#e8ecf6] rounded-md text-xs font-medium border border-[#1f2b45] transition cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5 text-[#8b96b8]" />
            <span>コンソールからログアウト</span>
          </button>
        </div>
      </aside>
    </>
  );
};
