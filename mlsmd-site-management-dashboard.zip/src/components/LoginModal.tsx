import React, { useState } from 'react';
import { useSecurity } from '../context/SecurityContext';
import { UserRole } from '../types/security';
import {
  Flame,
  Shield,
  Key,
  UserCheck,
  AlertTriangle,
  ArrowRight,
  Lock,
  CheckCircle2,
  XCircle,
  UserPlus,
  LogIn,
  ShieldAlert,
  Smartphone,
} from 'lucide-react';

interface LoginModalProps {
  onOpenPWAInstall?: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onOpenPWAInstall }) => {
  const { login, registerNewAccount, repelLockdownAndRestore, autoRepelShieldActive } = useSecurity();
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');

  // Login form
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Register form
  const [regId, setRegId] = useState('');
  const [regName, setRegName] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regPassConfirm, setRegPassConfirm] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('L3');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) {
      setStatusMessage({ text: '❌ パスワードを入力してください', isError: true });
      return;
    }

    setIsLoading(true);
    setStatusMessage(null);

    setTimeout(() => {
      const res = login(userId, password);
      setIsLoading(false);
      if (!res.success) {
        setStatusMessage({ text: `❌ ${res.message}`, isError: true });
      } else {
        setStatusMessage({ text: '✅ ログインに成功しました', isError: false });
      }
    }, 200);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regId.trim() || !regName.trim() || !regPass.trim()) {
      setStatusMessage({ text: '❌ すべての必須項目を入力してください', isError: true });
      return;
    }
    if (regPass !== regPassConfirm) {
      setStatusMessage({ text: '❌ パスワード（確認用）が一致しません', isError: true });
      return;
    }

    setIsLoading(true);
    setStatusMessage(null);

    setTimeout(() => {
      const res = registerNewAccount(regId, regName, regPass, regRole);
      setIsLoading(false);
      if (!res.success) {
        setStatusMessage({ text: `❌ ${res.message}`, isError: true });
      } else {
        setStatusMessage({ text: '✅ アカウントを作成しログインしました', isError: false });
      }
    }, 200);
  };

  const handleQuickFill = (u: string, p: string) => {
    setUserId(u);
    setPassword(p);
    setStatusMessage(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0a101d]/90 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-md bg-[#131b2e] border border-[#23314e] rounded-2xl shadow-2xl overflow-hidden relative">
        {/* Firebase Console styled top bar */}
        <div className="bg-gradient-to-r from-[#f57c00] via-[#ffa000] to-[#ffca28] h-1.5 w-full" />

        <div className="p-6 sm:p-8">
          {/* Header Branding (Firebase Console style) */}
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-13 h-13 rounded-2xl bg-[#ffa000]/15 border border-[#ffa000]/30 text-[#ffa000] mb-3 shadow-inner">
              <Flame className="w-7 h-7 fill-[#ffa000]" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-[#e8ecf6] flex items-center justify-center gap-2">
              🛡️ Firebase Security Console
            </h1>
            <p className="text-xs text-[#8b96b8] mt-1 font-mono">
              Multi-Layer Security Site Management Dashboard (MLSMD)
            </p>
          </div>

          {/* Tab Selector: ログイン vs 新規アカウント作成 */}
          <div className="flex bg-[#0c1222] p-1 rounded-xl border border-[#23314e] mb-6">
            <button
              type="button"
              onClick={() => {
                setActiveTab('login');
                setStatusMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'login'
                  ? 'bg-[#1a73e8] text-white shadow-sm'
                  : 'text-[#8b96b8] hover:text-[#e8ecf6]'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>ログイン</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveTab('register');
                setStatusMessage(null);
              }}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                activeTab === 'register'
                  ? 'bg-[#ffa000] text-[#0a101d] font-bold shadow-sm'
                  : 'text-[#8b96b8] hover:text-[#e8ecf6]'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>新規アカウント作成</span>
            </button>
          </div>

          {/* Status Alert Banner */}
          {statusMessage && (
            <div
              className={`p-3.5 rounded-lg mb-5 text-xs font-semibold flex items-center gap-2 transition-all ${
                statusMessage.isError
                  ? 'bg-[#ff5c7a]/15 text-[#ff5c7a] border border-[#ff5c7a]/30'
                  : 'bg-[#3ddc97]/15 text-[#3ddc97] border border-[#3ddc97]/30'
              }`}
            >
              {statusMessage.isError ? (
                <XCircle className="w-4 h-4 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* TAB 1: LOGIN FORM */}
          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#8b96b8] mb-1.5">
                  ユーザーID <span className="text-[#8b96b8]/60 text-[11px]">（未登録IDは安全のため詳細隠蔽）</span>
                </label>
                <input
                  type="text"
                  value={userId}
                  onChange={e => setUserId(e.target.value)}
                  placeholder="例: admin または 作成したID"
                  className="w-full bg-[#0c1222] border border-[#23314e] rounded-lg px-3.5 py-2.5 text-sm text-[#e8ecf6] placeholder-[#8b96b8]/50 focus:outline-none focus:border-[#ffa000] focus:ring-1 focus:ring-[#ffa000] transition"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-medium text-[#8b96b8]">
                    パスワード または マスターキー
                  </label>
                  <span className="text-[11px] text-[#ffa000] flex items-center gap-1">
                    <Lock className="w-3 h-3" /> マスク保護
                  </span>
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="パスワード または MASTER-2024-OVERRIDE"
                  className="w-full bg-[#0c1222] border border-[#23314e] rounded-lg px-3.5 py-2.5 text-sm text-[#e8ecf6] placeholder-[#8b96b8]/50 focus:outline-none focus:border-[#ffa000] focus:ring-1 focus:ring-[#ffa000] transition"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 py-2.5 px-4 rounded-lg font-semibold text-sm text-white bg-gradient-to-r from-[#1a73e8] to-[#0288d1] hover:opacity-95 active:scale-[0.99] transition shadow-md shadow-[#1a73e8]/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <span>照合中...</span>
                ) : (
                  <>
                    <span>コンソールにログイン</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* TAB 2: REGISTER NEW ACCOUNT FORM */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-[#8b96b8] mb-1">
                  希望するユーザーID <span className="text-[#ff5c7a]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={regId}
                  onChange={e => setRegId(e.target.value.replace(/[^a-zA-Z0-9_-]/g, ''))}
                  placeholder="例: user_myproject"
                  className="w-full bg-[#0c1222] border border-[#23314e] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] font-mono focus:outline-none focus:border-[#ffa000]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#8b96b8] mb-1">
                  表示名（お名前/役職） <span className="text-[#ff5c7a]">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={e => setRegName(e.target.value)}
                  placeholder="例: サイトオーナー 田中"
                  className="w-full bg-[#0c1222] border border-[#23314e] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-[#8b96b8] mb-1">
                    パスワード <span className="text-[#ff5c7a]">*</span>
                  </label>
                  <input
                    type="password"
                    required
                    value={regPass}
                    onChange={e => setRegPass(e.target.value)}
                    placeholder="パスワード"
                    className="w-full bg-[#0c1222] border border-[#23314e] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#8b96b8] mb-1">
                    確認用 <span className="text-[#ff5c7a]">*</span>
                  </label>
                  <input
                    type="password"
                    required
                    value={regPassConfirm}
                    onChange={e => setRegPassConfirm(e.target.value)}
                    placeholder="再入力"
                    className="w-full bg-[#0c1222] border border-[#23314e] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#8b96b8] mb-1">
                  権限レベル
                </label>
                <select
                  value={regRole}
                  onChange={e => setRegRole(e.target.value as UserRole)}
                  className="w-full bg-[#0c1222] border border-[#23314e] rounded-lg px-3 py-2 text-xs text-[#e8ecf6] focus:outline-none focus:border-[#ffa000]"
                >
                  <option value="L3">L3 管理者 (サイト登録・制限管理・全権限)</option>
                  <option value="L2">L2 編集者 (サイト登録・編集・検査)</option>
                  <option value="L1">L1 閲覧者 (監査・閲覧専用)</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full mt-2 py-2.5 px-4 rounded-lg font-bold text-xs text-[#0a101d] bg-gradient-to-r from-[#ffa000] to-[#ffca28] hover:opacity-95 active:scale-[0.99] transition shadow-md shadow-[#ffa000]/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                <UserPlus className="w-4 h-4" />
                <span>アカウントを新規作成してすぐ使う</span>
              </button>
            </form>
          )}

          {/* Emergency Anti-Lockdown Repel Shield Quick Action */}
          <div className="mt-6 pt-5 border-t border-[#23314e] space-y-3">
            <div className="p-3 bg-[#ff5c7a]/10 border border-[#ff5c7a]/30 rounded-xl flex items-center justify-between gap-3">
              <div>
                <div className="text-[11px] font-bold text-[#ff5c7a] flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4" />
                  <span>ハッカー制限の強制弾き返し＆復旧</span>
                </div>
                <div className="text-[10px] text-[#8b96b8] mt-0.5">
                  万が一不正ロックダウンされた場合も即座に無力化・復旧
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  repelLockdownAndRestore();
                  setStatusMessage({ text: '🛡️ すべての制限を弾き返し無力化しました！そのまま管理者としてログインできます', isError: false });
                }}
                className="px-2.5 py-1.5 text-[11px] bg-[#ff5c7a] hover:bg-[#ff5c7a]/90 text-white rounded-lg font-bold transition shadow-sm shrink-0 cursor-pointer"
              >
                強制解除
              </button>
            </div>

            {/* Quick admin account fill */}
            <div className="flex items-center justify-between text-xs text-[#8b96b8] px-1">
              <span>初期管理者アカウント: <code>admin</code> / <code>admin123</code></span>
              <button
                type="button"
                onClick={() => handleQuickFill('admin', 'admin123')}
                className="text-[#1a73e8] hover:underline font-semibold"
              >
                入力
              </button>
            </div>

            {/* Direct Device Install PWA Button on Login Screen */}
            {onOpenPWAInstall && (
              <button
                type="button"
                onClick={onOpenPWAInstall}
                className="w-full mt-2 py-2 px-3 bg-[#0c1222] hover:bg-[#162035] border border-[#3ddc97]/30 hover:border-[#3ddc97]/60 text-[#3ddc97] rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>サイトから端末へ直接インストール (PWA) / 端末防衛設定</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
