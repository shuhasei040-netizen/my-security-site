import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  getDeviceImmunityCert,
  isDeviceImmune,
  setDeviceImmunity,
  downloadWindowsShieldScript,
  downloadMacLinuxShieldScript,
} from '../utils/deviceProtection';
import { useSecurity } from '../context/SecurityContext';
import {
  Smartphone,
  Monitor,
  ShieldCheck,
  Download,
  CheckCircle2,
  X,
  Share,
  PlusSquare,
  Terminal,
  ShieldAlert,
  Flame,
  ArrowRight,
  Laptop,
} from 'lucide-react';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const { downloadStandaloneHtml, showToast } = useSecurity();
  const [activeTab, setActiveTab] = useState<'pwa' | 'device_shield'>('pwa');
  const [cert, setCert] = useState(() => getDeviceImmunityCert());
  const [shieldActive, setShieldActive] = useState(() => isDeviceImmune());

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        showToast('✅ アプリが端末に正常にインストールされました！', 'success');
        onClose();
      }
    } else if (isIOS) {
      setActiveTab('pwa');
    } else {
      showToast('ℹ️ ブラウザメニューの「アプリをインストール」または「ホーム画面に追加」からも実行できます', 'info');
    }
  };

  const handleToggleDeviceImmunity = () => {
    const nextState = !shieldActive;
    setShieldActive(nextState);
    setDeviceImmunity(nextState);
    showToast(
      nextState
        ? '🛡️ 端末レベルの制限自動弾き返しシールドを有効化しました'
        : '⚠️ 端末シールドを一時停止しました',
      nextState ? 'success' : 'warning'
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#0a101d]/90 backdrop-blur-md overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#111726] border border-[#23314e] rounded-2xl shadow-2xl overflow-hidden relative">
        {/* Firebase Top Accent Bar */}
        <div className="bg-gradient-to-r from-[#ffa000] via-[#f57c00] to-[#1a73e8] h-1.5 w-full" />

        {/* Modal Header */}
        <div className="p-6 border-b border-[#1f2b45] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#ffa000]/15 border border-[#ffa000]/30 flex items-center justify-center text-[#ffa000]">
              <Flame className="w-6 h-6 fill-[#ffa000]" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#e8ecf6] flex items-center gap-2">
                <span>端末直接インストール & デバイス保護シールド</span>
                <span className="text-[10px] bg-[#1a73e8]/20 text-[#1a73e8] border border-[#1a73e8]/30 px-2 py-0.5 rounded-full font-mono">
                  PWA Ready
                </span>
              </h2>
              <p className="text-xs text-[#8b96b8] mt-0.5">
                ブラウザから端末（PC / スマホ）へ直接アプリをインストールし、デバイス自体に制限弾き返しを適応
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#8b96b8] hover:text-[#e8ecf6] hover:bg-[#1f2b45] rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-[#1f2b45] bg-[#0c1222] px-6">
          <button
            onClick={() => setActiveTab('pwa')}
            className={`py-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 cursor-pointer transition ${
              activeTab === 'pwa'
                ? 'border-[#ffa000] text-[#ffa000]'
                : 'border-transparent text-[#8b96b8] hover:text-[#e8ecf6]'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>① 端末へ直接インストール (PWA)</span>
          </button>
          <button
            onClick={() => setActiveTab('device_shield')}
            className={`py-3 px-4 text-xs font-bold border-b-2 flex items-center gap-2 cursor-pointer transition ${
              activeTab === 'device_shield'
                ? 'border-[#3ddc97] text-[#3ddc97]'
                : 'border-transparent text-[#8b96b8] hover:text-[#e8ecf6]'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>② 端末本体への制限弾き返し適用 (Device Immunity)</span>
          </button>
        </div>

        {/* Tab 1: PWA Direct Installation */}
        {activeTab === 'pwa' && (
          <div className="p-6 space-y-5">
            <div className="bg-[#162035] border border-[#26375a] rounded-xl p-4 flex items-start gap-4">
              <div className="p-3 bg-[#ffa000]/15 rounded-xl text-[#ffa000] shrink-0">
                <Laptop className="w-6 h-6" />
              </div>
              <div className="flex-1 text-xs space-y-1">
                <div className="font-bold text-[#e8ecf6] text-sm">
                  アプリストア不要で、お使いの端末に直接インストール可能
                </div>
                <p className="text-[#8b96b8] leading-relaxed">
                  Progressive Web App（PWA）技術により、URLバーのない独立ウィンドウで高速動作し、オフラインでも起動します。
                </p>
                {isInstalled && (
                  <div className="inline-flex items-center gap-1.5 mt-2 px-2.5 py-1 rounded bg-[#3ddc97]/15 text-[#3ddc97] border border-[#3ddc97]/30 text-xs font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>この端末には既にインストールされています (Standalone起動)</span>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Install Action Box */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Option A: Direct Browser Install */}
              <div className="bg-[#0c1222] border border-[#1f2b45] rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-bold text-[#ffa000] flex items-center gap-1.5 mb-1">
                    <Monitor className="w-4 h-4" />
                    <span>ブラウザ直接インストール</span>
                  </div>
                  <p className="text-[11px] text-[#8b96b8] mb-4">
                    Chrome / Edge / Android をご利用の場合、ワンクリックでPCやスマートフォンのホーム画面に配置されます。
                  </p>
                </div>
                <button
                  onClick={handleInstallClick}
                  className="w-full py-2.5 px-4 bg-[#ffa000] hover:bg-[#ffb300] text-[#0a101d] rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>{isInstallable ? '今すぐ端末にインストール' : 'インストールを実行'}</span>
                </button>
              </div>

              {/* Option B: Standalone HTML with Embedded Immunity */}
              <div className="bg-[#0c1222] border border-[#1f2b45] rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="text-xs font-bold text-[#1a73e8] flex items-center gap-1.5 mb-1">
                    <Download className="w-4 h-4" />
                    <span>単体HTMLファイルとして保存</span>
                  </div>
                  <p className="text-[11px] text-[#8b96b8] mb-4">
                    端末免疫コードと制限弾き返しシールドを内包した自己完結HTML。USBやオフライン環境でもダブルクリックで実行可能。
                  </p>
                </div>
                <button
                  onClick={() => {
                    downloadStandaloneHtml();
                    showToast('💾 制限弾き返し付き単体HTML（site-manager-security.html）をダウンロードしました', 'success');
                  }}
                  className="w-full py-2.5 px-4 bg-[#1a73e8] hover:bg-[#2a83f8] text-white rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Download className="w-4 h-4" />
                  <span>単体HTML保存 (オフライン対応)</span>
                </button>
              </div>
            </div>

            {/* iOS Instructions */}
            {isIOS && (
              <div className="bg-[#0c1222] border border-[#ffca28]/30 rounded-xl p-4">
                <div className="text-xs font-bold text-[#ffca28] flex items-center gap-2 mb-2">
                  <Share className="w-4 h-4" />
                  <span>iOS (iPhone / iPad) でのインストール手順</span>
                </div>
                <ol className="text-xs text-[#8b96b8] space-y-1.5 list-decimal list-inside">
                  <li>Safariブラウザ下部の <strong className="text-white">共有アイコン</strong> をタップします。</li>
                  <li>メニューをスクロールして <strong className="text-white">「ホーム画面に追加」<PlusSquare className="w-3.5 h-3.5 inline mx-1 text-white" /></strong> を選択します。</li>
                  <li>右上の <strong className="text-white">「追加」</strong> をタップすると、ホーム画面にアプリアイコンが配置されます。</li>
                </ol>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Device-level Immunity */}
        {activeTab === 'device_shield' && (
          <div className="p-6 space-y-5">
            {/* Device Immunity Status Card */}
            <div className="bg-[#162035] border border-[#26375a] rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-[#3ddc97]" />
                  <span className="text-sm font-bold text-[#e8ecf6]">端末固有の防御証明書 (Device Immunity Token)</span>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                  shieldActive ? 'bg-[#3ddc97]/20 text-[#3ddc97] border border-[#3ddc97]/30' : 'bg-[#ff5c7a]/20 text-[#ff5c7a]'
                }`}>
                  {shieldActive ? '端末免疫 稼働中 (ACTIVE)' : '端末免疫 停止中'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs bg-[#0c1222] p-3 rounded-lg border border-[#1f2b45] font-mono">
                <div>
                  <span className="text-[#8b96b8] block text-[10px]">端末ID:</span>
                  <span className="text-[#e8ecf6] font-bold">{cert.deviceId}</span>
                </div>
                <div>
                  <span className="text-[#8b96b8] block text-[10px]">署名ハッシュ:</span>
                  <span className="text-[#3ddc97] font-bold">{cert.signature}</span>
                </div>
                <div>
                  <span className="text-[#8b96b8] block text-[10px]">復旧権限:</span>
                  <span className="text-[#ffa000]">{cert.masterAuthority}</span>
                </div>
                <div>
                  <span className="text-[#8b96b8] block text-[10px]">保護有効期限:</span>
                  <span className="text-[#e8ecf6]">永続 (Permanent)</span>
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <p className="text-xs text-[#8b96b8]">
                  この設定は端末の永続ストレージに保存され、ハッカーによる不正制限を端末全体で自動的に弾き返します。
                </p>
                <button
                  onClick={handleToggleDeviceImmunity}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer shrink-0 ml-4 ${
                    shieldActive
                      ? 'bg-[#3ddc97]/20 hover:bg-[#3ddc97]/30 text-[#3ddc97] border border-[#3ddc97]/30'
                      : 'bg-[#ff5c7a]/20 hover:bg-[#ff5c7a]/30 text-[#ff5c7a] border border-[#ff5c7a]/30'
                  }`}
                >
                  {shieldActive ? 'シールド常時保護中' : 'シールドを再有効化'}
                </button>
              </div>
            </div>

            {/* Native OS Anti-Hijack Deflector Scripts */}
            <div>
              <div className="text-xs font-bold text-[#e8ecf6] mb-2 flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-[#ffa000]" />
                <span>OS端末レベル防衛スクリプトのダウンロード（Windows / Mac / Linux）</span>
              </div>
              <p className="text-[11px] text-[#8b96b8] mb-3 leading-relaxed">
                万が一、端末自体が不正なプロキシやDNS改ざん、ローカルロックファイル等の外部制限を受けた場合でも、
                ワンクリック実行で端末の通信とアクセス制限を強制正常化し、安全にダッシュボードを起動します。
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    downloadWindowsShieldScript();
                    showToast('🪟 Windows用 端末防衛スクリプト (device-repel-shield.bat) を保存しました', 'success');
                  }}
                  className="p-3 bg-[#0c1222] hover:bg-[#162035] border border-[#1f2b45] hover:border-[#1a73e8]/50 rounded-xl text-left transition cursor-pointer flex items-center justify-between group"
                >
                  <div>
                    <div className="text-xs font-bold text-[#e8ecf6] group-hover:text-[#1a73e8]">
                      Windows用 防衛バッチ (.bat)
                    </div>
                    <div className="text-[10px] text-[#8b96b8] mt-0.5">
                      プロキシ解除・DNSフラッシュ・端末証明書配備
                    </div>
                  </div>
                  <Download className="w-4 h-4 text-[#8b96b8] group-hover:text-[#1a73e8]" />
                </button>

                <button
                  onClick={() => {
                    downloadMacLinuxShieldScript();
                    showToast('🍎 Mac/Linux用 端末防衛スクリプト (device-repel-shield.sh) を保存しました', 'success');
                  }}
                  className="p-3 bg-[#0c1222] hover:bg-[#162035] border border-[#1f2b45] hover:border-[#3ddc97]/50 rounded-xl text-left transition cursor-pointer flex items-center justify-between group"
                >
                  <div>
                    <div className="text-xs font-bold text-[#e8ecf6] group-hover:text-[#3ddc97]">
                      macOS / Linux用 シェル (.sh)
                    </div>
                    <div className="text-[10px] text-[#8b96b8] mt-0.5">
                      DNSクリア・設定保護・端末保護起動
                    </div>
                  </div>
                  <Download className="w-4 h-4 text-[#8b96b8] group-hover:text-[#3ddc97]" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="p-4 bg-[#0c1222] border-t border-[#1f2b45] flex items-center justify-between text-xs text-[#8b96b8]">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-[#ffa000]" />
            <span>自律反撃・弾き返しモード常時スタンバイ</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#1f2b45] hover:bg-[#2a3858] text-[#e8ecf6] rounded-lg font-semibold transition cursor-pointer"
          >
            閉じる
          </button>
        </div>
      </div>
    </div>
  );
};
