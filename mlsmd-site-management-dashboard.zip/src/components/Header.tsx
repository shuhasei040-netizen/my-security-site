import React from 'react';
import { useSecurity } from '../context/SecurityContext';
import { NavTab } from './Sidebar';
import {
  Menu,
  Download,
  FileCode,
  Sparkles,
  ShieldAlert,
  RotateCcw,
  Flame,
  ShieldCheck,
  Smartphone,
} from 'lucide-react';

interface HeaderProps {
  currentTab: NavTab;
  onOpenMobileMenu: () => void;
  onOpenScenarios: () => void;
  onOpenPWAInstall: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onOpenMobileMenu,
  onOpenScenarios,
  onOpenPWAInstall,
}) => {
  const {
    emergencyOverrideActive,
    dismissEmergencyOverride,
    repelLockdownAndRestore,
    exportJsonBackup,
    downloadStandaloneHtml,
    stats,
  } = useSecurity();

  const tabMetadata: Record<NavTab, { title: string; subtitle: string; category: string }> = {
    dashboard: {
      category: 'Overview',
      title: 'プロジェクト概要 & セキュリティスコア',
      subtitle: 'リアルタイム脅威検知・信頼度スコア推移・システム防護状態',
    },
    sites: {
      category: 'Hosting',
      title: '管理対象Webサイト & URLマルウェアスキャナ',
      subtitle: '登録サイトのSSL/HTTPS検証・危険拡張子・短縮URL・フィッシング検知',
    },
    restrictions: {
      category: 'Security Rules',
      title: 'アクセス制限・セキュリティルール管理',
      subtitle: '動的信頼スコア算出・自動期限切れ・低信頼制限の即時削除',
    },
    accounts: {
      category: 'Authentication',
      title: 'Authentication & IAM ユーザー管理',
      subtitle: '多層権限レベル（L1閲覧者/L2編集者/L3管理者）と信頼性検証',
    },
    audit: {
      category: 'Security Audit',
      title: '内部脅威検知 & セキュリティ監査',
      subtitle: 'ロックダウンスパム・権限奪取・不規則時間帯アクセスのリアルタイム監視',
    },
    logs: {
      category: 'Cloud Logging',
      title: '不変ログ台帳 (CRC-32チェックサム検証)',
      subtitle: '改ざん防止ハッシュ照合による透明性の高い操作履歴記録',
    },
    settings: {
      category: 'Settings',
      title: 'プロジェクト構成 & データバックアップ',
      subtitle: 'マスターキー管理・完全自己完結HTMLダウンロード・復元',
    },
  };

  const meta = tabMetadata[currentTab] || {
    category: 'Console',
    title: '管理コンソール',
    subtitle: 'システム統合セキュリティ管理',
  };

  return (
    <header className="bg-[#111726] border-b border-[#1f2b45] shrink-0 sticky top-0 z-30">
      {/* Emergency Override Banner */}
      {emergencyOverrideActive && (
        <div className="bg-gradient-to-r from-[#b71c1c] via-[#d32f2f] to-[#f44336] px-4 py-2 text-white flex flex-wrap items-center justify-between gap-3 shadow-md text-xs font-bold">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 shrink-0 animate-bounce" />
            <span>
              🚨 EMERGENCY OVERRIDE 発動中：すべての制限を弾き返し「無視モード」に変更しています。
            </span>
          </div>
          <button
            onClick={dismissEmergencyOverride}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-black/40 hover:bg-black/60 rounded text-xs font-semibold border border-white/30 transition cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>通常モードへ復帰</span>
          </button>
        </div>
      )}

      {/* Main Bar (Firebase Console style) */}
      <div className="px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Left: Breadcrumbs & Page title */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobileMenu}
            className="p-1.5 rounded-lg text-[#8b96b8] hover:text-[#e8ecf6] hover:bg-[#1a233a] md:hidden"
            aria-label="メニューを開く"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-1.5 text-[11px] text-[#ffa000] font-medium">
              <span>Firebase</span>
              <span>/</span>
              <span>site-security-prod</span>
              <span>/</span>
              <span className="text-[#8b96b8]">{meta.category}</span>
            </div>
            <h1 className="text-sm sm:text-base font-bold text-[#e8ecf6] flex items-center gap-2 mt-0.5">
              {meta.title}
            </h1>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Active Anti-Lockdown Repel Button */}
          <button
            onClick={repelLockdownAndRestore}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#ff5c7a]/15 hover:bg-[#ff5c7a]/25 text-[#ff5c7a] border border-[#ff5c7a]/30 rounded-lg text-xs font-bold transition cursor-pointer shadow-xs"
            title="ハッカーによるロックダウンや制限をワンクリックで強制弾き返し＆復旧"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">ハッカー制限を強制弾き返し</span>
            <span className="sm:hidden">弾き返し</span>
          </button>

          {/* Test Scenarios */}
          <button
            onClick={onOpenScenarios}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1a73e8]/15 hover:bg-[#1a73e8]/25 text-[#1a73e8] border border-[#1a73e8]/30 rounded-lg text-xs font-semibold transition cursor-pointer"
            title="仕様書のテストシナリオ1〜4を実行"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#ffa000]" />
            <span className="hidden sm:inline">テストシナリオ</span>
          </button>

          {/* Direct Device Install / PWA Modal */}
          <button
            onClick={onOpenPWAInstall}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#3ddc97]/15 hover:bg-[#3ddc97]/25 text-[#3ddc97] border border-[#3ddc97]/30 rounded-lg text-xs font-bold transition shadow-xs cursor-pointer animate-pulse"
            title="サイトから直接お使いのPCやスマホ端末にアプリをインストール"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">端末に直接インストール</span>
            <span className="sm:hidden">インストール</span>
          </button>

          {/* Download Standalone HTML */}
          <button
            onClick={downloadStandaloneHtml}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#ffa000] hover:bg-[#ffb300] text-[#0a101d] rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
            title="制限を弾き返す機能付きの単体HTMLファイル（site-manager-security.html）を保存"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span className="hidden md:inline">単体HTML保存</span>
          </button>
        </div>
      </div>
    </header>
  );
};
