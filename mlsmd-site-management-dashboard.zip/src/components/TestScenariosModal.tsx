import React from 'react';
import { useSecurity } from '../context/SecurityContext';
import { Sparkles, X, ShieldAlert, Lock, Search, UserCheck } from 'lucide-react';
import { NavTab } from './Sidebar';

interface TestScenariosModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: NavTab) => void;
}

export const TestScenariosModal: React.FC<TestScenariosModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const { runTestScenario } = useSecurity();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
      <div className="w-full max-w-2xl bg-[#0f1420] border border-[#2a3550] rounded-xl shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4 border-b border-[#2a3550] pb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#5b8cff]" />
            <div>
              <h3 className="font-bold text-base text-[#e8ecf6]">
                仕様書テストシナリオ実行ランチャー
              </h3>
              <p className="text-xs text-[#8b96b8]">
                プロンプト要件のテストシナリオ1〜4を即座にシミュレートし検証します
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#8b96b8] hover:text-[#e8ecf6]">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Test 1 */}
          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#ff5c7a] flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4" />
                テスト1：ハッカーが管理権限を奪った場合の回復
              </span>
              <button
                onClick={() => {
                  runTestScenario(1);
                  onNavigate('restrictions');
                  onClose();
                }}
                className="px-3 py-1 bg-[#ff5c7a] hover:bg-[#ff5c7a]/90 text-white rounded text-xs font-bold transition cursor-pointer"
              >
                実行する
              </button>
            </div>
            <p className="text-xs text-[#8b96b8] leading-relaxed">
              ハッカーによる「フルロックダウン」を適用。マスターキー <code>MASTER-2024-OVERRIDE</code> をパスワード欄または緊急復旧パネルに入力して、全制限が無視モードに移行し復旧されることを確認できます。
            </p>
          </div>

          {/* Test 2 */}
          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#ffb547] flex items-center gap-1.5">
                <Lock className="w-4 h-4" />
                テスト2：悪質なユーザーが不正な制限をかけた場合
              </span>
              <button
                onClick={() => {
                  runTestScenario(2);
                  onNavigate('restrictions');
                  onClose();
                }}
                className="px-3 py-1 bg-[#ffb547] hover:bg-[#ffb547]/90 text-[#0a0e1a] rounded text-xs font-bold transition cursor-pointer"
              >
                実行する
              </button>
            </div>
            <p className="text-xs text-[#8b96b8] leading-relaxed">
              未検証アカウントが制限を適用。信頼度スコアが35点（&lt;40点）と自動判定され、閲覧者(L1)や編集者(L2)でも制限解除ボタンが表示され即座に削除できることを確認できます。
            </p>
          </div>

          {/* Test 3 */}
          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#5b8cff] flex items-center gap-1.5">
                <Search className="w-4 h-4" />
                テスト3：ウイルス・マルウェア簡易検査
              </span>
              <button
                onClick={() => {
                  runTestScenario(3);
                  onNavigate('sites');
                  onClose();
                }}
                className="px-3 py-1 bg-[#5b8cff] hover:bg-[#5b8cff]/90 text-white rounded text-xs font-bold transition cursor-pointer"
              >
                実行する
              </button>
            </div>
            <p className="text-xs text-[#8b96b8] leading-relaxed">
              危険なURL「https://bit.ly/malicious-payload-installer.exe」をサイトとして追加。短縮URLと実行ファイル拡張子が即時検知され、状態が「危険」に自動変更されることを確認できます。
            </p>
          </div>

          {/* Test 4 */}
          <div className="p-4 bg-[#161d2e] rounded-lg border border-[#2a3550]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-[#3ddc97] flex items-center gap-1.5">
                <UserCheck className="w-4 h-4" />
                テスト4：ログインの試行錯誤（ID列挙攻撃の阻止）
              </span>
              <button
                onClick={() => {
                  runTestScenario(4);
                  onNavigate('logs');
                  onClose();
                }}
                className="px-3 py-1 bg-[#3ddc97] hover:bg-[#3ddc97]/90 text-[#0a0e1a] rounded text-xs font-bold transition cursor-pointer"
              >
                実行する
              </button>
            </div>
            <p className="text-xs text-[#8b96b8] leading-relaxed">
              存在しないID「hacker123」でのログイン試行を発生させ、詳細を相手に知らせず「アカウントが見つかりません」と拒否し、改ざん防止ログに「未登録IDでの試行」が記録されることを確認できます。
            </p>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-[#2a3550] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#161d2e] hover:bg-[#2a3550] text-[#e8ecf6] rounded text-xs font-medium border border-[#2a3550]"
          >
            閉じる
          </button>
        </div>
      </div>
    </div>
  );
};
