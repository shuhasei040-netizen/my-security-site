export type UserRole = 'L1' | 'L2' | 'L3';

export interface User {
  id: string;
  name: string;
  role: UserRole;
  isVerified: boolean;
  createdAt: string;
  failedLoginAttempts: number;
  isRestricted: boolean;
  password?: string; // Stored securely for local session simulation
}

export type RestrictionType =
  | 'full_lockdown'      // 全ユーザーロック / フルロック
  | 'read_only'          // 読み取り専用
  | 'revoke_admin'       // 管理権限剥奪
  | 'site_block';        // サイトアクセス禁止

export type RestrictionStatus = 'active' | 'bypassed' | 'expired';

export interface Restriction {
  id: string;
  type: RestrictionType;
  typeLabel: string;
  reason: string;
  appliedBy: string;
  appliedByRole: UserRole;
  isCreatorVerified: boolean;
  appliedAt: string;
  durationMinutes: number;
  expiresAt: string;
  trustScore: number;       // 0 - 100
  trustLevel: 'high' | 'medium' | 'low'; // >=70: high, 40-70: medium, <40: low
  status: RestrictionStatus;
  targetUserId?: string;
}

export type SiteStatus = 'normal' | 'warning' | 'danger';

export interface MalwareScanResult {
  scannedAt: string;
  riskLevel: 'safe' | 'warning' | 'danger';
  riskScore: number; // 0 - 100
  issues: string[];
  isHttps: boolean;
  hasRiskyExt: boolean;
  isShortUrl: boolean;
  hasSuspiciousKeywords: boolean;
  isSuspiciousIdn: boolean;
  isRiskyTld: boolean;
}

export interface Site {
  id: string;
  name: string;
  url: string;
  category: string;
  notes: string;
  addedBy: string;
  isVerified: boolean;
  status: SiteStatus;
  createdAt: string;
  lastScanResult?: MalwareScanResult;
}

export type LogCategory =
  | 'login'
  | 'site'
  | 'restriction'
  | 'admin'
  | 'emergency'
  | 'scan'
  | 'system';

export interface ActivityLog {
  id: string;
  timestamp: string;
  operatorId: string;
  action: string;
  category: LogCategory;
  checksum: string;     // CRC-32 checksum
  isTampered: boolean;   // Verification flag (false = intact, true = tampered)
  severity?: 'success' | 'warning' | 'error' | 'info';
}

export interface ThreatPattern {
  id: string;
  title: string;
  description: string;
  severity: 'red' | 'yellow';
  isActive: boolean;
  count: number;
  lastDetected?: string;
}

export interface SystemStats {
  securityScore: number;
  activeRestrictions: number;
  suspiciousRestrictions: number;
  verifiedAccounts: number;
  totalSites: number;
  systemStatus: 'normal' | 'warning' | 'danger';
  detectedAnomaliesCount: number;
  emergencyOverrideActive: boolean;
  autoRepelShieldActive: boolean;
}
