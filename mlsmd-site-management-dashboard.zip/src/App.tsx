/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SecurityProvider, useSecurity } from './context/SecurityContext';
import { LoginModal } from './components/LoginModal';
import { Sidebar, NavTab } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/views/DashboardView';
import { SitesView } from './components/views/SitesView';
import { RestrictionsView } from './components/views/RestrictionsView';
import { AccountsView } from './components/views/AccountsView';
import { SecurityAuditView } from './components/views/SecurityAuditView';
import { ActivityLogsView } from './components/views/ActivityLogsView';
import { SettingsView } from './components/views/SettingsView';
import { TestScenariosModal } from './components/TestScenariosModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { CheckCircle2, AlertTriangle, XCircle, Info } from 'lucide-react';

const MainLayout: React.FC = () => {
  const { currentUser, toastMessage } = useSecurity();
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScenariosModalOpen, setIsScenariosModalOpen] = useState(false);
  const [isPWAInstallModalOpen, setIsPWAInstallModalOpen] = useState(false);

  // If not logged in, display the login screen with PWA direct install trigger
  if (!currentUser) {
    return (
      <>
        <LoginModal onOpenPWAInstall={() => setIsPWAInstallModalOpen(true)} />
        <PWAInstallModal
          isOpen={isPWAInstallModalOpen}
          onClose={() => setIsPWAInstallModalOpen(false)}
        />
      </>
    );
  }

  const renderActiveView = () => {
    switch (currentTab) {
      case 'dashboard':
        return (
          <DashboardView
            onNavigate={setCurrentTab}
            onOpenScenarios={() => setIsScenariosModalOpen(true)}
          />
        );
      case 'sites':
        return <SitesView />;
      case 'restrictions':
        return <RestrictionsView />;
      case 'accounts':
        return <AccountsView />;
      case 'audit':
        return <SecurityAuditView />;
      case 'logs':
        return <ActivityLogsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return (
          <DashboardView
            onNavigate={setCurrentTab}
            onOpenScenarios={() => setIsScenariosModalOpen(true)}
          />
        );
    }
  };

  return (
    <div className="flex h-screen bg-[#0a0e1a] text-[#e8ecf6] overflow-hidden">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        isMobileOpen={isMobileMenuOpen}
        setIsMobileOpen={setIsMobileMenuOpen}
        onOpenPWAInstall={() => setIsPWAInstallModalOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          currentTab={currentTab}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          onOpenScenarios={() => setIsScenariosModalOpen(true)}
          onOpenPWAInstall={() => setIsPWAInstallModalOpen(true)}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">{renderActiveView()}</div>
        </main>
      </div>

      {/* PWA Direct Device Installation & Immunity Modal */}
      <PWAInstallModal
        isOpen={isPWAInstallModalOpen}
        onClose={() => setIsPWAInstallModalOpen(false)}
      />

      {/* Test Scenarios Quick Launcher Modal */}
      <TestScenariosModal
        isOpen={isScenariosModalOpen}
        onClose={() => setIsScenariosModalOpen(false)}
        onNavigate={setCurrentTab}
      />

      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 animate-bounce duration-300">
          <div
            className={`px-4 py-3 rounded-lg shadow-xl text-xs font-semibold flex items-center gap-2 border backdrop-blur-md ${
              toastMessage.type === 'error'
                ? 'bg-[#ff5c7a]/20 text-[#ff5c7a] border-[#ff5c7a]/50'
                : toastMessage.type === 'warning'
                ? 'bg-[#ffb547]/20 text-[#ffb547] border-[#ffb547]/50'
                : toastMessage.type === 'success'
                ? 'bg-[#3ddc97]/20 text-[#3ddc97] border-[#3ddc97]/50'
                : 'bg-[#5b8cff]/20 text-[#5b8cff] border-[#5b8cff]/50'
            }`}
          >
            {toastMessage.type === 'error' && <XCircle className="w-4 h-4 shrink-0" />}
            {toastMessage.type === 'warning' && <AlertTriangle className="w-4 h-4 shrink-0" />}
            {toastMessage.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0" />}
            {toastMessage.type === 'info' && <Info className="w-4 h-4 shrink-0" />}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <SecurityProvider>
      <MainLayout />
    </SecurityProvider>
  );
}
